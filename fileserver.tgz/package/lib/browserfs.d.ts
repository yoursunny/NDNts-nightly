import { type BackendOption } from "@browserfs/core/backends/backend.js";
import { BaseFileSystem, type Cred, type File, type FileFlag, type FileSystemMetadata, Stats } from "@browserfs/core/index.js";
import { Client } from "./client.js";
/**
 * ndn6-file-server client wrapped as BrowserFS backend.
 *
 * @remarks
 * This backend only supports async operations.
 */
export declare class NDNFileSystem extends BaseFileSystem {
    static readonly Name = "NDN";
    static readonly Create: (options: import("@browserfs/core/backends/backend").BackendOptions, cb: import("@browserfs/core/filesystem").BFSCallback<import("@browserfs/core/filesystem").FileSystem>) => void;
    static readonly Options: Record<string, BackendOption<unknown>>;
    static isAvailable(): boolean;
    constructor(opts?: Partial<NDNFileSystem.Options>);
    private readonly client;
    private readonly statsCache?;
    get metadata(): FileSystemMetadata;
    private getFileMetadata;
    stat(p: string, cred: Cred): Promise<Stats>;
    readdir(p: string, cred: Cred): Promise<string[]>;
    openFile(p: string, flag: FileFlag, cred: Cred): Promise<File>;
    readFile(p: string, flag: FileFlag, cred: Cred): Promise<Uint8Array>;
}
export declare namespace NDNFileSystem {
    interface Options {
        client: Client;
        statsCacheCapacity?: number;
    }
}
