import { File, FileSystem, type FileSystemMetadata, Stats } from "@zenfs/core";
import { Client } from "./client.js";
declare const NDNFileSystem_base: import("@zenfs/core").Mixin<import("@zenfs/core").Mixin<typeof FileSystem, {
    metadata(): FileSystemMetadata;
    rename(oldPath: string, newPath: string): Promise<void>;
    renameSync(oldPath: string, newPath: string): void;
    createFile(path: string, flag: string, mode: number): Promise<File>;
    createFileSync(path: string, flag: string, mode: number): File;
    unlink(path: string): Promise<void>;
    unlinkSync(path: string): void;
    rmdir(path: string): Promise<void>;
    rmdirSync(path: string): void;
    mkdir(path: string, mode: number): Promise<void>;
    mkdirSync(path: string, mode: number): void;
    link(srcpath: string, dstpath: string): Promise<void>;
    linkSync(srcpath: string, dstpath: string): void;
    sync(path: string, data: Uint8Array, stats: Readonly<Stats>): Promise<void>;
    syncSync(path: string, data: Uint8Array, stats: Readonly<Stats>): void;
}>, {
    _sync?: FileSystem;
    queueDone(): Promise<void>;
    ready(): Promise<void>;
    renameSync(oldPath: string, newPath: string): void;
    statSync(path: string): Stats;
    createFileSync(path: string, flag: string, mode: number): File;
    openFileSync(path: string, flag: string): File;
    unlinkSync(path: string): void;
    rmdirSync(path: string): void;
    mkdirSync(path: string, mode: number): void;
    readdirSync(path: string): string[];
    linkSync(srcpath: string, dstpath: string): void;
    syncSync(path: string, data: Uint8Array, stats: Readonly<Stats>): void;
}>;
/**
 * ndn6-file-server client wrapped as ZenFS backend.
 *
 * @remarks
 * This backend only supports async operations.
 */
export declare class NDNFileSystem extends NDNFileSystem_base {
    constructor(opts: NDNFileSystem.Options);
    ready(): Promise<void>;
    metadata(): FileSystemMetadata;
    private readonly client;
    private readonly statsCache?;
    private getFileMetadata;
    stat(path: string): Promise<Stats>;
    readdir(path: string): Promise<string[]>;
    openFile(path: string, flag: string): Promise<File>;
}
export declare namespace NDNFileSystem {
    interface Options {
        client: Client;
        statsCacheCapacity?: number;
    }
}
/** ZenFS backend for {@link NDNFileSystem}. */
export declare const NDNZenFS: {
    readonly name: "NDN";
    readonly options: {
        readonly client: {
            readonly type: "object";
            readonly description: "Client instance";
            readonly required: true;
            readonly validator: (opt: Client) => void;
        };
        readonly statsCacheCapacity: {
            readonly type: "number";
            readonly description: "cache capacity for FileMetadata, 0 disables cache";
            readonly required: false;
            readonly validator: (opt: number | undefined) => void;
        };
    };
    readonly isAvailable: () => true;
    readonly create: (opts: NDNFileSystem.Options) => NDNFileSystem;
};
export {};
