export declare const TT: {
    readonly SegmentSize: 62720;
    readonly Size: 62722;
    readonly Mode: 62724;
    readonly Atime: 62726;
    readonly Btime: 62728;
    readonly Ctime: 62730;
    readonly Mtime: 62732;
};
export declare const ModeFile = 32768;
export declare const ModeDir = 16384;
/** 32=ls component */
export declare const lsKeyword: import("@ndn/packet").Component;
