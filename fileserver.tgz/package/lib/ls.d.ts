/** Directory listing entry. */
export interface DirEntry {
    name: string;
    isDir: boolean;
}
/** Parse directory listing payload from ndn6-file-server. */
export declare function parseDirectoryListing(input: Uint8Array): Iterable<DirEntry>;
/** Build directory listing payload. */
export declare function buildDirectoryListing(entries: Iterable<DirEntry>): Uint8Array;
