import type { ConsumerOptions } from "@ndn/endpoint";
import { type Name } from "@ndn/packet";
import { fetch } from "@ndn/segmented-object";
import { type DirEntry } from "./ls.js";
import { FileMetadata } from "./metadata.js";
/** {@link Client} options. */
export interface ClientOptions extends ConsumerOptions, fetch.Options {
}
/** ndn6-file-server client. */
export declare class Client {
    readonly prefix: Name;
    private readonly opts;
    constructor(prefix: Name, opts?: ClientOptions);
    /**
     * Retrieve metadata of given relative path.
     * @param relPath - File or directory path underneath the mount point.
     */
    stat(relPath: string): Promise<FileMetadata>;
    /**
     * Retrieve metadata of given relative path and directory entry.
     * @param parentRelPath - Parent directory path underneath the mount point.
     * @param de - Child directory entry.
     */
    stat(parentRelPath: string, de: DirEntry): Promise<FileMetadata>;
    /**
     * List directory.
     * @param m - Metadata of a directory.
     */
    readdir(m: FileMetadata): AsyncIterable<DirEntry>;
    /**
     * Retrieve entire contents of a file.
     * @param m - Metadata of a file.
     */
    readFile(m: FileMetadata): fetch.Result;
    /**
     * Retrieve part of a file into a buffer.
     * @param m - Metadata of a file.
     * @param buffer - The buffer that file contents will be written into.
     * @param offset - The offset within the buffer where writing will start.
     * @param length - The number of bytes to retrieve.
     * @param position - Where to begin reading from the file.
     */
    readFileInto(m: FileMetadata, buffer: Uint8Array, offset: number, length: number, position: number): Promise<void>;
}
