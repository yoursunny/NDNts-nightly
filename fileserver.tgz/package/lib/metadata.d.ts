import { type Component } from "@ndn/packet";
import { Metadata } from "@ndn/rdr";
import { Extensible, ExtensionRegistry } from "@ndn/tlv";
/** ndn6-file-server file/directory metadata. */
export declare class FileMetadata extends Metadata implements Extensible {
    readonly [Extensible.TAG]: ExtensionRegistry<Extensible>;
    finalBlock: Component | undefined;
    segmentSize: number | undefined;
    size: number | undefined;
    private atimeBig;
    private btimeBig;
    private ctimeBig;
    private mtimeOBig;
    atime: Date | undefined;
    btime: Date | undefined;
    ctime: Date | undefined;
    private mtimeO;
    get lastSeg(): number | undefined;
    set lastSeg(v: number | undefined);
    get mode(): number;
    set mode(v: number);
    get isFile(): boolean;
    get isDir(): boolean;
    get mtime(): Date;
    set mtime(v: Date);
}
