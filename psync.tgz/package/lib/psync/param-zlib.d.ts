import type { PSyncCodec } from "./codec.js";
/** Use zlib compression with PSync. */
export declare const PSyncZlib: PSyncCodec.Compression;
