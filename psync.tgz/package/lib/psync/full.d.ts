import { ConsumerOptions, type Endpoint, ProducerOptions } from "@ndn/endpoint";
import type { Name, Signer, Verifier } from "@ndn/packet";
import { type SyncNode, type SyncProtocol } from "@ndn/sync-api";
import { TypedEventTarget } from "typescript-event-target";
import { type IntervalRange } from "../detail/interval.js";
import type { IBLT } from "../iblt.js";
import { PSyncCodec } from "./codec.js";
import { PSyncCore } from "./core.js";
interface DebugEntry {
    action: string;
    ownIblt: IBLT;
    recvIblt?: IBLT;
    state?: PSyncCore.State;
}
type EventMap = SyncProtocol.EventMap<Name> & {
    debug: CustomEvent<DebugEntry>;
};
/** PSync - FullSync participant. */
export declare class FullSync extends TypedEventTarget<EventMap> implements SyncProtocol<Name> {
    constructor({ p, syncPrefix, describe, endpoint, // eslint-disable-line etc/no-deprecated
    cpOpts, syncReplyFreshness, signer, producerBufferLimit, syncInterestLifetime, syncInterestInterval, verifier, }: FullSync.Options);
    private readonly maybeHaveEventListener;
    readonly describe: string;
    private readonly syncPrefix;
    private readonly c;
    private readonly codec;
    private closed;
    private readonly pFreshness;
    private readonly pBuffer;
    private readonly pProducer;
    private readonly pPendings;
    private readonly cFetcher;
    private readonly cInterval;
    private cTimer;
    private cAbort?;
    private cCurrentInterestName?;
    private debug;
    /** Stop the protocol operation. */
    close(): void;
    get(prefix: Name): SyncNode<Name> | undefined;
    add(prefix: Name): SyncNode<Name>;
    private handleSyncInterest;
    private handleIncreaseSeqNum;
    private sendSyncData;
    private scheduleSyncInterest;
    private sendSyncInterest;
}
export declare namespace FullSync {
    interface Parameters extends PSyncCore.Parameters, PSyncCodec.Parameters {
    }
    interface Options {
        /**
         * Algorithm parameters.
         *
         * @remarks
         * They must be the same on every peer.
         */
        p: Parameters;
        /** Sync group prefix. */
        syncPrefix: Name;
        /**
         * Description for debugging purpose.
         * @defaultValue FullSync + syncPrefix
         */
        describe?: string;
        /**
         * Endpoint for communication.
         * @deprecated Specify `.cpOpts`.
         */
        endpoint?: Endpoint;
        /**
         * Consumer and producer options.
         *
         * @remarks
         * - `.fw` may be specified.
         * - Most other fields are overridden.
         */
        cpOpts?: ConsumerOptions & ProducerOptions;
        /**
         * FreshnessPeriod of sync reply Data packet.
         * @defaultValue 1000
         */
        syncReplyFreshness?: number;
        /**
         * Signer of sync reply Data packets.
         * @defaultValue digestSigning
         */
        signer?: Signer;
        /**
         * How many sync reply segmented objects to keep in buffer.
         * This must be a positive integer.
         * @defaultValue 32
         */
        producerBufferLimit?: number;
        /**
         * Sync Interest lifetime in milliseconds.
         * @defaultValue 1000
         */
        syncInterestLifetime?: number;
        /**
         * Interval between sync Interests, randomized within the range, in milliseconds.
         * @defaultValue `[syncInterestLifetime/2+100,syncInterestLifetime/2+500]`
         */
        syncInterestInterval?: IntervalRange;
        /**
         * Verifier of sync reply Data packets.
         * @defaultValue no verification
         */
        verifier?: Verifier;
    }
}
export {};
