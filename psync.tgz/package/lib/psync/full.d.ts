import { ConsumerOptions, ProducerOptions } from "@ndn/endpoint";
import type { Name, Signer, Verifier } from "@ndn/packet";
import { type SyncNode, type SyncProtocol } from "@ndn/sync-api";
import { TypedEventTarget } from "typescript-event-target";
import { type IntervalRange } from "../detail/interval.js";
import type { IBLT } from "../iblt.js";
import { PSyncCodec } from "./codec.js";
import { PSyncCore } from "./core.js";
interface DebugEntry {
    action: string;
    ownIblt: IBLT;
    recvIblt?: IBLT;
    state?: PSyncCore.State;
}
type EventMap = SyncProtocol.EventMap<Name> & {
    debug: CustomEvent<DebugEntry>;
};
/** PSync - FullSync participant. */
export declare class FullSync extends TypedEventTarget<EventMap> implements SyncProtocol<Name> {
    constructor({ p, syncPrefix, describe, cpOpts, syncReplyFreshness, signer, producerBufferLimit, syncInterestLifetime, syncInterestInterval, verifier, }: FullSync.Options);
    private readonly maybeHaveEventListener;
    readonly describe: string;
    private readonly syncPrefix;
    private readonly c;
    private readonly codec;
    private readonly syncInterestNameCumulativeNElements;
    private closed;
    private readonly pFreshness;
    private readonly pBuffer;
    private readonly pProducer;
    private readonly pPendings;
    private readonly cFetcher;
    private readonly cInterval;
    private cTimer;
    private cAbort?;
    private cCurrentInterestName?;
    private debug;
    /** Stop the protocol operation. */
    close(): void;
    get(prefix: Name): SyncNode<Name> | undefined;
    add(prefix: Name): SyncNode<Name>;
    private handleSyncInterest;
    private handleIncreaseSeqNum;
    private sendSyncData;
    private scheduleSyncInterest;
    private sendSyncInterest;
}
export declare namespace FullSync {
    interface Parameters extends PSyncCore.Parameters, PSyncCodec.Parameters {
        /**
         * If true, sync Interest name contains cumulative number of elements in IBLT.
         * @defaultValue true
         *
         * @remarks
         * PSync C++ library commit d83af5255db9c4a557264542647f7ccb281e6840 (2024-04-09) introduced an
         * algorithm change that involves a breaking change in sync Interest encoding.
         * To interact with PSync since this commit, set to true.
         * To interact with PSync before this commit, set to false.
         *
         * @experimental
         */
        syncInterestNameCumulativeNElements?: boolean;
    }
    interface Options {
        /**
         * Algorithm parameters.
         *
         * @remarks
         * They must be the same on every peer.
         */
        p: Parameters;
        /** Sync group prefix. */
        syncPrefix: Name;
        /**
         * Description for debugging purpose.
         * @defaultValue FullSync + syncPrefix
         */
        describe?: string;
        /**
         * Consumer and producer options.
         *
         * @remarks
         * - `.fw` may be specified.
         * - Most other fields are overridden.
         */
        cpOpts?: ConsumerOptions & ProducerOptions;
        /**
         * FreshnessPeriod of sync reply Data packet.
         * @defaultValue 1000
         */
        syncReplyFreshness?: number;
        /**
         * Signer of sync reply Data packets.
         * @defaultValue digestSigning
         */
        signer?: Signer;
        /**
         * How many sync reply segmented objects to keep in buffer.
         * This must be a positive integer.
         * @defaultValue 32
         */
        producerBufferLimit?: number;
        /**
         * Sync Interest lifetime in milliseconds.
         * @defaultValue 1000
         */
        syncInterestLifetime?: number;
        /**
         * Interval between sync Interests, randomized within the range, in milliseconds.
         * @defaultValue `[syncInterestLifetime/2+100,syncInterestLifetime/2+500]`
         */
        syncInterestInterval?: IntervalRange;
        /**
         * Verifier of sync reply Data packets.
         * @defaultValue no verification
         */
        verifier?: Verifier;
    }
}
export {};
