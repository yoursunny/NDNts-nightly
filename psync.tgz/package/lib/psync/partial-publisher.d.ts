import { type Endpoint, type ProducerOptions } from "@ndn/endpoint";
import { type Name, type Signer } from "@ndn/packet";
import type { SyncNode, SyncProtocol } from "@ndn/sync-api";
import { TypedEventTarget } from "typescript-event-target";
import { PSyncCodec } from "./codec.js";
import { PSyncCore } from "./core.js";
interface DebugEntry {
    action: string;
    interestName?: Name;
}
type EventMap = SyncProtocol.EventMap<Name> & {
    debug: CustomEvent<DebugEntry>;
};
/** PSync - PartialSync publisher. */
export declare class PartialPublisher extends TypedEventTarget<EventMap> implements SyncProtocol<Name> {
    constructor({ p, syncPrefix, describe, endpoint, // eslint-disable-line etc/no-deprecated
    pOpts, helloReplyFreshness, syncReplyFreshness, signer, producerBufferLimit, }: PartialPublisher.Options);
    private readonly maybeHaveEventListener;
    readonly describe: string;
    private readonly syncPrefix;
    private readonly c;
    private readonly codec;
    private closed;
    private readonly pBuffer;
    private readonly hFreshness;
    private readonly hProducer;
    private readonly sFreshness;
    private readonly sProducer;
    private readonly sPendings;
    private debug;
    /** Stop the protocol operation. */
    close(): void;
    get(prefix: Name): SyncNode<Name> | undefined;
    add(prefix: Name): SyncNode<Name>;
    private readonly handleHelloInterest;
    private readonly handleSyncInterest;
    private readonly handleIncreaseSeqNum;
    private sendStateData;
}
export declare namespace PartialPublisher {
    /** Algorithm parameters. */
    interface Parameters extends PSyncCore.Parameters, PSyncCodec.Parameters {
    }
    /** {@link PartialPublisher} constructor options. */
    interface Options {
        /**
         * Algorithm parameters.
         *
         * @remarks
         * They must match the subscriber parameters.
         */
        p: Parameters;
        /** Sync producer prefix. */
        syncPrefix: Name;
        /**
         * Description for debugging purpose.
         * @defaultValue PartialPublisher + syncPrefix
         */
        describe?: string;
        /**
         * Endpoint for communication.
         * @deprecated Specify `.pOpts`.
         */
        endpoint?: Endpoint;
        /**
         * Producer options (advanced).
         *
         * @remarks
         * - `.fw` is overridden as {@link Options.fw}.
         * - `.describe` is overridden as {@link Options.describe}.
         * - `.announcement` is overridden.
         * - `.routeCapture` is overridden.
         * - `.concurrency` is overridden.
         */
        pOpts?: ProducerOptions;
        /**
         * FreshnessPeriod of hello reply Data packet.
         * @defaultValue 1000
         */
        helloReplyFreshness?: number;
        /**
         * FreshnessPeriod of sync reply Data packet.
         * @defaultValue 1000
         */
        syncReplyFreshness?: number;
        /**
         * Signer of sync reply Data packets.
         * @defaultValue digestSigning
         */
        signer?: Signer;
        /**
         * How many sync reply segmented objects to keep in buffer.
         * This must be a positive integer.
         * @defaultValue 32
         */
        producerBufferLimit?: number;
    }
}
export {};
