import type { ConsumerOptions } from "@ndn/endpoint";
import type { Name } from "@ndn/packet";
import type { PSyncCodec } from "./codec.js";
import type { PSyncCore } from "./core.js";
interface Result {
    versioned: Name;
    state: PSyncCore.State;
}
export declare class StateFetcher {
    private readonly describe;
    private readonly codec;
    constructor(describe: string, codec: PSyncCodec, syncInterestLifetime: number, cOpts: ConsumerOptions);
    private readonly discoverVersionOpts;
    private readonly fetchOpts;
    fetch(name: Name, { signal }: AbortController, describeSuffix?: string): Promise<Result>;
}
export {};
