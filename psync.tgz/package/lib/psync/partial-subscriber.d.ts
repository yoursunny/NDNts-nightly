import type { ConsumerOptions, Endpoint } from "@ndn/endpoint";
import type { Name, Verifier } from "@ndn/packet";
import { type Subscriber, type Subscription, SyncUpdate } from "@ndn/sync-api";
import { type Parameters as BloomParameters } from "@yoursunny/psync-bloom";
import { TypedEventTarget } from "typescript-event-target";
import { PSyncCodec } from "./codec.js";
import type { PSyncCore } from "./core.js";
type Sub = Subscription<Name, SyncUpdate<Name>>;
type Update = SyncUpdate<Name>;
interface DebugEntry {
    action: string;
}
type EventMap = {
    /** Emitted for debugging. */
    debug: CustomEvent<DebugEntry>;
    state: PartialSubscriber.StateEvent;
};
/** PSync - PartialSync subscriber. */
export declare class PartialSubscriber extends TypedEventTarget<EventMap> implements Subscriber<Name, Update, PartialSubscriber.TopicInfo> {
    constructor({ p, syncPrefix, describe, endpoint, // eslint-disable-line etc/no-deprecated
    cOpts, syncInterestLifetime, syncInterestInterval, verifier, }: PartialSubscriber.Options);
    readonly describe: string;
    private readonly helloPrefix;
    private readonly syncPrefix;
    private readonly codec;
    private readonly encodeBloom;
    private closed;
    private readonly subs;
    private readonly prevSeqNums;
    private bloom;
    private ibltComp?;
    private readonly cFetcher;
    private readonly cInterval;
    private cTimer;
    private cAbort?;
    private debug;
    /** Stop the protocol operation. */
    close(): void;
    subscribe(topic: PartialSubscriber.TopicInfo): Sub;
    private readonly handleRemoveTopic;
    private scheduleInterest;
    private readonly sendInterest;
    private sendHelloInterest;
    private sendSyncInterest;
    private handleState;
}
export declare namespace PartialSubscriber {
    /** Algorithm parameters. */
    interface Parameters extends PSyncCore.Parameters, PSyncCodec.Parameters {
        bloom: BloomParameters;
    }
    /** {@link PartialSubscriber} constructor options. */
    interface Options {
        /**
         * Algorithm parameters.
         *
         * @remarks
         * They must match the publisher parameters.
         */
        p: Parameters;
        /** Sync producer prefix. */
        syncPrefix: Name;
        /**
         * Description for debugging purpose.
         * @defaultValue PartialSubscriber + syncPrefix
         */
        describe?: string;
        /**
         * Endpoint for communication.
         * @deprecated Specify `.cOpts`.
         */
        endpoint?: Endpoint;
        /**
         * Consumer options.
         *
         * @remarks
         * - `.describe` is overridden as {@link Options.describe}.
         * - `.modifyInterest` is overridden.
         * - `.retx` is overridden.
         * - `.signal` is overridden.
         * - `.verifier` is overridden.
         */
        cOpts?: ConsumerOptions;
        /**
         * Sync Interest lifetime in milliseconds.
         * @defaultValue 1000
         */
        syncInterestLifetime?: number;
        /**
         * Interval between sync Interests, randomized within the range, in milliseconds.
         * @defaultValue `[syncInterestLifetime/2+100,syncInterestLifetime/2+500]`
         */
        syncInterestInterval?: [min: number, max: number];
        /**
         * Verifier of sync reply Data packets.
         * @defaultValue no verification
         */
        verifier?: Verifier;
    }
    interface TopicInfo extends PSyncCore.PrefixSeqNum {
    }
    class StateEvent extends Event {
        readonly topics: readonly TopicInfo[];
        constructor(type: string, topics: readonly TopicInfo[]);
    }
}
export {};
