import type { Component, Name } from "@ndn/packet";
import type { BloomFilter } from "@yoursunny/psync-bloom";
import { type Compression as Compression_, IbltCodec } from "../detail/iblt-codec.js";
import type { IBLT } from "../iblt.js";
import type { PSyncCore } from "./core.js";
export declare class PSyncCodec {
    protected readonly ibltParams: IBLT.PreparedParameters;
    constructor(p: PSyncCodec.Parameters, ibltParams: IBLT.PreparedParameters);
    state2buffer(state: PSyncCore.State): Uint8Array;
    buffer2state(buffer: Uint8Array): PSyncCore.State;
}
export interface PSyncCodec extends Readonly<PSyncCodec.Parameters>, IbltCodec {
}
export declare namespace PSyncCodec {
    type Compression = Compression_;
    interface Parameters {
        /** Compression method for IBLT in name component. */
        ibltCompression: Compression;
        /** Compression method for State in segmented object. */
        contentCompression: Compression;
        /** Encode State to buffer (without compression). */
        encodeState: (state: PSyncCore.State) => Uint8Array;
        /** Decode State from buffer (without decompression). */
        decodeState: (payload: Uint8Array) => PSyncCore.State;
        /** Convert a name prefix to a Bloom filter key. */
        toBloomKey: (prefix: Name) => string | Uint8Array;
        /** Number of name components in an encoded Bloom filter. */
        encodeBloomLength: number;
        /** Encode a Bloom filter. */
        encodeBloom: (bf: BloomFilter) => Component[];
        /** Decode a Bloom filter. */
        decodeBloom: (Bloom: typeof BloomFilter, comps: readonly Component[]) => Promise<BloomFilter>;
    }
}
