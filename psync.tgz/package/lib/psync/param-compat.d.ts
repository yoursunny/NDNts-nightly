import type { IBLT } from "../iblt.js";
import type { PSyncCodec } from "./codec.js";
import type { FullSync } from "./full.js";
import type { PartialPublisher } from "./partial-publisher.js";
import type { PartialSubscriber } from "./partial-subscriber.js";
export declare function hash(seed: number, input: Uint8Array): number;
export declare function makeIbltParams(expectedEntries: number, keyToBufferLittleEndian: boolean, serializeLittleEndian?: boolean): IBLT.Parameters;
/** Create algorithm parameters to be compatible with PSync C++ library. */
export declare function makePSyncCompatParam({ keyToBufferLittleEndian, expectedEntries, expectedSubscriptions, ibltCompression, contentCompression, }?: makePSyncCompatParam.Options): FullSync.Parameters & PartialPublisher.Parameters & PartialSubscriber.Parameters;
export declare namespace makePSyncCompatParam {
    interface Options {
        /**
         * Whether to use little endian when converting uint32 key to Uint8Array.
         * @defaultValue true
         *
         * @remarks
         * PSync C++ library behaves differently on big endian and little endian machines,
         * {@link https://github.com/named-data/PSync/blob/b60398c5fc216a1b577b9dbcf61d48a21cb409a4/PSync/detail/util.cpp#L126}
         * This must be set to match other peers.
         */
        keyToBufferLittleEndian?: boolean;
        /**
         * Expected number of IBLT entries, i.e. expected number of updates in a sync cycle.
         * @defaultValue 80
         *
         * @remarks
         * This is irrelevant to PartialSync consumer.
         */
        expectedEntries?: number;
        /**
         * Estimated number of subscriptions in PartialSync consumer.
         * @defaultValue 16
         */
        expectedSubscriptions?: number;
        /**
         * Whether to use zlib compression on IBLT.
         * @defaultValue no compression
         *
         * @remarks
         * Use {@link PSyncZlib} to set zlib compression.
         *
         * In PSync C++ library, default for FullSync depends on whether zlib is available at compile
         * time, and default for PartialSync is no compression.
         * This must be set to match other peers.
         */
        ibltCompression?: PSyncCodec.Compression;
        /**
         * Whether to use zlib compression on Data payload.
         * @defaultValue no compression
         *
         * @remarks
         * Use {@link PSyncZlib} to set zlib compression.
         *
         * In PSync C++ library, default for FullSync depends on whether zlib is available at compile
         * time. For PartialSync, it is always no compression.
         * This must be set to match other peers.
         */
        contentCompression?: PSyncCodec.Compression;
    }
}
