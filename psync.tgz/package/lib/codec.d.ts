import { Component, type Name } from "@ndn/packet";
import type { BloomFilter } from "@yoursunny/psync-bloom";
import type { Promisable } from "type-fest";
import type { PSyncCore } from "./core.js";
import { IBLT } from "./iblt.js";
export declare class PSyncCodec {
    protected readonly ibltParams: IBLT.PreparedParameters;
    constructor(p: PSyncCodec.Parameters, ibltParams: IBLT.PreparedParameters);
    iblt2comp(iblt: IBLT): Promise<Component>;
    comp2iblt(comp: Component): Promise<IBLT>;
    state2buffer(state: PSyncCore.State): Promise<Uint8Array>;
    buffer2state(buffer: Uint8Array): Promise<PSyncCore.State>;
}
export interface PSyncCodec extends Readonly<PSyncCodec.Parameters> {
}
export declare namespace PSyncCodec {
    interface Compression {
        compress: (input: Uint8Array) => Promisable<Uint8Array>;
        decompress: (compressed: Uint8Array) => Promisable<Uint8Array>;
    }
    interface Parameters {
        /** Compression method for IBLT in name component. */
        ibltCompression: Compression;
        /** Compression method for State in segmented object. */
        contentCompression: Compression;
        /** Encode State to buffer (without compression). */
        encodeState: (state: PSyncCore.State) => Uint8Array;
        /** Decode State from buffer (without decompression). */
        decodeState: (payload: Uint8Array) => PSyncCore.State;
        /** Convert a name prefix to a Bloom filter key. */
        toBloomKey: (prefix: Name) => string | Uint8Array;
        /** Number of name components in an encoded Bloom filter. */
        encodeBloomLength: number;
        /** Encode a Bloom filter. */
        encodeBloom: (bf: BloomFilter) => Component[];
        /** Decode a Bloom filter. */
        decodeBloom: (Bloom: typeof BloomFilter, comps: readonly Component[]) => Promise<BloomFilter>;
    }
}
