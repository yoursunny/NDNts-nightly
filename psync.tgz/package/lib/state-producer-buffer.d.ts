import type { ProducerOptions } from "@ndn/endpoint";
import type { Name } from "@ndn/packet";
import { type Server } from "@ndn/segmented-object";
import type { PSyncCodec } from "./codec.js";
import type { PSyncCore } from "./core.js";
export declare class StateProducerBuffer {
    private readonly codec;
    private readonly limit;
    constructor(describe: string, codec: PSyncCodec, limit: number, pOpts: ProducerOptions);
    private readonly pOpts;
    private readonly servers;
    close(): void;
    add(name: Name, state: PSyncCore.State, freshnessPeriod: number): Promise<Server>;
}
