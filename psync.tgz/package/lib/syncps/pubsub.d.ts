import { ConsumerOptions, ProducerOptions } from "@ndn/endpoint";
import { Data, type Name, type Signer, type Verifier } from "@ndn/packet";
import { type Subscriber, type Subscription } from "@ndn/sync-api";
import { TypedEventTarget } from "typescript-event-target";
import { IBLT } from "../iblt.js";
import { SyncpsCodec } from "./codec.js";
interface DebugEntry {
    action: string;
    key?: number;
    name?: Name;
    ownIblt: IBLT;
    recvIblt?: IBLT;
    content?: Name[];
}
type EventMap = {
    debug: CustomEvent<DebugEntry>;
};
/** syncps - pubsub service. */
export declare class SyncpsPubsub extends TypedEventTarget<EventMap> implements Subscriber<Name, CustomEvent<Data>> {
    constructor({ p, syncPrefix, describe, cpOpts, syncInterestLifetime, syncDataPubSize, syncSigner, syncVerifier, maxPubLifetime, maxClockSkew, modifyPublication, isExpired, filterPubs, pubSigner, pubVerifier, }: SyncpsPubsub.Options);
    private readonly maybeHaveEventListener;
    readonly describe: string;
    private readonly syncPrefix;
    private readonly codec;
    private closed;
    private readonly iblt;
    private readonly pubs;
    private readonly maxPubLifetime;
    private readonly maxClockSkew;
    private readonly subs;
    private readonly dModify;
    private readonly dIsExpired;
    private readonly dSigner;
    private readonly dVerifier?;
    private nOwnPubs;
    /** IBLT of own publications with callback. */
    private readonly dConfirmIblt;
    private readonly pProducer;
    private readonly pFilter;
    private readonly pPubSize;
    private readonly pPendings;
    private readonly cOpts;
    private readonly cLifetime;
    private cAbort?;
    private cTimer;
    private cCurrentInterestNonce?;
    private cDelivering;
    private debug;
    /** Stop the protocol operation. */
    close(): void;
    /**
     * Publish a packet.
     * @param pub - Data packet. This does not need to be signed.
     * @param cb - Callback to get notified whether publication is confirmed,
     *             i.e. its hash appears in a sync Interest from another participant.
     * @returns - Promise that resolves when the publication is recorded.
     *            It does not mean the publication has reached other participants.
     */
    publish(pub: Data, cb?: SyncpsPubsub.PublishCallback): Promise<void>;
    /** Subscribe to a topic. */
    subscribe(topic: Name): Subscription<Name, CustomEvent<Data>>;
    private handleSyncInterest;
    private processSyncInterest;
    private processPendingInterests;
    private scheduleSyncInterest;
    private sendSyncInterest;
    private isExpired;
    private addToActive;
    private invokePublishCb;
}
export declare namespace SyncpsPubsub {
    interface Parameters extends SyncpsCodec.Parameters {
        iblt: IBLT.Parameters;
    }
    type ModifyPublicationCallback = (pub: Data) => void;
    /**
     * Callback to determine if a publication is expired.
     *
     * @remarks
     * The callback can return either:
     * - boolean to indicate whether the publication is expired.
     * - number, interpreted as Unix timestamp (milliseconds) of publication creation time.
     *   The publication is considered expired if this timestamp is before
     *   `NOW - (maxPubLifetime+maxClockSkew)` or after `NOW + maxClockSkew`.
     */
    type IsExpiredCallback = (pub: Data) => boolean | number;
    interface FilterPubItem {
        /** A publication, i.e. Data packet. */
        readonly pub: Data;
        /** Whether the publication is owned by the local participant. */
        readonly own: boolean;
    }
    /**
     * Callback to decide what publications to be included in a response.
     * @param items - Unexpired publications.
     * @returns A priority list of publications to be included in the response.
     */
    type FilterPubsCallback = (items: FilterPubItem[]) => FilterPubItem[];
    interface Options {
        /**
         * Algorithm parameters.
         *
         * @remarks
         * They must be the same on every peer.
         */
        p: Parameters;
        /** Sync group prefix. */
        syncPrefix: Name;
        /**
         * Description for debugging purpose.
         * @defaultValue SyncpsPubsub + syncPrefix
         */
        describe?: string;
        /**
         * Consumer and producer options.
         *
         * @remarks
         * - `.fw` may be specified.
         * - Most other fields are overridden.
         */
        cpOpts?: ConsumerOptions & ProducerOptions;
        /**
         * Sync Interest lifetime in milliseconds.
         * @defaultValue 4000
         */
        syncInterestLifetime?: number;
        /**
         * Advisory maximum size for publications included in a sync reply Data packet.
         * @defaultValue 1300
         */
        syncDataPubSize?: number;
        /**
         * Signer of sync reply Data packets.
         * @defaultValue digestSigning
         */
        syncSigner?: Signer;
        /**
         * Verifier of sync reply Data packets.
         * @defaultValue no verification
         */
        syncVerifier?: Verifier;
        /**
         * Publication lifetime.
         * @defaultValue 1000
         */
        maxPubLifetime?: number;
        /**
         * Maximum clock skew, for calculating timers.
         * @defaultValue 1000
         */
        maxClockSkew?: number;
        /**
         * Callback to modify publication before it's signed.
         * @defaultValue appending a TimestampNameComponent to the name
         */
        modifyPublication?: ModifyPublicationCallback;
        /**
         * Callback to determine if a publication is expired.
         *
         * @defaultValue
         * The last component is interpreted as TimestampNameComponent.
         * If it is not a TimestampNameComponent, the publication is seen as expired.
         */
        isExpired?: IsExpiredCallback;
        /**
         * Callback to decide what publications to be included in a response.
         *
         * @defaultValue
         * - Respond nothing if there's no own publication.
         * - Otherwise, prioritize own publications over others, and prioritize later timestamp.
         */
        filterPubs?: FilterPubsCallback;
        /**
         * Signer of publications.
         * @defaultValue digestSigning
         */
        pubSigner?: Signer;
        /**
         * Verifier of publications.
         * @defaultValue no verification
         */
        pubVerifier?: Verifier;
    }
    type PublishCallback = (pub: Data, confirmed: boolean) => void;
}
export {};
