import type { SyncpsPubsub } from "./pubsub.js";
/** Create algorithm parameters to be compatible with DNMP-v2 syncps library. */
export declare function makeSyncpsCompatParam({ keyToBufferLittleEndian, expectedEntries, }?: makeSyncpsCompatParam.Options): SyncpsPubsub.Parameters;
export declare namespace makeSyncpsCompatParam {
    interface Options {
        /**
         * Whether to use little endian when converting a uint32 key to a byte array.
         * @defaultValue true
         *
         * @remarks
         * ndn-ind behaves differently on big endian and little endian machines,
         * {@link https://github.com/operantnetworks/ndn-ind/blob/dd934a7a5106cda6ea14675554427e12df1ce18f/src/lite/util/crypto-lite.cpp#L114}
         * This must be set to match other peers.
         */
        keyToBufferLittleEndian?: boolean;
        /**
         * Expected number of IBLT entries, i.e. expected number of updates in a sync cycle.
         * @defaultValue 85
         */
        expectedEntries?: number;
    }
}
