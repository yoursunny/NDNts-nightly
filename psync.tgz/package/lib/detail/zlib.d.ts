import pako from "pako";
import type { Compression } from "./iblt-codec.js";
export declare function makeZlib(level: pako.DeflateFunctionOptions["level"]): Compression;
