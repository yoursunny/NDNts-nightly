export type IntervalRange = [min: number, max: number];
export type IntervalFunc = () => number;
export declare function computeInterval(input: IntervalRange | undefined, syncInterestLifetime: number): IntervalFunc;
