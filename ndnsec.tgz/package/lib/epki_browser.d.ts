/** Create EncryptedPrivateKeyInfo. */
export declare function create(privateKey: Uint8Array, passphrase: string | Uint8Array): Promise<Uint8Array>;
/** Decrypt EncryptedPrivateKeyInfo. */
export declare function decrypt(encryptedKey: Uint8Array, passphrase: string | Uint8Array): Promise<Uint8Array>;
