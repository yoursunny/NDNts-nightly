import { Certificate, KeyChain, KeyStore } from "@ndn/keychain";
import { Name } from "@ndn/packet";
import { SafeBag } from "./safe-bag";
/** Access ndn-cxx KeyChain. */
export declare class NdnsecKeyChain extends KeyChain {
    constructor({ home, pibLocator, tpmLocator, importOptions, }?: NdnsecKeyChain.Options);
    private readonly env;
    private readonly importOptions;
    private invokeNdnsec;
    /** Copy keys and certificates to another keychain. */
    copyTo(dest: KeyChain): Promise<KeyChain>;
    private mutex;
    private cached?;
    private load;
    readonly needJwk = true;
    private readonly insertKeyLoader;
    listKeys(prefix?: Name): Promise<Name[]>;
    getKeyPair(name: Name): Promise<KeyChain.KeyPair>;
    insertKey(name: Name, stored: KeyStore.StoredKey): Promise<void>;
    deleteKey(name: Name): Promise<void>;
    listCerts(prefix?: Name): Promise<Name[]>;
    getCert(name: Name): Promise<Certificate>;
    insertCert(cert: Certificate): Promise<void>;
    deleteCert(name: Name): Promise<void>;
}
export declare namespace NdnsecKeyChain {
    interface Options {
        home?: string;
        pibLocator?: string;
        tpmLocator?: string;
        importOptions?: SafeBag.ImportOptions;
    }
}
