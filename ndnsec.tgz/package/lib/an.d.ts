export declare const TT: {
    readonly SafeBag: 128;
    readonly EncryptedKey: 129;
};
