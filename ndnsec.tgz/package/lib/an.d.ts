export declare namespace TT {
    const SafeBag = 128;
    const EncryptedKeyBag = 129;
}
