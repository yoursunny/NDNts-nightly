import { Certificate, KeyChain, KeyChainSerialized, KeyStore } from "@ndn/keychain";
import { Name } from "@ndn/packet";
import { SafeBag } from "./safe-bag.js";
/** Access ndn-cxx KeyChain. */
export declare class NdnsecKeyChain extends KeyChainSerialized {
    /**
     * Whether current environment supports ndn-cxx KeyChain.
     *
     * @remarks
     * It checks whether `ndnsec` program is installed.
     */
    static get supported(): boolean;
    constructor({ pibLocator, tpmLocator, home, importOptions, }?: NdnsecKeyChain.Options);
    readonly needJwk = true;
    private readonly env;
    private readonly importOptions?;
    private cached?;
    private readonly insertKeyLoader;
    private invokeNdnsec;
    /** Copy keys and certificates to another keychain. */
    copyTo(dest: KeyChain): Promise<KeyChain>;
    private load;
    protected sListKeys(prefix: Name): Promise<Name[]>;
    protected sGetKeyPair(name: Name): Promise<KeyChain.KeyPair>;
    protected sInsertKey(name: Name, stored: KeyStore.StoredKey): Promise<void>;
    protected sDeleteKey(name: Name): Promise<void>;
    protected sListCerts(prefix: Name): Promise<Name[]>;
    protected sGetCert(name: Name): Promise<Certificate>;
    protected sInsertCert(cert: Certificate): Promise<void>;
    protected sDeleteCert(name: Name): Promise<void>;
}
export declare namespace NdnsecKeyChain {
    /** {@link NdnsecKeyChain} constructor options. */
    interface Options {
        /**
         * ndn-cxx PIB locator.
         *
         * @remarks
         * This must be specified together with `.tpmLocator`.
         * @see {@link https://docs.named-data.net/ndn-cxx/0.8.1/manpages/ndn-client.conf.html#key-management}
         */
        pibLocator?: string;
        /**
         * ndn-cxx TPM locator.
         *
         * @remarks
         * This must be specified together with `.pibLocator`.
         * @see {@link https://docs.named-data.net/ndn-cxx/0.8.1/manpages/ndn-client.conf.html#key-management}
         */
        tpmLocator?: string;
        /**
         * HOME environment variable to pass to ndnsec command.
         *
         * @remarks
         * ndn-cxx will derive PIB locator and TPM locator from HOME environment variable.
         * This is ignored when both `.pibLocator` and `.tpmLocator` are specified.
         */
        home?: string;
        /** SafeBag import options. */
        importOptions?: SafeBag.ImportOptions;
    }
}
