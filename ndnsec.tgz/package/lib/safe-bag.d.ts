import { Certificate, type KeyChain } from "@ndn/keychain";
import { type Decoder, type Encoder } from "@ndn/tlv";
interface Fields {
    certificate: Certificate;
    encryptedKey: Uint8Array;
}
/**
 * ndn-cxx exported credentials.
 * @see {@link https://docs.named-data.net/ndn-cxx/0.8.1/specs/safe-bag.html}
 */
export declare class SafeBag {
    /** Create a SafeBag from certificate and private key. */
    static create(certificate: Certificate, privateKey: Uint8Array, passphrase: string | Uint8Array): Promise<SafeBag>;
    static decodeFrom(decoder: Decoder): SafeBag;
    private constructor();
    encodeTo(encoder: Encoder): void;
    /**
     * Decrypt private key.
     * @param passphrase - SafeBag passphrase.
     * @returns Unencrypted private key in PKCS8 format.
     */
    decryptKey(passphrase: string | Uint8Array): Promise<Uint8Array>;
    /**
     * Save private key and public key to KeyChain.
     * @param passphrase - SafeBag passphrase.
     * @param keyChain - Destination KeyChain.
     */
    saveKeyPair(passphrase: string | Uint8Array, keyChain: KeyChain, { preferRSAOAEP }?: SafeBag.ImportOptions): Promise<void>;
}
export interface SafeBag extends Readonly<Fields> {
}
export declare namespace SafeBag {
    /** {@link SafeBag.saveKeyPair} options. */
    interface ImportOptions {
        /**
         * Import RSA key as RSA-OAEP encryption key instead of RSA signing key.
         *
         * @remarks
         * ndn-cxx stores RSA signing key and RSA-OAEP encryption key in the same format.
         * By default, RSA key is imported as RSASSA-PKCS1-v1_5 signing key.
         * Set to true to import RSA key as RSA-OAEP encryption key instead.
         */
        preferRSAOAEP?: boolean;
    }
}
export {};
