import { Certificate, KeyChain } from "@ndn/keychain";
import { Decoder, Encoder } from "@ndn/tlv";
/** ndn-cxx private key export. */
export declare class SafeBag {
    readonly certificate: Certificate;
    readonly encryptedKey: Uint8Array;
    static create(certificate: Certificate, privateKey: Uint8Array, passphrase: string): SafeBag;
    static decodeFrom(decoder: Decoder): SafeBag;
    constructor(certificate: Certificate, encryptedKey: Uint8Array);
    encodeTo(encoder: Encoder): void;
    /** Decrypt private key and return unencrypted PKCS8 format. */
    decryptKey(passphrase: string | Uint8Array): Uint8Array;
    /**
     * Save private key and public key to KeyChain.
     * @param passphrase SafeBag passphrase.
     * @param keyChain destination KeyChain.
     */
    saveKeyPair(passphrase: string, keyChain: KeyChain, { preferRSAOAEP }?: SafeBag.ImportOptions): Promise<void>;
}
export declare namespace SafeBag {
    interface ImportOptions {
        /**
         * ndn-cxx stores RSA signing key and RSA-OAEP encryption key in the same format.
         * By default, RSA key is imported as RSASSA-PKCS1-v1_5 signing key.
         * Set to true to import RSA key as RSA-OAEP encryption key instead.
         */
        preferRSAOAEP?: boolean;
    }
}
