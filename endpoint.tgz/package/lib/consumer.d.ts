import { Forwarder } from "@ndn/fw";
import { Data, Interest, type NameLike, type Verifier } from "@ndn/packet";
import { type RetxPolicy } from "./retx.js";
/** {@link consume} options. */
export interface ConsumerOptions {
    /**
     * Logical forwarder instance.
     * @defaultValue `Forwarder.getDefault()`
     */
    fw?: Forwarder;
    /**
     * Description for debugging purpose.
     * @defaultValue
     * "consume" + Interest name.
     */
    describe?: string;
    /** AbortSignal that allows canceling the Interest via AbortController. */
    signal?: AbortSignal;
    /**
     * Modify Interest according to specified options.
     * @defaultValue
     * `undefined`, no modification.
     */
    modifyInterest?: Interest.Modify;
    /**
     * Retransmission policy.
     * @defaultValue
     * `undefined`, no retransmission.
     */
    retx?: RetxPolicy;
    /**
     * Data verifier.
     * @defaultValue
     * `undefined`, no verification.
     */
    verifier?: Verifier;
}
export declare namespace ConsumerOptions {
    function exact(opts?: ConsumerOptions): ConsumerOptions;
}
/**
 * Progress of Data retrieval.
 *
 * @remarks
 * This is a Promise that resolves with the retrieved Data and rejects upon timeout,
 * annotated with the Interest and some counters.
 */
export interface ConsumerContext extends Promise<Data> {
    readonly interest: Interest;
    readonly nRetx: number;
}
/**
 * Retrieve a single piece of Data.
 * @param interest - Interest or Interest name.
 */
export declare function consume(interest: Interest | NameLike, opts?: ConsumerOptions): ConsumerContext;
