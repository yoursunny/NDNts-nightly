import { Data, Interest, type NameLike, type Verifier } from "@ndn/packet";
import { type CommonOptions } from "./common.js";
import { type RetxPolicy } from "./retx.js";
/** {@link consume} options. */
export interface ConsumerOptions extends CommonOptions {
    /**
     * Modify Interest according to specified options.
     * @defaultValue
     * `undefined`, no modification.
     */
    modifyInterest?: Interest.Modify;
    /**
     * Retransmission policy.
     * @defaultValue
     * `undefined`, no retransmission.
     */
    retx?: RetxPolicy;
    /**
     * Data verifier.
     * @defaultValue
     * `undefined`, no verification.
     */
    verifier?: Verifier;
}
export declare namespace ConsumerOptions {
    function exact(opts?: ConsumerOptions): ConsumerOptions;
}
/**
 * Progress of Data retrieval.
 *
 * @remarks
 * This is a Promise that resolves with the retrieved Data and rejects upon timeout,
 * annotated with the Interest and some counters.
 */
export interface ConsumerContext extends Promise<Data> {
    /** Interest packet, after any modifications. */
    readonly interest: Interest;
    /**
     * Number of retransmissions sent so far.
     *
     * @remarks
     * The initial Interest does not count as a retransmission.
     */
    readonly nRetx: number;
    /**
     * Duration (milliseconds) between last Interest transmission and Data arrival.
     *
     * @remarks
     * This is a valid RTT measurement if {@link nRetx} is zero.
     */
    readonly rtt: number | undefined;
}
/**
 * Retrieve a single piece of Data.
 * @param interest - Interest or Interest name.
 */
export declare function consume(interest: Interest | NameLike, opts?: ConsumerOptions): ConsumerContext;
