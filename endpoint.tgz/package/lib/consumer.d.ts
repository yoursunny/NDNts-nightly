import { Forwarder } from "@ndn/fw";
import { Data, Interest, NameLike, Verifier } from "@ndn/packet";
import type { AbortSignal } from "abort-controller";
import { RetxPolicy } from "./retx";
export interface Options {
    /** Description for debugging purpose. */
    describe?: string;
    /**
     * Modify Interest according to specified options.
     * Default is no modification.
     */
    modifyInterest?: Interest.Modify;
    /**
     * Retransmission policy.
     * Default is disabling retransmission.
     */
    retx?: RetxPolicy;
    /** AbortSignal that allows canceling the Interest via AbortController. */
    signal?: AbortSignal | globalThis.AbortSignal;
    /**
     * Data verifier.
     * Default is no verification.
     */
    verifier?: Verifier;
}
/**
 * Progress of Data retrieval.
 *
 * This is a Promise that resolves with the retrieved Data, and rejects upon timeout.
 * Calling .cancel() cancels Data retrieval and rejects the Promise.
 */
export declare type Context = Promise<Data> & {
    readonly interest: Interest;
    readonly nRetx: number;
};
/** Consumer functionality of Endpoint. */
export declare class EndpointConsumer {
    fw: Forwarder;
    opts: Options;
    /** Consume a single piece of Data. */
    consume(interestInput: Interest | NameLike, opts?: Options): Context;
}
