import { Data, Interest, Signer } from "@ndn/packet";
/** Outgoing Data buffer for producer. */
export interface DataBuffer {
    find: (interest: Interest) => Promise<Data | undefined>;
    insert: (...pkts: Data[]) => Promise<void>;
}
/** Prototype of DataStore from @ndn/repo package. */
interface DataStore {
    find: (interest: Interest) => Promise<Data | undefined>;
    insert: (opts: {
        expireTime?: number;
    }, ...pkts: Data[]) => Promise<void>;
}
/**
 * DataBuffer implementation based on DataStore from @ndn/repo package.
 *
 * @example
 * new DataStoreBuffer(new DataStore(memdown()))
 */
export declare class DataStoreBuffer implements DataBuffer {
    readonly store: DataStore;
    constructor(store: DataStore, { ttl, dataSigner, }?: DataStoreBuffer.Options);
    private readonly ttl;
    private readonly dataSigner?;
    find(interest: Interest): Promise<Data | undefined>;
    insert(...pkts: Data[]): Promise<void>;
}
export declare namespace DataStoreBuffer {
    interface Options {
        /** Data expiration time. Default is 60000ms. 0 means infinity. */
        ttl?: number;
        /** If specified, automatically sign Data packets unless already signed. */
        dataSigner?: Signer;
    }
}
export {};
