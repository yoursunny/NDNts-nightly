import { type Data, type Interest, Signer } from "@ndn/packet";
/** Outgoing Data buffer for producer. */
export interface DataBuffer {
    find: (interest: Interest) => Promise<Data | undefined>;
    insert: (...pkts: readonly Data[]) => Promise<void>;
}
interface DataStore {
    find: (interest: Interest) => Promise<Data | undefined>;
    insert: (opts: {
        expireTime?: number;
    }, ...pkts: readonly Data[]) => Promise<void>;
}
/** DataBuffer implementation based on `@ndn/repo`. */
export declare class DataStoreBuffer implements DataBuffer {
    readonly store: DataStore;
    /**
     * Constructor.
     * @param store - {@link \@ndn/repo!DataStore} instance.
     *
     * @example
     * ```ts
     * new DataStoreBuffer(await makeInMemoryDataStore())
     * ```
     *
     * @remarks
     * `DataStore` is declared as an interface instead of importing, in order to reduce bundle size
     * for webapps that do not use DataBuffer. The trade-off is that, applications wanting to use
     * DataBuffer would have to import `@ndn/repo` themselves.
     * Note: {@link \@ndn/repo-api!DataArray} is insufficient because it lacks `expireTime` option.
     */
    constructor(store: DataStore, { ttl, dataSigner, }?: DataStoreBuffer.Options);
    private readonly ttl;
    private readonly dataSigner?;
    find(interest: Interest): Promise<Data | undefined>;
    insert(...pkts: Data[]): Promise<void>;
}
export declare namespace DataStoreBuffer {
    /** {@link DataStoreBuffer} constructor options. */
    interface Options {
        /**
         * Data expiration time in milliseconds.
         * 0 means infinity.
         * @defaultValue 60000
         */
        ttl?: number;
        /**
         * If specified, automatically sign Data packets unless already signed.
         * @see {@link ProducerOptions.dataSigner}
         */
        dataSigner?: Signer;
    }
}
export {};
