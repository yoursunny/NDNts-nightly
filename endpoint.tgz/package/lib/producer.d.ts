import { Forwarder, FwFace } from "@ndn/fw";
import { Data, Interest, Name, NameLike, Signer } from "@ndn/packet";
import type { DataBuffer } from "./data-buffer";
/**
 * Producer handler function.
 *
 * The handler can return a Data to respond to the Interest, or return `undefined` to cause a timeout.
 *
 * If Options.dataBuffer is provided, the handler can access the DataBuffer via producer.dataBuffer .
 * The handler can return a Data to respond to the Interest, which is also inserted to the DataBuffer
 * unless Options.autoBuffer is set to false. If the handler returns `undefined`, the Interest is used
 * to query the DataBuffer, and any matching Data may be sent.
 */
export declare type Handler = (interest: Interest, producer: Producer) => Promise<Data | undefined>;
export interface Options {
    /** Description for debugging purpose. */
    describe?: string;
    /**
     * What name to be readvertised.
     * Ignored if prefix is undefined.
     */
    announcement?: EndpointProducer.RouteAnnouncement;
    /**
     * How many Interests to process in parallel.
     * Default is 1.
     */
    concurrency?: number;
    /**
     * If specified, automatically sign Data packets unless already signed.
     * This does not apply to Data packets manually inserted to the dataBuffer.
     */
    dataSigner?: Signer;
    /** Outgoing Data buffer. */
    dataBuffer?: DataBuffer;
    /**
     * Whether to add handler return value to buffer.
     * Default is true.
     * Ignored when dataBuffer is not specified.
     */
    autoBuffer?: boolean;
}
/** A running producer. */
export interface Producer {
    readonly prefix: Name | undefined;
    readonly face: FwFace;
    readonly dataBuffer?: DataBuffer;
    /**
     * Process an Interest received elsewhere.
     *
     * Use case of this function:
     * 1. Producer A dynamically creates producer B upon receiving an Interest.
     * 2. Producer A can invoke this function to let producer B generate a response.
     * 3. The response should be sent by producer A.
     */
    processInterest: (interest: Interest) => Promise<Data | undefined>;
    /** Close the producer. */
    close: () => void;
}
/** Producer functionality of Endpoint. */
export declare class EndpointProducer {
    fw: Forwarder;
    opts: Options;
    /**
     * Start a producer.
     * @param prefixInput prefix registration; if undefined, prefixes may be added later.
     * @param handler function to handle incoming Interest.
     */
    produce(prefixInput: NameLike | undefined, handler: Handler, opts?: Options): Producer;
}
export declare namespace EndpointProducer {
    type RouteAnnouncement = FwFace.RouteAnnouncement;
}
export declare function signUnsignedData(data: Data, dataSigner: Signer | undefined): Promise<void>;
