import { Forwarder } from "@ndn/fw";
import { EndpointConsumer, Options as ConsumerOptions } from "./consumer";
import { EndpointProducer, Options as ProducerOptions } from "./producer";
export interface Options extends ConsumerOptions, ProducerOptions {
    fw?: Forwarder;
}
/**
 * Endpoint is the main entrypoint for an application to interact with the forwarding plane.
 * It provides basic consumer and producer functionality.
 */
export declare class Endpoint {
    readonly opts: Options;
    readonly fw: Forwarder;
    constructor(opts?: Options);
}
export interface Endpoint extends EndpointConsumer, EndpointProducer {
}
export declare namespace Endpoint {
    /** Delete default Forwarder instance (mainly for unit testing). */
    const deleteDefaultForwarder: typeof Forwarder.deleteDefault;
    type RouteAnnouncement = EndpointProducer.RouteAnnouncement;
}
