import { Forwarder } from "@ndn/fw";
import type { Interest, NameLike } from "@ndn/packet";
import { type ConsumerContext, ConsumerOptions } from "./consumer.js";
import { type Producer, type ProducerHandler, ProducerOptions } from "./producer.js";
/**
 * {@link Endpoint} constructor options.
 *
 * @remarks
 * This type includes consumer and producer options. These settings will be inherited by
 * {@link Endpoint.consume} and {@link Endpoint.produce} unless overridden.
 */
export interface Options extends ConsumerOptions, ProducerOptions {
}
/**
 * Endpoint provides basic consumer and producer functionality. It is the main entry point for an
 * application to interact with the logical forwarder.
 */
export declare class Endpoint {
    readonly opts: Options;
    /**
     * Constructor.
     * @deprecated Use {@link consume} and {@link produce} standalone functions.
     */
    constructor(opts?: Options);
    /** Logical forwarder instance. */
    get fw(): Forwarder;
    get cOpts(): ConsumerOptions;
    get pOpts(): ProducerOptions;
    /**
     * Retrieve a single piece of Data.
     * @param interest - Interest or Interest name.
     * @deprecated Use {@link consume} standalone function.
     */
    consume(interest: Interest | NameLike, opts?: ConsumerOptions): ConsumerContext;
    /**
     * Start a producer.
     * @param prefix - Prefix registration; if `undefined`, prefixes may be added later.
     * @param handler - Function to handle incoming Interest.
     * @deprecated Use {@link produce} standalone function.
     */
    produce(prefix: NameLike | undefined, handler: ProducerHandler, opts?: ProducerOptions): Producer;
}
export declare namespace Endpoint {
    /**
     * Delete default Forwarder instance (mainly for unit testing).
     * @deprecated Use `Forwarder.deleteDefault`.
     */
    const deleteDefaultForwarder: typeof Forwarder.deleteDefault;
    /**
     * Describe how to derive route announcement from name prefix in {@link Endpoint.produce}.
     * @deprecated Use `ProducerOptions.RouteAnnouncement`.
     */
    type RouteAnnouncement = ProducerOptions.RouteAnnouncement;
}
