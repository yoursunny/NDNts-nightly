/// <reference types="node" />
import { CopyOptions } from "./copy";
import type * as S from "./data-store";
/** Accept packets into DataStore via bulk insertion protocol. */
export declare class BulkInsertTarget {
    private readonly store;
    private readonly opts?;
    static create<InsertOptions extends {}>(store: S.Insert<InsertOptions>, opts?: CopyOptions & InsertOptions): BulkInsertTarget;
    private constructor();
    accept(stream: NodeJS.ReadableStream): Promise<void>;
}
