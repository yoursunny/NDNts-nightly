/// <reference types="node" />
import { type CopyOptions } from "./copy.js";
import type * as S from "./data-store.js";
/** Accept packets into DataStore via bulk insertion protocol. */
export declare class BulkInsertTarget {
    private readonly store;
    private readonly opts?;
    static create<InsertOptions extends {}>(store: S.Insert<InsertOptions>, opts?: CopyOptions & InsertOptions): BulkInsertTarget;
    private constructor();
    /**
     * Accept bulk insertion from a stream of Data packets.
     * @param stream - Input stream.
     * @returns Promise that resolves to number of Data packets inserted, when `stream` has ended.
     */
    accept(stream: NodeJS.ReadableStream): Promise<number>;
}
