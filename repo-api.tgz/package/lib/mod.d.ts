export * from "./bulk-insert-initiator.js";
export * from "./bulk-insert-target.js";
export * from "./copy.js";
export * from "./data-tape.js";
export * from "./respond-rdr.js";
/**
 * Namespace consists of interfaces that form the DataStore API.
 *
 * @remarks
 * Each DataStore implementation may support a subset of DataStore API. The supported methods
 * are expressed as a union of these interfaces.
 *
 * There isn't a `.close()` method. A DataStore may implement `Disposable` or `AsyncDisposable`
 * if it should be explicitly closed.
 */
import * as DataStore from "./data-store.js"; export { DataStore };
