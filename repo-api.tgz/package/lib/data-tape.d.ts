import { Data, type Interest, type Name } from "@ndn/packet";
import * as S from "./data-store.js";
/**
 * DataTape is a file or stream that consists of a sequence of Data packets.
 * This type implements DataStore interfaces on top of such a file or stream.
 */
export declare class DataTape implements DataTape.Reader, DataTape.Writer {
    /**
     * Constructor.
     * @param stream - Stream or how to open the stream.
     *
     * @remarks
     * `stream` could be:
     * - a readable/writable stream;
     * - a function to (re)open the stream;
     * - a filename.
     *
     * {@link DataTape.Reader} methods are available only if the stream is readable.
     * {@link DataTape.Writer} methods are available only if the stream is writable.
     *
     * If `stream` is a stream instance, it allows either one read or multiple writes.
     * If `stream` is an opener function or filename, it allows multiple reads and writes.
     * Function calls must be sequenced because this type is non-thread-safe.
     */
    constructor(stream: NodeJS.ReadableStream | NodeJS.WritableStream | DataTape.OpenStream | string);
    private readonly makeStream;
    private readonly mutex;
    private currentWriter?;
    private closeCurrentWriter;
    private useReader;
    private useWriter;
    listNames(prefix?: Name): AsyncIterable<Name>;
    listData(prefix?: Name): AsyncIterable<Data>;
    private findFirst;
    get(name: Name): Promise<Data | undefined>;
    find(interest: Interest): Promise<Data | undefined>;
    insert(...args: S.Insert.Args<{}>): Promise<void>;
    [Symbol.asyncDispose](): Promise<void>;
}
export declare namespace DataTape {
    /** Desired mode of opening a stream. */
    type StreamMode = "read" | "append";
    /** Function to open a stream for use by DataTape. */
    type OpenStream = (mode: StreamMode) => NodeJS.ReadableStream | NodeJS.WritableStream;
    /** Interface of {@link DataTape} read operations. */
    type Reader = S.ListNames & S.ListData & S.Get & S.Find & AsyncDisposable;
    /** Interface of {@link DataTape} write operations. */
    type Writer = S.Insert & AsyncDisposable;
}
