/// <reference types="node" />
import { Data, Interest, Name } from "@ndn/packet";
import * as S from "./data-store";
/**
 * DataTape is a file or stream that consists of a sequence of Data packets.
 * This type implements DataStore interfaces on top of such a file or stream.
 */
export declare class DataTape implements S.Close, S.ListNames, S.ListData, S.Get, S.Find, S.Insert {
    /**
     * Constructor.
     * @param stream a readable/writable stream, a function to (re)open the stream, or a filename.
     *
     * If stream is a stream (instead of a function or a filename), only one method may be called once.
     * Otherwise, methods can be called, but they must be sequenced because this type is non-thread-safe.
     *
     * DataTape.Reader methods are available only if the stream is readable.
     * DataTape.Writer methods are available only if the stream is writable.
     */
    constructor(stream: NodeJS.ReadableStream | NodeJS.WritableStream | DataTape.OpenStream | string);
    private readonly makeStream;
    private readonly mutex;
    private currentWriter?;
    private closeCurrentWriter;
    private useReader;
    private useWriter;
    listNames(prefix?: Name): AsyncIterable<Name>;
    listData(prefix?: Name): AsyncIterable<Data>;
    private findFirst;
    get(name: Name): Promise<Data | undefined>;
    find(interest: Interest): Promise<Data | undefined>;
    close(): Promise<void>;
    insert(...args: S.Insert.Args<{}>): Promise<void>;
}
export declare namespace DataTape {
    type StreamMode = "read" | "append";
    type OpenStream = (mode: StreamMode) => NodeJS.ReadableStream | NodeJS.WritableStream;
}
