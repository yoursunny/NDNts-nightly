import type { Data, Interest, Name } from "@ndn/packet";
import * as S from "./data-store.js";
/**
 * Data packet storage based on array.
 *
 * @remarks
 * This is a minimal implementation of DataStore interfaces. It has small code size but every
 * operation has O(N) time complexity.
 */
export declare class DataArray implements S.ListNames, S.ListData, S.Get, S.Find, S.Insert, S.Delete {
    private array;
    listNames(prefix?: Name): AsyncIterable<Name>;
    listData(prefix?: Name): AsyncIterable<Data>;
    get(name: Name): Promise<Data | undefined>;
    find(interest: Interest): Promise<Data | undefined>;
    insert(...args: S.Insert.Args<{}>): Promise<void>;
    delete(...names: readonly Name[]): Promise<void>;
}
