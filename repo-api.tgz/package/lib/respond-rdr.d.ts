import { type Data, type Interest, type NamingConvention, type Signer } from "@ndn/packet";
import type * as S from "./data-store.js";
/**
 * Respond to RDR discovery Interest with RDR metadata describing the latest version
 * among stored Data.
 */
export declare function respondRdr(interest: Interest, store: S.ListNames, { versionConvention, signer, }?: respondRdr.Options): Promise<Data | undefined>;
export declare namespace respondRdr {
    interface Options {
        /**
         * Version naming convention.
         * @defaultValue `Version3`
         */
        versionConvention?: NamingConvention<any, number>;
        /**
         * Data signer.
         * @defaultValue digestSigning
         */
        signer?: Signer;
    }
}
