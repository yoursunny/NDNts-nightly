import { Data, Interest, NamingConvention, Signer } from "@ndn/packet";
import type * as S from "./data-store";
/**
 * Respond to RDR discovery Interest with RDR metadata describing the latest version
 * among stored Data.
 */
export declare function respondRdr(interest: Interest, store: S.ListNames, { versionConvention, signer, }?: respondRdr.Options): Promise<Data | undefined>;
export declare namespace respondRdr {
    interface Options {
        versionConvention?: NamingConvention<any, number>;
        signer?: Signer;
    }
}
