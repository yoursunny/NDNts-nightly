import { Data, type Interest, type Name } from "@ndn/packet";
import type { AnyIterable } from "streaming-iterables";
/** DataStore interface, listNames method. */
export interface ListNames {
    /** List Data names, optionally filtered by name prefix. */
    listNames: (prefix?: Name) => AsyncIterable<Name>;
}
/** DataStore interface, listData method. */
export interface ListData {
    /** List Data packets, optionally filtered by name prefix. */
    listData: (prefix?: Name) => AsyncIterable<Data>;
}
/** DataStore interface, get method. */
export interface Get {
    /** Retrieve Data by exact name. */
    get: (name: Name) => Promise<Data | undefined>;
}
/** DataStore interface, find method. */
export interface Find {
    /** Find Data that satisfies Interest. */
    find: (interest: Interest) => Promise<Data | undefined>;
}
/** DataStore interface, insert method. */
export interface Insert<Options extends {} = {}> {
    /**
     * Insert one or more Data packets.
     *
     * @remarks
     * Arguments include:
     * - an optional Options object
     * - zero or more Data, Iterable<Data>, or AsyncIterable<Data>
     */
    insert: (...args: Insert.Args<Options>) => Promise<void>;
}
export declare namespace Insert {
    type Tail = ReadonlyArray<Data | AnyIterable<Data>>;
    export type Args<O extends {}> = [...(Record<string, unknown> extends O ? [O] | [] : []), ...Tail];
    /** Normalize {@link Insert.insert} arguments. */
    export interface ParsedArgs<O> {
        /** Options object. */
        readonly opts?: O;
        /** All Data packets, including `singles` and expanded `batches`. */
        readonly pkts: AsyncIterable<Data>;
        /** Singular Data packets only. */
        readonly singles: Data[];
        /** Batches only. */
        readonly batches: Array<AnyIterable<Data>>;
    }
    /** Normalize {@link Insert.insert} arguments. */
    export function parseArgs<O extends {}>(args: Args<O>): ParsedArgs<O>;
    export {};
}
/** DataStore interface, delete method. */
export interface Delete {
    /** Delete Data packets with given names. */
    delete: (...names: readonly Name[]) => Promise<void>;
}
