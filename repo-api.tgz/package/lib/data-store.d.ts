import { Data, Interest, Name } from "@ndn/packet";
import type { AnyIterable } from "streaming-iterables";
export interface Close {
    /** Close the store. */
    close: () => Promise<void>;
}
export interface ListNames {
    /** List Data names, optionally filtered by name prefix. */
    listNames: (prefix?: Name) => AsyncIterable<Name>;
}
export interface ListData {
    /** List Data packets, optionally filtered by name prefix. */
    listData: (prefix?: Name) => AsyncIterable<Data>;
}
export interface Get {
    /** Retrieve Data by exact name. */
    get: (name: Name) => Promise<Data | undefined>;
}
export interface Find {
    /** Find Data that satisfies Interest. */
    find: (interest: Interest) => Promise<Data | undefined>;
}
export interface Insert<Options extends {} = {}> {
    /**
     * Insert one or more Data packets.
     *
     * Arguments include:
     * - an optional Options object
     * - zero or more Data, Iterable<Data>, or AsyncIterable<Data>
     */
    insert: (...args: Insert.Args<Options>) => Promise<void>;
}
export declare namespace Insert {
    type Args<O extends {}> = [...(object extends O ? [O] | [] : []), ...Array<Data | AnyIterable<Data>>];
    interface ParsedArgs<O> {
        readonly opts?: O;
        readonly pkts: AsyncIterable<Data>;
        readonly singles: Data[];
        readonly batches: Array<AnyIterable<Data>>;
    }
    function parseArgs<O>(args: Args<O>): ParsedArgs<O>;
}
export interface Delete {
    /** Delete Data packets with given names. */
    delete: (...names: Name[]) => Promise<void>;
}
