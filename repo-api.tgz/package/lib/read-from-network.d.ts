import { type ConsumerOptions } from "@ndn/endpoint";
import { type Data, Interest, type Name } from "@ndn/packet";
import type * as S from "./data-store.js";
/** Implement DataStore read-side interfaces by sending Interests to the network. */
export declare class ReadFromNetwork implements S.Get, S.Find {
    private readonly cOpts?;
    constructor(cOpts?: ConsumerOptions | undefined);
    get(name: Name): Promise<Data | undefined>;
    find(interest: Interest): Promise<Data | undefined>;
    /**
     * Extend a write-only DataStore with read methods.
     * @param inner - Inner DataStore that does not support reading.
     * @returns Readable DataStore.
     */
    mix<T extends {}>(inner: T): T & S.Get & S.Find;
}
