import { L3Face } from "@ndn/l3face";
import * as S from "./data-store";
/** Send packets to a bulk insertion target. */
export declare class BulkInsertInitiator implements S.Close, S.Insert {
    private readonly jobs;
    private readonly faceTx;
    constructor(face: L3Face);
    close(): Promise<void>;
    /**
     * Send packets to the target.
     *
     * A resolved Promise means the packets are scheduled for transmission.
     * It does not imply the target has received or accepted these packets.
     */
    insert(...args: S.Insert.Args<{}>): Promise<void>;
    private tx;
}
