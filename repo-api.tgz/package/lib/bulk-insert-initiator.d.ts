import { Transport } from "@ndn/l3face";
import { TypedEventTarget } from "typescript-event-target";
import * as S from "./data-store.js";
type EventMap = {
    /** Emitted when the transport TX side has an error. */
    error: CustomEvent<Error>;
};
/** Send packets to a bulk insertion target. */
export declare class BulkInsertInitiator extends TypedEventTarget<EventMap> implements S.Insert, AsyncDisposable {
    /**
     * Constructor.
     * @param tr - Transport connected to bulk insertion target.
     * Typically, this is a subclass of {@link \@ndn/l3face!Transport}. The RX side is opened and
     * any received packets are discarded. The outgoing Data packet stream is passed to TX side.
     * If the transport has a finite MTU, any Data packets exceeding MTU are silently dropped.
     *
     * You can connect to repo-ng or ndn-python-repo by creating a TCP transport with
     * {@link \@ndn/node-transport!TcpTransport.connect}. However, it is recommended to use
     * {@link \@ndn/pyrepo!PyRepoClient} for inserting Data into ndn-python-repo.
     */
    constructor(tr: Pick<Transport, "tx">);
    private readonly mtu;
    private readonly queue;
    private readonly transportTx;
    /**
     * Finish insertion and close the connection to the target.
     *
     * @remarks
     * `.insert()` cannot be called after this.
     */
    [Symbol.asyncDispose](): Promise<void>;
    /**
     * Send packets to the target.
     * @returns Promise that resolves when the packets are scheduled for transmission.
     * It does not imply the target has received or accepted these packets.
     */
    insert(...args: S.Insert.Args<{}>): Promise<void>;
    private tx;
}
export {};
