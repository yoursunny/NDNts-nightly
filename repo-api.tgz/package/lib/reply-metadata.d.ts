import { type Data, type Interest, type NamingConvention, type Signer } from "@ndn/packet";
import type * as S from "./data-store.js";
/**
 * Respond to metadata discovery Interest with metadata packet describing the latest version
 * among stored Data.
 */
export declare function replyMetadata(interest: Interest, store: S.ListNames, { versionConvention, signer, }?: replyMetadata.Options): Promise<Data | undefined>;
export declare namespace replyMetadata {
    interface Options {
        /**
         * Version naming convention.
         * @defaultValue `Version3`
         */
        versionConvention?: NamingConvention<any, number>;
        /**
         * Data signer.
         * @defaultValue digestSigning
         */
        signer?: Signer;
    }
}
