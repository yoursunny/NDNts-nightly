import { Name } from "@ndn/packet";
import * as S from "./data-store";
export interface CopyOptions {
    /** Number of packets per transaction. Default is 64. */
    batch?: number;
    /** Maximum parallel transactions. Default is 1. */
    parallel?: number;
}
/**
 * Copy Data packets from source DataStore to destination DataStore.
 * @param src source DataStore.
 * @param prefix name prefix to select Data packets.
 * @param dst destination DataStore.
 * @param opts insert options and copy batching options.
 */
export declare function copy<InsertOptions extends {} = never>(src: S.ListData, prefix: Name, dst: S.Insert<InsertOptions>, opts?: CopyOptions & InsertOptions): Promise<void>;
export declare function copy<InsertOptions extends {} = never>(src: S.ListData, dst: S.Insert<InsertOptions>, opts?: CopyOptions & InsertOptions): Promise<void>;
