import { Name } from "@ndn/packet";
import type * as S from "./data-store.js";
/** {@link copy} options. */
export interface CopyOptions {
    /**
     * Number of packets per transaction.
     * @defaultValue 64
     */
    batch?: number;
    /**
     * Maximum parallel transactions.
     * @defaultValue 1
     */
    parallel?: number;
}
/**
 * Copy Data packets from source DataStore to destination DataStore.
 * @param src - Source DataStore.
 * @param prefix - Filter Data packets by name prefix.
 * @param dst - Destination DataStore.
 * @param opts - Insert options and copy batching options.
 * @returns Number of Data packets copied.
 */
export declare function copy<InsertOptions extends {} = never>(src: S.ListData, prefix: Name, dst: S.Insert<InsertOptions>, opts?: CopyOptions & InsertOptions): Promise<number>;
export declare function copy<InsertOptions extends {} = never>(src: S.ListData, dst: S.Insert<InsertOptions>, opts?: CopyOptions & InsertOptions): Promise<number>;
