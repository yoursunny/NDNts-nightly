import type { DataTape } from "./data-tape.js";
export declare function makeOpenFileStreamFunction(filename: string): DataTape.OpenStream;
