import type { DataTape } from "./data-tape";
export declare function makeOpenFileStreamFunction(filename: string): DataTape.OpenStream;
