import type { DataTape } from "./data-tape.js";
export declare function makeOpenFileStreamFunction(_filename: string): DataTape.OpenStream;
