import { Component } from "@ndn/packet";
export declare const TT: {
    readonly StateVector: 201;
    readonly StateVectorEntry: 202;
    readonly SeqNo: 204;
    readonly MappingData: 205;
    readonly MappingEntry: 206;
};
export declare const MappingKeyword: Component;
export declare const Version0: Component;
export declare const ContentTypeEncap = 6;
