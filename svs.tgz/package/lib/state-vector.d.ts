import { Name } from "@ndn/packet";
import { type Decoder, type Encoder } from "@ndn/tlv";
import { KeyMap } from "@ndn/util";
/** SVS state vector. */
export declare class StateVector {
    /**
     * Constructor.
     * @param from - Copy from state vector or its JSON value.
     */
    constructor(from?: StateVector | Record<string, number>);
    /** @internal */
    constructor(from: NodeMap);
    private readonly m;
    /**
     * Get node sequence number.
     * @param id - Name (SVS v2) or Name+bootstrapTime (SVS v3).
     *
     * @remarks
     * If the node does not exist, returns zero.
     */
    get(id: Name | StateVector.ID): number;
    /**
     * Get node entry.
     * @param id - Name (SVS v2) or Name+bootstrapTime (SVS v3).
     *
     * @remarks
     * If the node does not exist, returns an entry with seqNum=0.
     */
    getEntry(id: Name | StateVector.ID): StateVector.NodeEntry;
    /**
     * Set node sequence number or entry.
     * @param id - Name (SVS v2) or Name+bootstrapTime (SVS v3).
     * @param entry -
     * If specified as number, it's interpreted as sequence number, and `performance.now()` is used
     * as lastUpdate. Otherwise, it's used as the node entry.
     *
     * @remarks
     * Setting sequence number to zero removes the node.
     */
    set(id: Name | StateVector.ID, entry: number | StateVector.NodeEntry): void;
    /** Iterate over nodes and their sequence numbers. */
    [Symbol.iterator](): IterableIterator<[id: Name & StateVector.ID, seqNum: number]>;
    /** Return maximum bootstrap timestamp. */
    get maxBoot(): number;
    private iterOlderThan;
    /** List nodes with older sequence number in this state vector than other. */
    listOlderThan(other: StateVector): StateVector.DiffEntry[];
    /** Update this state vector to have newer sequence numbers between this and other. */
    mergeFrom(other: StateVector, lastUpdate?: number): void;
    /** Serialize as JSON. */
    toJSON(): Record<string, number>;
    /** Encode StateVector TLV. */
    encodeTo(encoder: Encoder, version?: 2 | 3): void;
    private svs2EncodeValue;
    private svs3EncodeValue;
    /** Decode StateVector TLV. */
    static decodeFrom(decoder: Decoder): StateVector;
}
export declare namespace StateVector {
    /** Node identifier. */
    interface ID {
        /** Node prefix. */
        name: Name;
        /**
         * Node bootstrap timestamp, seconds since Unix epoch (SVS v3).
         *
         * This field shall be set to -1 for SVS v2 nodes.
         */
        boot: number;
    }
    /** Per-node entry. */
    interface NodeEntry {
        /** Current sequence number (positive integer). */
        seqNum: number;
        /** Last update timestamp (from `performance.now()`). */
        lastUpdate: number;
    }
    /** Result of {@link StateVector.listOlderThan}. */
    interface DiffEntry {
        /** Node ID. */
        id: Name & ID;
        /** Low sequence number (inclusive). */
        loSeqNum: number;
        /** High sequence number (inclusive). */
        hiSeqNum: number;
    }
}
export declare class IDImpl extends Name implements StateVector.ID {
    readonly boot: number;
    constructor(name: Name, boot?: number);
    get name(): Name;
}
export declare function makeIDImpl(input: Name | StateVector.ID): IDImpl;
declare function mapKeyOf(id: Name | StateVector.ID): string;
declare class NodeMap extends KeyMap<IDImpl, StateVector.NodeEntry, string, Parameters<typeof mapKeyOf>[0]> {
    constructor();
}
export {};
