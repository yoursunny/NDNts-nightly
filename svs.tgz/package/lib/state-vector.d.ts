import { Name } from "@ndn/packet";
import { type Decoder, type Encoder } from "@ndn/tlv";
/** SVS state vector. */
export declare class StateVector {
    /**
     * Constructor.
     * @param from - Copy from state vector or its JSON value.
     * @param lastUpdate - Initial lastUpdate value for each node entry.
     */
    constructor(from?: StateVector | Record<string, number>, lastUpdate?: number);
    private readonly m;
    /**
     * Get node sequence number.
     *
     * @remarks
     * If the node does not exist, returns zero.
     */
    get(id: Name): number;
    /**
     * Get node entry.
     *
     * @remarks
     * If the node does not exist, returns an entry with seqNum=0.
     */
    getEntry(id: Name): StateVector.NodeEntry;
    /**
     * Set node sequence number or entry.
     * @param entry -
     * If specified as number, it's interpreted as sequence number, and `Date.now()` is used as
     * lastUpdate. Otherwise, it's used as the node entry.
     *
     * @remarks
     * Setting sequence number to zero removes the node.
     */
    set(id: Name, entry: number | StateVector.NodeEntry): void;
    /** Iterate over nodes and their sequence numbers. */
    [Symbol.iterator](): IterableIterator<[id: Name, seqNum: number]>;
    private iterOlderThan;
    /** List nodes with older sequence number in this state vector than other. */
    listOlderThan(other: StateVector): StateVector.DiffEntry[];
    /** Update this state vector to have newer sequence numbers between this and other. */
    mergeFrom(other: StateVector, lastUpdate?: number): void;
    /** Serialize as JSON. */
    toJSON(): Record<string, number>;
    /** Encode StateVector TLV. */
    encodeTo(encoder: Encoder): void;
    /** Decode StateVector TLV. */
    static decodeFrom(decoder: Decoder): StateVector;
}
export declare namespace StateVector {
    /**
     * StateVector TLV-TYPE.
     *
     * @remarks
     * SVS v1 encodes StateVector as a name component of this type.
     * SVS v2 encodes StateVector as a sub-element of this type within AppParameters.
     */
    const Type: 201;
    /** Per-node entry. */
    interface NodeEntry {
        /** Current sequence number (positive integer). */
        seqNum: number;
        /** Last update timestamp (from `Date.now()`). */
        lastUpdate: number;
    }
    /** Result of {@link StateVector.listOlderThan}. */
    interface DiffEntry {
        /** Node ID. */
        id: Name;
        /** Low sequence number (inclusive). */
        loSeqNum: number;
        /** High sequence number (inclusive). */
        hiSeqNum: number;
    }
}
