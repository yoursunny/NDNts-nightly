import { type ProducerOptions } from "@ndn/endpoint";
import { Name, type NameLike, type Signer } from "@ndn/packet";
import type { DataStore as S } from "@ndn/repo-api";
import { MappingEntry } from "./mapping-entry.js";
import type { SvSync } from "./sync.js";
/** SVS-PS publisher. */
export declare class SvPublisher {
    constructor({ pOpts, sync, id, store, chunkSize, innerSigner, outerSigner, mappingSigner, }: SvPublisher.Options);
    private readonly node;
    private readonly nodeMutex;
    private readonly nodeSyncPrefix;
    private readonly store;
    private readonly chunkOptions;
    private readonly innerSigner;
    private readonly outerSigner;
    private readonly outerProducer;
    private readonly mappingProducer;
    /** Publisher node ID. */
    get id(): Name;
    /**
     * Stop publisher operations.
     *
     * @remarks
     * This does not stop the {@link SvSync} instance or the {@link SvPublisher.DataStore}.
     */
    close(): Promise<void>;
    /**
     * Publish application data.
     * @param name - Application-specified inner name.
     * @param payload - Application payload.
     * @param entry - MappingEntry for subscriber-side filtering.
     * This is required if subscribers are expecting a certain MappingEntry subclass.
     * @returns seqNum.
     */
    publish(name: NameLike, payload: Uint8Array, entry?: MappingEntry): Promise<number>;
    private publishInner;
    private readonly handleOuter;
    private readonly handleMapping;
}
export declare namespace SvPublisher {
    /**
     * Data repository used by publisher.
     *
     * @remarks
     * Possible implementations include but are not limited to:
     * - {@link \@ndn/repo!DataStore} (faster, disk-persistency option, larger code size)
     * - {@link \@ndn/repo-api!DataArray} (slower, in-memory only, smaller code size)
     */
    type DataStore = S.Get & S.Find & S.Insert;
    interface Options {
        /**
         * Producer options.
         *
         * @remarks
         * - `.describe` is overridden as "SVS-PS" + prefix.
         * - `.dataSigner` is overridden.
         */
        pOpts?: ProducerOptions;
        /**
         * SvSync instance.
         *
         * @remarks
         * Multiple {@link SvSubscriber}s and {@link SvPublisher}s may reuse the same SvSync instance.
         * However, publications from a publisher cannot reach subscribers on the same SvSync instance.
         */
        sync: SvSync;
        /**
         * Publisher node ID.
         *
         * @remarks
         * Each publisher must have a unique node ID.
         */
        id: Name;
        /** Data repository used for this publisher. */
        store: DataStore;
        /**
         * Segment chunk size of inner Data packet.
         * @defaultValue 8000
         */
        chunkSize?: number;
        /**
         * Inner Data signer.
         * @defaultValue nullSigner
         */
        innerSigner?: Signer;
        /**
         * Outer Data signer.
         * @defaultValue nullSigner
         */
        outerSigner?: Signer;
        /**
         * Mapping Data signer.
         * @defaultValue nullSigner
         */
        mappingSigner?: Signer;
    }
}
