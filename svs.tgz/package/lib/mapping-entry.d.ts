import { Name } from "@ndn/packet";
import { type Decodable, type Decoder, type Encodable, type EncodableObj, type Encoder, Extensible, ExtensionRegistry } from "@ndn/tlv";
/** SVS-PS MappingEntry element. */
export declare class MappingEntry implements EncodableObj {
    seqNum: number;
    name: Name;
    static decodeFrom(decoder: Decoder): MappingEntry;
    encodeTo(encoder: Encoder): void;
    protected encodeValueExt(): Encodable[];
}
export declare namespace MappingEntry {
    interface Constructor<M extends MappingEntry = MappingEntry> extends Decodable<M> {
        new (): M;
    }
    /** Class decorator on an extensible MappingEntry subclass. */
    function extend<M extends MappingEntry & Extensible>(ctor: new () => M, ctx?: ClassDecoratorContext): void;
}
/** SVS-PS MappingEntry with Timestamp element. */
export declare class TimedMappingEntry extends MappingEntry implements Extensible {
    constructor();
    readonly [Extensible.TAG]: ExtensionRegistry<Extensible>;
    timestamp: Date;
}
