import { Forwarder } from "@ndn/fw";
import { Interest, Name, type NameLike, type Signer, type Verifier } from "@ndn/packet";
import { type SyncNode, type SyncProtocol } from "@ndn/sync-api";
import type { Promisable } from "type-fest";
import { TypedEventTarget } from "typescript-event-target";
import { StateVector } from "./state-vector.js";
interface DebugEntry {
    action: string;
    own: Record<string, number>;
    recv?: Record<string, number>;
    state: string;
    nextState?: string;
    ourOlder?: number;
    ourNewer?: number;
}
type EventMap = SyncProtocol.EventMap<Name> & {
    debug: CustomEvent<DebugEntry>;
    rxerror: CustomEvent<[interest: Interest, e: unknown]>;
};
/** StateVectorSync participant. */
export declare class SvSync extends TypedEventTarget<EventMap> implements SyncProtocol<Name> {
    readonly syncPrefix: Name;
    readonly describe: string;
    private readonly own;
    private readonly svs2interest;
    private readonly steadyTimer;
    private readonly suppressionTimer;
    private readonly svs2suppressionPeriod;
    static create({ syncPrefix, fw, describe, initialStateVector, initialize, syncInterestLifetime, svs2interest, steadyTimer, periodicTimeout, svs2suppression, suppressionTimer, suppressionPeriod, suppressionTimeout, signer, verifier, }: SvSync.Options): Promise<SvSync>;
    private constructor();
    private makeFace;
    private readonly maybeHaveEventListener;
    private face?;
    private txStream;
    /**
     * In steady state, undefined.
     * In suppression state, aggregated state vector of incoming sync Interests.
     */
    private aggregated?;
    /** Sync Interest timer. */
    private timer;
    private debug;
    /** Cease operations. */
    close(): void;
    get(id: NameLike): SyncNode<Name>;
    add(id: NameLike): SyncNode<Name>;
    /**
     * Obtain a copy of own state vector.
     *
     * @remarks
     * This may be used as {@link SvSync.Options.initialStateVector} to re-create an SvSync instance.
     */
    get currentStateVector(): StateVector;
    /**
     * Multi-purpose callback passed to {@link SvSyncNode} constructor.
     *
     * @remarks
     * - `nodeOp(id)`: get seqNum
     * - `nodeOp(id, n)`: set seqNum, return new seqNum
     * - `nodeOp(id, 0)`: delete node during initialization
     */
    private readonly nodeOp;
    /**
     * Handle incoming sync Interest.
     * @param interest - Received Interest, signature verified.
     */
    private handleSyncInterest;
    private shouldEnterSuppression;
    private resetTimer;
    private readonly handleTimer;
    /** Transmit a sync Interest. */
    private sendSyncInterest;
}
export declare namespace SvSync {
    /** {@link SvSync.create} options. */
    interface Options {
        /** Sync group prefix. */
        syncPrefix: Name;
        /**
         * Use the specified logical forwarder.
         * @defaultValue `Forwarder.getDefault()`
         */
        fw?: Forwarder;
        /** Description for debugging purpose. */
        describe?: string;
        /**
         * Initial state vector.
         * @defaultValue empty state vector
         */
        initialStateVector?: StateVector;
        /**
         * Application initialization function.
         *
         * @remarks
         * During initialization, it's possible to remove SyncNode or decrease seqNum.
         * Calling `sync.close()` has no effect.
         *
         * Sync protocol starts running after the returned Promise is resolved.
         */
        initialize?: (sync: SvSync) => Promisable<void>;
        /**
         * Sync Interest lifetime in milliseconds.
         * @defaultValue 1000
         */
        syncInterestLifetime?: number;
        /**
         * Encode sync Interest in SVS v2 format.
         * @defaultValue false
         * @experimental
         */
        svs2interest?: boolean;
        /**
         * Sync Interest timer in steady state (SVS v1).
         * @defaultValue `[30000ms, ±10%]`
         * @remarks
         * - median: median interval in milliseconds.
         * - jitter: ± percentage, in [0.0, 1.0) range.
         */
        steadyTimer?: [median: number, jitter: number];
        /**
         * Sync Interest timer in steady state (SVS v2).
         * @defaultValue `[30000ms, ±10%]`
         * @remarks
         * If specified as tuple,
         * - median: median interval in milliseconds.
         * - jitter: ± percentage, in [0.0, 1.0) range.
         *
         * If specified as number, it's interpreted as median.
         *
         * SVS v1 `steadyTimer` and SVS v2 `periodicTimeout` are equivalent.
         * If both are specified, this option takes precedence.
         * @experimental
         */
        periodicTimeout?: number | [median: number, jitter: number];
        /**
         * Use SVS v2 suppression timer and suppression logic.
         * @defaultValue false
         * @experimental
         */
        svs2suppression?: boolean;
        /**
         * Sync Interest timer in suppression state (SVS v1).
         * @defaultValue `[200ms, ±50%]`
         * @remarks
         * - median: median interval in milliseconds.
         * - jitter: ± percentage, in [0.0, 1.0) range.
         *
         * This option takes effect only if `.svs2suppression` is false.
         */
        suppressionTimer?: [median: number, jitter: number];
        /**
         * Sync Interest timer in suppression state, maximum value (SVS v2).
         * @defaultValue `200ms`
         * @experimental
         */
        suppressionPeriod?: number;
        /**
         * Sync Interest timer in suppression state, value generator (SVS v2).
         * @defaultValue `SvSync.suppressionExpDelay(suppressionPeriod)`
         * @remarks
         * The maximum value returned by the generator function should be `suppressionPeriod`.
         *
         * This option takes effect only if `.svs2suppression` is true.
         * @experimental
         */
        suppressionTimeout?: () => number;
        /**
         * Sync Interest signer.
         * @defaultValue nullSigner
         */
        signer?: Signer;
        /**
         * Sync Interest verifier.
         * @defaultValue no verification
         */
        verifier?: Verifier;
    }
    /**
     * SVS v2 suppression timeout exponential decay function.
     * @param c - Constant factor.
     * @param f - Decay factor.
     * @returns Function to generate suppression timeout values.
     * @experimental
     */
    function suppressionExpDelay(c: number, f?: number): () => number;
}
export {};
