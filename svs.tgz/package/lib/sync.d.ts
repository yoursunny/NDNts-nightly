import { Forwarder } from "@ndn/fw";
import { Interest, Name, type NameLike, type NamingConvention, type Signer, type Verifier } from "@ndn/packet";
import { type SyncNode, type SyncProtocol } from "@ndn/sync-api";
import type { Promisable } from "type-fest";
import { TypedEventTarget } from "typescript-event-target";
import { StateVector } from "./state-vector.js";
interface DebugEntry {
    action: string;
    own: Record<string, number>;
    recv?: Record<string, number>;
    state: string;
    nextState?: string;
    ourOlder?: number;
    ourNewer?: number;
}
type EventMap = SyncProtocol.EventMap<SvSync.ID> & {
    debug: CustomEvent<DebugEntry>;
    rxerror: CustomEvent<[interest: Interest, e: unknown]>;
};
export declare const conventionSeqNum: unique symbol;
/** StateVectorSync participant. */
export declare class SvSync extends TypedEventTarget<EventMap> implements SyncProtocol<SvSync.ID> {
    private readonly svs3;
    readonly groupPrefix: Name;
    readonly describe: string;
    private readonly own;
    private readonly syncInterestLifetime;
    private readonly steadyTimer;
    private readonly suppressionTimer;
    private readonly suppressionPeriod;
    private readonly signer;
    private readonly verifier;
    static create({ groupPrefix, fw, describe, initialStateVector, initialize, syncInterestLifetime, periodicTimeout, suppressionPeriod, suppressionTimeout, signer, verifier, svs3, }: SvSync.Options): Promise<SvSync>;
    private constructor();
    private makeFace;
    private readonly maybeHaveEventListener;
    private face?;
    private readonly syncDataName;
    private txStream;
    /**
     * In steady state, undefined.
     * In suppression state, aggregated state vector of incoming sync Interests.
     */
    private aggregated?;
    /** Sync Interest timer. */
    private timer;
    private debug;
    /** Cease operations. */
    close(): void;
    /**
     * Retrieve or create sync node by name.
     *
     * For SVS v2, retrieve or create sync node with specified name.
     *
     * For SVS v3, retrieve sync node with specified name and most recent bootstrap time.
     * If no sync node with this name exists, create sync node with current time as bootstrap time.
     */
    get(name: NameLike): SvSync.Node;
    /** Retrieve or create sync node by name and bootstrap time (SVS v3). */
    get(id: {
        name: NameLike;
        boot: number;
    }): SvSync.Node;
    /** Retrieve or create sync node by name and bootstrap time (SVS v3). */
    get(name: NameLike, boot: number): SvSync.Node;
    /**
     * Retrieve or create sync node by name.
     *
     * For SVS v2, same as `get(name)`.
     *
     * For SVS v3, create sync node with specified name and current bootstrap time.
     * Note the different between `get(name)` and `add(name)`:
     * - `get(name)` searches for existing sync nodes with specified name first.
     * - `add(name)` almost always creates a new sync node.
     */
    add(name: NameLike): SvSync.Node;
    /** Same as `get(id)` (SVS v3). */
    add(id: {
        name: NameLike;
        boot: number;
    }): SvSync.Node;
    /** Same as `get(name, boot)` (SVS v3). */
    add(name: NameLike, boot: number): SvSync.Node;
    private findByName;
    /**
     * Obtain a copy of own state vector.
     *
     * @remarks
     * This may be used as {@link SvSync.Options.initialStateVector} to re-create an SvSync instance.
     */
    get currentStateVector(): StateVector;
    /**
     * Multi-purpose callback passed to {@link SvSyncNode} constructor.
     *
     * @remarks
     * - `nodeOp(id, "G") => number`: getSeqNum
     * - `nodeOp(id, positive)`: setSeqNum
     * - `nodeOp(id, 0)`: delete node during initialization
     * - `nodeOp(id, "P") => number`: dataInterestPrefix
     * - `nodeOp(id, negative) => Name`: buildDataInterestName
     */
    private readonly nodeOp;
    get [conventionSeqNum](): NamingConvention<number>;
    private readonly handleRxPacket;
    /**
     * Parse and verify incoming sync Interest.
     * @param interest - Received Interest.
     */
    private parseSyncInterest;
    /**
     * Handle incoming state vector.
     * @param recv - Received StateVector.
     */
    private handleRecv;
    private shouldEnterSuppression;
    private resetTimer;
    private readonly handleTimer;
    /** Transmit a sync Interest. */
    private sendSyncInterest;
}
export declare namespace SvSync {
    /** {@link SvSync.create} options. */
    interface Options {
        /** Sync group prefix. */
        groupPrefix: Name;
        /**
         * Use the specified logical forwarder.
         * @defaultValue `Forwarder.getDefault()`
         */
        fw?: Forwarder;
        /** Description for debugging purpose. */
        describe?: string;
        /**
         * Initial state vector.
         * @defaultValue empty state vector
         */
        initialStateVector?: StateVector;
        /**
         * Application initialization function.
         *
         * @remarks
         * During initialization, it's possible to remove SyncNode or decrease seqNum.
         * Calling `sync.close()` has no effect.
         *
         * Sync protocol starts running after the returned Promise is resolved.
         */
        initialize?: (sync: SvSync) => Promisable<void>;
        /**
         * Sync Interest lifetime in milliseconds.
         * @defaultValue 1000
         */
        syncInterestLifetime?: number;
        /**
         * Sync Interest timer in steady state.
         * @defaultValue `[30000ms, ±10%]`
         * @remarks
         * If specified as tuple,
         * - median: median interval in milliseconds.
         * - jitter: ± percentage, in [0.0, 1.0) range.
         *
         * If specified as number, it's interpreted as median.
         */
        periodicTimeout?: number | [median: number, jitter: number];
        /**
         * Sync Interest timer in suppression state, maximum value in milliseconds.
         * @defaultValue 200
         */
        suppressionPeriod?: number;
        /**
         * Sync Interest timer in suppression state, value generator.
         * @defaultValue `SvSync.suppressionExpDelay(suppressionPeriod)`
         * @remarks
         * The maximum value returned by the generator function should be `suppressionPeriod`.
         */
        suppressionTimeout?: () => number;
        /**
         * Sync Interest signer (SVS v2).
         * State Vector Data signer (SVS v3).
         * @defaultValue nullSigner
         */
        signer?: Signer;
        /**
         * Sync Interest verifier (SVS v2).
         * State Vector Data verifier (SVS v3).
         * @defaultValue no verification
         */
        verifier?: Verifier;
        /**
         * Enable SVS v3 protocol instead of SVS v2.
         * @defaultValue true
         *
         * @deprecated SVS v2 is deprecated.
         */
        svs3?: boolean;
    }
    /**
     * SVS v3 suppression timeout exponential decay function.
     * @param c - Constant factor, aka SuppressionPeriod.
     * @param f - Decay factor.
     * @returns Function to generate suppression timeout values.
     */
    function suppressionExpDelay(c: number, f?: number): () => number;
    /** Make SVS v3 bootstrap time based on current timestamp. */
    function makeBootstrapTime(now?: number): number;
    /**
     * Sync node ID.
     *
     * For SVS v2, this should be accessed as `Name`.
     * Accessing the object fields would give `{ name, boot: -1 }`.
     *
     * For SVS v3, this should be accessed as `{ name, boot }` object.
     * Accessing as `Name` would return the name only.
     *
     * Note: the `Name` variant will be deleted when SVS v2 support is dropped.
     */
    type ID = Name & StateVector.ID;
    interface Node extends SyncNode<ID> {
        /**
         * Return the prefix for Data Interest Names.
         * See `buildDataInterestName` for the conventions.
         */
        readonly dataInterestPrefix: Name;
        /**
         * Build Data Interest Name for the given sequence number.
         * @param seqNum - Sequence number; omit to obtain the prefix without sequence number.
         *
         * This follows the recommended syntax:
         * - `/<node-prefix>/<group-prefix>/<seq-num>` (SVS v2)
         * - `/<node-prefix>/<group-prefix>/t=<bootstrap-time>/seq=<seq>` (SVS v3)
         */
        buildDataInterestName: (seqNum: number) => Name;
    }
}
export {};
