import { type ConsumerOptions } from "@ndn/endpoint";
import { Name, type Verifier } from "@ndn/packet";
import { type Subscriber, type Subscription } from "@ndn/sync-api";
import { TypedEventTarget } from "typescript-event-target";
import { MappingEntry } from "./mapping-entry.js";
import type { SvSync } from "./sync.js";
type EventMap = {
    error: CustomEvent<Error>;
};
/**
 * SVS-PS subscriber.
 * @typeParam ME - Subclass of MappingEntry.
 * If it is not {@link MappingEntry} base class, its constructor must be specified in
 * {@link SvSubscriber.Options.mappingEntryType}.
 */
export declare class SvSubscriber<ME extends MappingEntry = MappingEntry> extends TypedEventTarget<EventMap> implements Subscriber<Name, SvSubscriber.Update, SvSubscriber.SubscribeInfo<ME>> {
    constructor({ cOpts, sync, retxLimit, mappingBatch, mappingEntryType, mustFilterByMapping, innerVerifier, outerVerifier, mappingVerifier, }: SvSubscriber.Options);
    private readonly abort;
    private readonly syncPrefix;
    private readonly nameSubs;
    private readonly nameFilters;
    private readonly publisherSubs;
    private readonly mappingBatch;
    private readonly mappingEVD;
    private readonly mustFilterByMapping;
    private readonly innerVerifier;
    private readonly outerFetchOpts;
    private readonly outerConsumerOpts;
    private readonly mappingConsumerOpts;
    private emitError;
    /**
     * Stop subscriber operations.
     *
     * @remarks
     * This does not stop the {@link SvSync} instance.
     */
    close(): void;
    /** Subscribe to either a topic prefix or a publisher node ID. */
    subscribe(topic: SvSubscriber.SubscribeInfo<ME>): Subscription<Name, SvSubscriber.Update>;
    private readonly handleSyncUpdate;
    private retrieveMapping;
    private dispatchUpdate;
    private listNameSubs;
    private retrieveSegmented;
}
export declare namespace SvSubscriber {
    interface Options {
        /**
         * Consumer options.
         *
         * @remarks
         * - `.describe` is overridden as "SVS-PS" + prefix.
         * - `.retx` defaults to {@link Options.retxLimit}.
         * - `.signal` and `.verifier` are overridden.
         */
        cOpts?: ConsumerOptions;
        /**
         * SvSync instance.
         * @see {@link SvPublisher.Options.sync} regarding reuse
         */
        sync: SvSync;
        /**
         * Retransmission limit for Data retrieval.
         * @defaultValue 2
         */
        retxLimit?: number;
        /**
         * Maximum quantity of MappingEntries to retrieve in a single query.
         * @defaultValue 10.
         * @see {@link https://github.com/named-data/ndn-svs/blob/e39538ed1ddd789de9a34c242af47c3ba4f3583d/ndn-svs/svspubsub.cpp#L199}
         */
        mappingBatch?: number;
        /**
         * MappingEntry constructor.
         * @defaultValue `MappingEntry` base type
         */
        mappingEntryType?: MappingEntry.Constructor;
        /**
         * If true, force the retrieval of MappingData.
         *
         * @remarks
         * When an update matches a {@link SubscribePublisher}, by default the MappingData is not
         * retrieved. Since the filter functions in {@link SubscribePrefixFilter} depend on
         * MappingEntry, they are not called, and each SubscribePrefixFilter is treated like a
         * {@link SubscribePrefix}, which would receive the message if the topic prefix matches.
         * Set this option to `true` forces the retrieval of MappingData and ensures filter functions
         * are called.
         */
        mustFilterByMapping?: boolean;
        /**
         * Inner Data verifier.
         * @defaultValue no verification
         */
        innerVerifier?: Verifier;
        /**
         * Outer Data verifier.
         * @defaultValue no verification
         */
        outerVerifier?: Verifier;
        /**
         * Mapping Data verifier.
         * @defaultValue no verification
         */
        mappingVerifier?: Verifier;
    }
    /** Subscribe parameters. */
    type SubscribeInfo<ME extends MappingEntry> = SubscribePrefix | SubscribePrefixFilter<ME> | SubscribePublisher;
    /** Subscribe to messages udner a name prefix. */
    type SubscribePrefix = Name;
    /** Subscribe to messages under a name prefix that passes a filter. */
    interface SubscribePrefixFilter<ME extends MappingEntry> {
        /** Topic prefix. */
        prefix: Name;
        /**
         * Filter function to determine whether to retrieve a message based on MappingEntry.
         * @see {@link Options.mustFilterByMapping} for limitations on when this may not be invoked.
         */
        filter: (entry: ME) => boolean;
    }
    /** Subscribe to messages from the specified publisher. */
    interface SubscribePublisher {
        publisher: Name;
    }
    /** Received update. */
    class Update extends Event {
        readonly publisher: Name;
        readonly seqNum: number;
        readonly name: Name;
        readonly payload: Uint8Array;
        constructor(publisher: Name, seqNum: number, name: Name, payload: Uint8Array);
    }
}
export {};
