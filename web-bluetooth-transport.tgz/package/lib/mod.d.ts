import "web-bluetooth";
import { L3Face, Transport } from "@ndn/l3face";
/** Web Bluetooth transport. */
export declare class WebBluetoothTransport extends Transport {
    private readonly server;
    private readonly cs;
    readonly rx: Transport.Rx;
    private constructor();
    close(): void;
    tx: (iterable: AsyncIterable<Uint8Array>) => Promise<void>;
    /** Request for a connection. */
    static request(): Promise<WebBluetoothTransport>;
}
export declare namespace WebBluetoothTransport {
    /** Create a transport and add to forwarder. */
    const createFace: L3Face.CreateFaceFunc<typeof WebBluetoothTransport.request>;
}
