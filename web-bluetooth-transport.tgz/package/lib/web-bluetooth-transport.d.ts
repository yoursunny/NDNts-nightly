import { L3Face, Transport } from "@ndn/l3face";
/** Web Bluetooth transport. */
export declare class WebBluetoothTransport extends Transport {
    private readonly server;
    private readonly cs;
    /**
     * Request for a connection.
     * @see {@link WebBluetoothTransport.createFace}
     */
    static request(): Promise<WebBluetoothTransport>;
    private constructor();
    readonly rx: Transport.RxIterable;
    tx(iterable: Transport.TxIterable): Promise<void>;
    close(): void;
}
export declare namespace WebBluetoothTransport {
    /** Create a transport and add to forwarder. */
    const createFace: L3Face.CreateFaceFunc<[]>;
}
