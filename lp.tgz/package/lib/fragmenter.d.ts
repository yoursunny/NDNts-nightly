import { LpPacket } from "./packet.js";
/** NDNLPv2 fragmenter. */
export declare class Fragmenter {
    private readonly seqNumGen;
    /**
     * Fragment a packet.
     * @param full - LpPacket contains full L3 packet and LpHeaders.
     * @param mtu - Transport MTU.
     * @returns LpPacket fragments, or empty array if fragmentation fails.
     */
    fragment(full: LpPacket, mtu: number): LpPacket[];
}
