import { LpPacket } from "./packet";
export declare class Fragmenter {
    readonly mtu: number;
    constructor(mtu: number);
    private seqNumGen;
    private fragmentRoom;
    fragment(full: LpPacket): LpPacket[];
}
