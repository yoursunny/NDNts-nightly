import { NackHeader } from "@ndn/packet";
import { Decoder, Encodable, Encoder } from "@ndn/tlv";
import type { PitToken } from "./pit-token";
/** NDNLPv2 packet. */
export declare class LpPacket {
    static decodeFrom(decoder: Decoder): LpPacket;
    fragSeqNum?: bigint;
    fragIndex: number;
    fragCount: number;
    pitToken?: PitToken;
    nack?: NackHeader;
    payload?: Uint8Array;
    encodeTo(encoder: Encoder): void;
    encodeL3Headers(): Encodable[];
    copyL3HeadersFrom(src: LpPacket): void;
}
