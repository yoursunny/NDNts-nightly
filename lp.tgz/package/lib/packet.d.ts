import { NackHeader } from "@ndn/packet";
import { type Decoder, type Encodable, Encoder } from "@ndn/tlv";
/** NDNLPv2 packet. */
export declare class LpPacket {
    static decodeFrom(decoder: Decoder): LpPacket;
    fragSeqNum?: bigint;
    fragIndex: number;
    fragCount: number;
    /**
     * L3 payload.
     *
     * @remarks
     * This field may contain either a whole L3 packet or fragment of one.
     * This is also known as *fragment* in other libraries.
     */
    payload?: Uint8Array;
    /**
     * Extract L3 fields only.
     *
     * @remarks
     * They may be copied to another LpPacket via `Object.assign()`.
     */
    get l3(): LpL3;
    /**
     * Prepend LpPacket to encoder.
     *
     * @throws Error
     * Thrown if fragmentation headers violate invariants:
     * - `.fragIndex >= .fragCount`
     * - `.fragSeqNum` is unset but `.fragCount > 1`
     */
    encodeTo(encoder: Encoder): void;
    private encodeFragHeaders;
    /**
     * Determine whether any L3 header is present.
     * @see {@link LpL3}
     */
    hasL3Headers(): boolean;
    /**
     * Encode L3 headers.
     * @see {@link LpL3}
     */
    encodeL3Headers(): Encodable[];
}
export interface LpPacket extends LpL3 {
}
/** L3 fields in {@link LpPacket}. */
export interface LpL3 {
    pitToken?: Uint8Array;
    nack?: NackHeader;
    congestionMark?: number;
}
