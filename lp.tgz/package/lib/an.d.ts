export declare const TT: {
    LpPacket: number;
    LpPayload: number;
    LpSeqNum: number;
    FragIndex: number;
    FragCount: number;
    PitToken: number;
    Nack: number;
    NackReason: number;
    CongestionMark: number;
};
