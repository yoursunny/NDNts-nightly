export declare const TT: {
    readonly LpPacket: 100;
    readonly LpPayload: 80;
    readonly LpSeqNum: 81;
    readonly FragIndex: 82;
    readonly FragCount: 83;
    readonly PitToken: 98;
    readonly Nack: 800;
    readonly NackReason: 801;
    readonly CongestionMark: 832;
};
