import { Data, Interest, Nack } from "@ndn/packet";
import { Decoder } from "@ndn/tlv";
/** NDNLPv2 service. */
export declare class LpService {
    private readonly transport;
    constructor({ keepAlive, mtu, reassemblerCapacity, }: LpService.Options, transport: LpService.Transport);
    private readonly keepAlive?;
    private readonly mtu;
    private readonly fragmenter;
    private readonly reassembler;
    readonly rx: (iterable: AsyncIterable<Decoder.Tlv>) => AsyncIterable<LpService.Packet | LpService.RxError>;
    private decode;
    private decodeL3;
    readonly tx: (iterable: AsyncIterable<LpService.Packet>) => AsyncIterable<Uint8Array | LpService.TxError>;
    private encode;
}
export declare namespace LpService {
    /** An object that reports transport MTU. */
    export interface Transport {
        /** Current transport MTU. */
        readonly mtu: number;
    }
    export interface Options {
        /**
         * How often to send IDLE packets if nothing else was sent, in milliseconds.
         * Set `false` or zero to disable keep-alive.
         * @defaultValue 60000
         */
        keepAlive?: false | number;
        /**
         * Administrative MTU.
         * The lesser of this MTU and the transport's reported MTU is used for fragmentation.
         * @defaultValue Infinity
         */
        mtu?: number;
        /**
         * Maximum number of partial packets kept in the reassembler.
         * @defaultValue 16
         */
        reassemblerCapacity?: number;
    }
    type L3Pkt = Interest | Data | Nack;
    export interface Packet {
        l3: L3Pkt;
        token?: Uint8Array;
        congestionMark?: number;
    }
    export class RxError extends Error {
        readonly packet: Uint8Array;
        constructor(inner: Error, packet: Uint8Array);
    }
    export class TxError extends Error {
        readonly packet: L3Pkt;
        constructor(inner: Error, packet: L3Pkt);
    }
    export {};
}
