import { Data, Interest, Nack } from "@ndn/packet";
import { Decoder } from "@ndn/tlv";
export declare class LpService {
    constructor({ keepAlive, mtu, reassemblerCapacity, }?: LpService.Options);
    private readonly keepAlive;
    private readonly mtu;
    private readonly fragmenter?;
    private readonly reassembler;
    rx: (iterable: AsyncIterable<Decoder.Tlv>) => AsyncIterable<LpService.Packet | LpService.RxError>;
    private rx_;
    private decode;
    private decodeL3;
    tx: (iterable: AsyncIterable<LpService.Packet>) => AsyncIterable<Uint8Array | LpService.TxError>;
    private tx_;
    private encode;
}
export declare namespace LpService {
    export interface Options {
        /**
         * How often to send IDLE packets if nothing else was sent, in millis.
         * Set false or zero to disable keep-alive.
         * @default 60000
         */
        keepAlive?: false | number;
        /**
         * MTU for fragmentation.
         * Set Infinity to disable fragmentation.
         * @default Infinity
         */
        mtu?: number;
        /**
         * Maximum number of partial packets kept in the reassembler.
         * @default 16
         */
        reassemblerCapacity?: number;
    }
    type L3Pkt = Interest | Data | Nack;
    export interface Packet {
        l3: L3Pkt;
        token?: Uint8Array;
    }
    export class RxError extends Error {
        readonly packet: Uint8Array;
        constructor(inner: Error, packet: Uint8Array);
    }
    export class TxError extends Error {
        readonly packet: L3Pkt;
        constructor(inner: Error, packet: L3Pkt);
    }
    export {};
}
