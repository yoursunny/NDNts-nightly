import { LpPacket } from "./packet.js";
/** NDNLPv2 reassembler. */
export declare class Reassembler {
    private readonly capacity;
    constructor(capacity: number);
    private readonly partials;
    /**
     * Process a fragment.
     * @returns Fully reassembled packet, or undefined if packet is not yet complete.
     */
    accept(fragment: LpPacket): LpPacket | undefined;
    private getPartial;
    private putPartial;
}
