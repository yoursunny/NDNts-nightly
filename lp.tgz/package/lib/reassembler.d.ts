import { LpPacket } from "./packet";
export declare class Reassembler {
    private readonly capacity;
    constructor(capacity: number);
    private readonly partials;
    accept(fragment: LpPacket): LpPacket | undefined;
    private getPartial;
    private putPartial;
}
