/** PIT token field of NDNLP packet. */
export declare type PitToken = Uint8Array;
/** PIT tokens in a 32-bit numeric range. */
export declare class NumericPitToken {
    readonly prefix: number;
    constructor(prefix?: number);
    toNumber(token?: PitToken): number | undefined;
    toToken(suffix: number): PitToken;
}
