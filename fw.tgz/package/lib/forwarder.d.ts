import type { Data, Interest, Nack, Name } from "@ndn/packet";
import { TypedEventTarget } from "typescript-event-target";
import { FaceImpl, type FwFace } from "./face.js";
import { Fib } from "./fib.js";
import type { FwPacket } from "./packet.js";
import { Pit } from "./pit.js";
import { Readvertise } from "./readvertise.js";
type EventMap = {
    /** Emitted before adding face. */
    faceadd: Forwarder.FaceEvent;
    /** Emitted after removing face. */
    facerm: Forwarder.FaceEvent;
    /** Emitted before adding prefix to face. */
    prefixadd: Forwarder.PrefixEvent;
    /** Emitted after removing prefix from face. */
    prefixrm: Forwarder.PrefixEvent;
    /** Emitted before advertising prefix. */
    annadd: Forwarder.AnnouncementEvent;
    /** Emitted before withdrawing prefix. */
    annrm: Forwarder.AnnouncementEvent;
    /** Emitted after packet arrival. */
    pktrx: Forwarder.PacketEvent;
    /** Emitted before packet transmission. */
    pkttx: Forwarder.PacketEvent;
};
/** Logical forwarder. */
export interface Forwarder extends TypedEventTarget<EventMap> {
    /** Node names, used in forwarding hint processing. */
    readonly nodeNames: Name[];
    /** Logical faces. */
    readonly faces: ReadonlySet<FwFace>;
    /** Add a logical face to the logical forwarder. */
    addFace: (face: FwFace.RxTx | FwFace.RxTxDuplex, attributes?: FwFace.Attributes) => FwFace;
    /**
     * Cancel timers and other I/O resources.
     * This instance should not be used after this operation.
     */
    close: () => void;
}
export declare namespace Forwarder {
    /** {@link Forwarder.create} options. */
    interface Options {
        /** Whether to try matching Data without PIT token. */
        dataNoTokenMatch?: boolean;
    }
    const DefaultOptions: Required<Options>;
    /** Create a new logical forwarder. */
    function create(options?: Options): Forwarder;
    /** Access the default logical forwarder instance. */
    function getDefault(): Forwarder;
    /** Replace the default logical forwarder instance. */
    function replaceDefault(fw?: Forwarder): void;
    /** Close and delete the default logical forwarder instance (mainly for unit testing). */
    function deleteDefault(): void;
    /** Face event. */
    class FaceEvent extends Event {
        readonly face: FwFace;
        constructor(type: string, face: FwFace);
    }
    /** Prefix registration event. */
    class PrefixEvent extends Event {
        readonly face: FwFace;
        readonly prefix: Name;
        constructor(type: string, face: FwFace, prefix: Name);
    }
    /** Prefix announcement event. */
    class AnnouncementEvent extends Event {
        readonly name: Name;
        constructor(type: string, name: Name);
    }
    /** Packet event. */
    class PacketEvent extends Event {
        readonly face: FwFace;
        readonly packet: FwPacket;
        constructor(type: string, face: FwFace, packet: FwPacket);
    }
}
export declare class ForwarderImpl extends TypedEventTarget<EventMap> implements Forwarder {
    readonly opts: Required<Forwarder.Options>;
    readonly nodeNames: Name[];
    readonly faces: Set<FaceImpl>;
    readonly fib: Fib;
    readonly pit: Pit;
    readonly readvertise: Readvertise;
    private readonly maybeHaveEventListener;
    constructor(opts: Required<Forwarder.Options>);
    addFace(face: FwFace.RxTx | FwFace.RxTxDuplex, attributes?: FwFace.Attributes): FwFace;
    private pickInterestForwardingName;
    /** Process incoming Interest. */
    processInterest(face: FaceImpl, pkt: FwPacket<Interest>): void;
    /** Process incoming cancel Interest request. */
    cancelInterest(face: FaceImpl, pkt: FwPacket<Interest>): void;
    /** Process incoming Data. */
    processData(face: FaceImpl, pkt: FwPacket<Data>): void;
    /** Process incoming Nack. */
    processNack(face: FaceImpl, nack: FwPacket<Nack>): void;
    close(): void;
    dispatchPacketEvent(type: "pktrx" | "pkttx", face: FaceImpl, pkt: FwPacket): void;
}
export {};
