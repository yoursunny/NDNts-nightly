import { Data, Interest, Nack, Name } from "@ndn/packet";
import type TypedEmitter from "typed-emitter";
import { FaceImpl, FwFace } from "./face";
import { Fib } from "./fib";
import type { FwPacket } from "./packet";
import { Pit } from "./pit";
import { Readvertise } from "./readvertise";
interface Events {
    /** Emitted before adding face. */
    faceadd: (face: FwFace) => void;
    /** Emitted after removing face. */
    facerm: (face: FwFace) => void;
    /** Emitted before adding prefix to face. */
    prefixadd: (face: FwFace, prefix: Name) => void;
    /** Emitted after removing prefix from face. */
    prefixrm: (face: FwFace, prefix: Name) => void;
    /** Emitted before advertising prefix. */
    annadd: (announcement: Name) => void;
    /** Emitted before withdrawing prefix. */
    annrm: (announcement: Name) => void;
    /** Emitted after packet arrival. */
    pktrx: (face: FwFace, pkt: FwPacket) => void;
    /** Emitted before packet transmission. */
    pkttx: (face: FwFace, pkt: FwPacket) => void;
}
declare const ForwarderImpl_base: new () => TypedEmitter<Events>;
export declare class ForwarderImpl extends ForwarderImpl_base implements Forwarder {
    readonly options: Forwarder.Options;
    /** Node names, used in forwarding hint processing. */
    readonly nodeNames: Name[];
    readonly faces: Set<FaceImpl>;
    readonly fib: Fib;
    readonly pit: Pit;
    readonly readvertise: Readvertise;
    constructor(options: Forwarder.Options);
    /** Add a face to the forwarding plane. */
    addFace(face: FwFace.RxTx | FwFace.RxTxTransform, attributes?: FwFace.Attributes): FwFace;
    private pickInterestForwardingName;
    /** Process incoming Interest. */
    processInterest(face: FaceImpl, pkt: FwPacket<Interest>): void;
    /** Process incoming cancel Interest request. */
    cancelInterest(face: FaceImpl, pkt: FwPacket<Interest>): void;
    /** Process incoming Data. */
    processData(face: FaceImpl, pkt: FwPacket<Data>): void;
    /** Process incoming Nack. */
    processNack(face: FaceImpl, nack: FwPacket<Nack>): void;
}
/** Forwarding plane. */
export interface Forwarder extends Pick<ForwarderImpl, "nodeNames" | "addFace" | Exclude<keyof TypedEmitter<Events>, "emit">> {
    readonly faces: Set<FwFace>;
    readonly pit: Pick<Pit, "dataNoTokenMatch">;
}
export declare namespace Forwarder {
    type Options = FaceImpl.Options;
    /** Create a new forwarding plane. */
    function create(options?: Options): Forwarder;
    /** Access the default forwarding plane instance. */
    function getDefault(): Forwarder;
    /** Delete default instance (mainly for unit testing). */
    function deleteDefault(): void;
}
export {};
