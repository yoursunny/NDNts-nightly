import { Name, NameMap } from "@ndn/packet";
import * as retry from "retry";
import type { FaceImpl, FwFace } from "./face.js";
import { Forwarder, type ForwarderImpl } from "./forwarder.js";
/**
 * Manage advertised prefix of the forwarder.
 *
 * @remarks
 * This class keeps track of what prefixes are announced by the owning forwarder.
 * It accepts announcements from faces attached to the forwarder, and then informs
 * each destination on what prefixes should be advertised.
 */
export declare class Readvertise {
    readonly fw: ForwarderImpl;
    constructor(fw: ForwarderImpl);
    readonly destinations: Set<ReadvertiseDestination<{}>>;
    /**
     * Prefix announcements arranged by name.
     *
     * NameMap key is the announced name.
     * Map key is a reference to the FwFace announcing the name.
     * Map value is an array of announcements made by the FwFace.
     * Array contains application supplied announcement objects or `undefined` for plain names.
     * Neither the Map nor the Array may be empty.
     *
     * More than one FwFaces can announce the same name simultaneously.
     * An FwFace can announce the same name more than once.
     * This stack of containers is to deduplicate these announcements.
     *
     * A name is being announced if at least one FwFace announces the name at least once.
     */
    readonly byName: NameMap<Map<FaceImpl, (FwFace.PrefixAnnouncementObj | undefined)[]>>;
    /**
     * Prefix announcements arranged by FwFace.
     *
     * Outer key is the FwFace.
     * Inner key is the announced name in hex.
     * Inner value is the announced name.
     *
     * This is for deleting all announcements from a FwFace.
     */
    private readonly byFace;
    addAnnouncement(face: FaceImpl, ann: FwFace.PrefixAnnouncement): void;
    removeAnnouncement(face: FaceImpl, ann: FwFace.PrefixAnnouncement): void;
    private removeAnnouncementImpl;
    clearFace(face: FaceImpl): void;
    listAnnouncementObjs(name: Name): Iterable<FwFace.PrefixAnnouncementObj>;
    /**
     * Cancel timers and other I/O resources.
     * This instance should not be used after this operation.
     */
    close(): void;
}
/**
 * A destination of prefix advertisement.
 *
 * @remarks
 * Generally, a prefix advertised to a destination would cause Interests matching the prefix
 * to come to the local logical forwarder, aka prefix registration.
 */
export declare abstract class ReadvertiseDestination<State extends {} = {}> {
    private readonly retryOptions;
    private readvertise?;
    protected readonly table: NameMap<ReadvertiseDestination.Record<State>>;
    protected readonly queue: import("@ndn/util").Pushable<Name>;
    protected closed: boolean;
    constructor(retryOptions?: ReadvertiseDestination.RetryOptions);
    /** Enable and attach to a forwarder. */
    enable(fw: Forwarder): void;
    /**
     * Disable and detach from forwarder.
     *
     * @remarks
     * Once detached, this instance is no longer usable.
     */
    disable(): void;
    /** Set a prefix to be advertised. */
    advertise(name: Name): void;
    /** Set a prefix to be withdrawn. */
    withdraw(name: Name): void;
    protected restart(name: Name, record: ReadvertiseDestination.Record<State>): void;
    private process;
    /**
     * Create per-prefix state.
     *
     * @remarks
     * Must override if State type parameter is changed from the default.
     */
    protected makeState(name: Name): State;
    /**
     * Retrieve application supplied prefix announcement objects.
     *
     * @remarks
     * This is only available during {@link makeState} and {@link doAdvertise}.
     */
    protected listAnnouncementObjs(name: Name): Iterable<FwFace.PrefixAnnouncementObj>;
    /** Advertise a prefix once. */
    protected abstract doAdvertise(name: Name, state: State): Promise<void>;
    /** Withdraw a prefix once. */
    protected abstract doWithdraw(name: Name, state: State): Promise<void>;
}
export declare namespace ReadvertiseDestination {
    type RetryOptions = retry.OperationOptions;
    enum Status {
        ADVERTISING = 0,
        ADVERTISED = 1,
        WITHDRAWING = 2,
        WITHDRAWN = 3
    }
    interface Record<State> {
        status: Status;
        retry?: retry.RetryOperation;
        state: State;
    }
}
