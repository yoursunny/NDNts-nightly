import { Name } from "@ndn/packet";
import pushable from "it-pushable";
import MultiMap from "mnemonist/multi-map.js";
import * as retry from "retry";
import type { FaceImpl } from "./face";
import type { Forwarder, ForwarderImpl } from "./forwarder";
/**
 * Manage advertised prefix of the forwarder.
 *
 * This class keeps track of what prefixes are announced by the owning forwarder.
 * It accepts announcements from faces attached to the forwarder, and then informs
 * each destination on what prefixes should be advertised.
 */
export declare class Readvertise {
    readonly fw: ForwarderImpl;
    constructor(fw: ForwarderImpl);
    readonly announcements: MultiMap<string, FaceImpl, Set<FaceImpl>>;
    readonly destinations: Set<ReadvertiseDestination<{}>>;
    addAnnouncement(face: FaceImpl, name: Name, nameHex: string): void;
    removeAnnouncement(face: FaceImpl, name: Name | undefined, nameHex: string): void;
}
/**
 * A destination of prefix advertisement.
 *
 * Generally, a prefix advertised to a destination would cause Interests matching the prefix
 * to come to the forwarder. aka prefix registration.
 */
export declare abstract class ReadvertiseDestination<State extends {} = {}> {
    private readonly retryOptions;
    private readvertise?;
    protected readonly table: Map<string, ReadvertiseDestination.Record<State>>;
    protected readonly queue: pushable.Pushable<string>;
    protected closed: boolean;
    constructor(retryOptions?: ReadvertiseDestination.RetryOptions);
    /** Enable and attach to a forwarder. */
    enable(fw: Forwarder): void;
    /**
     * Disable and detach from forwarder.
     *
     * Once detached, this instance is no longer usable.
     */
    disable(): void;
    /** Set a prefix to be advertised. */
    advertise(name: Name, nameHex: string): void;
    /** Set a prefix to be withdrawn. */
    withdraw(name: Name, nameHex: string): void;
    private restart;
    private process;
    /** Create per-prefix state. */
    protected makeState(name: Name, nameHex: string): State;
    /** Advertise a prefix once. */
    protected abstract doAdvertise(name: Name, state: State, nameHex: string): Promise<void>;
    /** Withdraw a prefix once. */
    protected abstract doWithdraw(name: Name, state: State, nameHex: string): Promise<void>;
}
export declare namespace ReadvertiseDestination {
    type RetryOptions = retry.OperationOptions;
    enum Status {
        ADVERTISING = 0,
        ADVERTISED = 1,
        WITHDRAWING = 2,
        WITHDRAWN = 3
    }
    interface Record<State> {
        name: Name;
        status: Status;
        retry?: retry.RetryOperation;
        state: State;
    }
}
