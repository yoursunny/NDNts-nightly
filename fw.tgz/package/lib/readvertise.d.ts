import { type Name, NameMap, NameMultiMap } from "@ndn/packet";
import * as retry from "retry";
import type { FaceImpl } from "./face.js";
import { Forwarder, type ForwarderImpl } from "./forwarder.js";
/**
 * Manage advertised prefix of the forwarder.
 *
 * @remarks
 * This class keeps track of what prefixes are announced by the owning forwarder.
 * It accepts announcements from faces attached to the forwarder, and then informs
 * each destination on what prefixes should be advertised.
 */
export declare class Readvertise {
    readonly fw: ForwarderImpl;
    constructor(fw: ForwarderImpl);
    readonly announcements: NameMultiMap<FaceImpl>;
    readonly destinations: Set<ReadvertiseDestination<{}>>;
    addAnnouncement(face: FaceImpl, name: Name): void;
    removeAnnouncement(face: FaceImpl, name: Name): void;
    /**
     * Cancel timers and other I/O resources.
     * This instance should not be used after this operation.
     */
    close(): void;
}
/**
 * A destination of prefix advertisement.
 *
 * @remarks
 * Generally, a prefix advertised to a destination would cause Interests matching the prefix
 * to come to the local logical forwarder, aka prefix registration.
 */
export declare abstract class ReadvertiseDestination<State extends {} = {}> {
    private readonly retryOptions;
    private readvertise?;
    protected readonly table: NameMap<ReadvertiseDestination.Record<State>>;
    protected readonly queue: import("@ndn/util").Pushable<Name>;
    protected closed: boolean;
    constructor(retryOptions?: ReadvertiseDestination.RetryOptions);
    /** Enable and attach to a forwarder. */
    enable(fw: Forwarder): void;
    /**
     * Disable and detach from forwarder.
     *
     * @remarks
     * Once detached, this instance is no longer usable.
     */
    disable(): void;
    /** Set a prefix to be advertised. */
    advertise(name: Name): void;
    /** Set a prefix to be withdrawn. */
    withdraw(name: Name): void;
    protected restart(name: Name, record: ReadvertiseDestination.Record<State>): void;
    private process;
    /** Create per-prefix state. */
    protected makeState(name: Name): State;
    /** Advertise a prefix once. */
    protected abstract doAdvertise(name: Name, state: State): Promise<void>;
    /** Withdraw a prefix once. */
    protected abstract doWithdraw(name: Name, state: State): Promise<void>;
}
export declare namespace ReadvertiseDestination {
    type RetryOptions = retry.OperationOptions;
    enum Status {
        ADVERTISING = 0,
        ADVERTISED = 1,
        WITHDRAWING = 2,
        WITHDRAWN = 3
    }
    interface Record<State> {
        status: Status;
        retry?: retry.RetryOperation;
        state: State;
    }
}
