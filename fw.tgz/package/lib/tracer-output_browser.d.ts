import type { Tracer } from "./tracer";
export declare function makeTracerOutput(): Tracer.Output;
