import { type Name } from "@ndn/packet";
import type { FaceImpl } from "./face.js";
export declare class Fib {
    private readonly table;
    insert(face: FaceImpl, nameHex: string, capture: boolean): void;
    delete(face: FaceImpl, nameHex: string): void;
    lookup(name: Name): ReadonlySet<FaceImpl>;
}
