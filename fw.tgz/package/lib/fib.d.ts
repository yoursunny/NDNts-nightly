import { Name } from "@ndn/packet";
import DefaultMap from "mnemonist/default-map.js";
import type { FaceImpl } from "./face";
declare class FibEntry {
    readonly nexthops: Set<FaceImpl>;
}
export declare class Fib {
    readonly table: DefaultMap<string, FibEntry>;
    insert(face: FaceImpl, nameHex: string): void;
    delete(face: FaceImpl, nameHex: string): void;
    lpm(name: Name): FibEntry | undefined;
}
export {};
