import type { Data, Interest, Nack } from "@ndn/packet";
type L3Pkt = Interest | Data | Nack;
/** A logical packet in the logical forwarder. */
export interface FwPacket<T extends L3Pkt = L3Pkt> {
    l3: T;
    token?: unknown;
    congestionMark?: number;
    reject?: RejectInterest.Reason;
    cancel?: boolean;
}
export declare namespace FwPacket {
    function create<T extends L3Pkt>(l3: T, token?: unknown, congestionMark?: number): FwPacket<T>;
    /** Determine whether this is a plain packet that can be sent on the wire. */
    function isEncodable({ reject, cancel }: FwPacket): boolean;
}
/** Indicate an Interest has been rejected. */
export declare class RejectInterest implements FwPacket<Interest> {
    reject: RejectInterest.Reason;
    l3: Interest;
    token?: unknown;
    constructor(reject: RejectInterest.Reason, l3: Interest, token?: unknown);
}
export declare namespace RejectInterest {
    type Reason = "cancel" | "expire";
}
/** Request to cancel a pending Interest. */
export declare class CancelInterest implements FwPacket<Interest> {
    l3: Interest;
    token?: unknown;
    constructor(l3: Interest, token?: unknown);
    readonly cancel = true;
}
export {};
