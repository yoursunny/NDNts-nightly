import { Forwarder } from "./forwarder.js";
/** Print trace logs from {@link Forwarder} events. */
export declare class FwTracer {
    static enable(opts?: FwTracer.Options): FwTracer;
    private readonly output;
    private readonly fw;
    private constructor();
    disable(): void;
    private readonly faceadd;
    private readonly facerm;
    private readonly prefixadd;
    private readonly prefixrm;
    private readonly annadd;
    private readonly annrm;
    private readonly pktrx;
    private readonly pkttx;
    private pkt;
}
export declare namespace FwTracer {
    interface Output {
        log: (str: string) => void;
    }
    interface Options {
        /**
         * Where to write log entries.
         * @defaultValue `console`
         */
        output?: Output;
        /**
         * Logical Forwarder instance.
         * @defaultValue `Forwarder.getDefault()`
         */
        fw?: Forwarder;
        /**
         * Whether to log face creations and deletions.
         * @defaultValue true
         */
        face?: boolean;
        /**
         * Whether to log prefix registrations.
         * @defaultValue true
         */
        prefix?: boolean;
        /**
         * Whether to log prefix announcements.
         * @defaultValue true
         */
        ann?: boolean;
        /**
         * Whether to log packets.
         * @defaultValue true
         */
        pkt?: boolean;
    }
}
