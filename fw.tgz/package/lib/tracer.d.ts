import { Forwarder } from "./forwarder";
/** Print trace logs from Forwarder events. */
export declare class Tracer {
    static enable(opts?: Tracer.Options): Tracer;
    private readonly output;
    private readonly fw;
    constructor({ output, fw, face, prefix, ann, pkt, }: Tracer.Options);
    disable(): void;
    private faceadd;
    private facerm;
    private prefixadd;
    private prefixrm;
    private annadd;
    private annrm;
    private pktrx;
    private pkttx;
    private pkt;
}
export declare namespace Tracer {
    interface Output {
        log(str: string): void;
    }
    interface Options {
        /**
         * Where to write log entries.
         * Default is stderr in Node and developer console in browser.
         */
        output?: Output;
        /**
         * Logical Forwarder instance.
         * @default Forwarder.getDefault()
         */
        fw?: Forwarder;
        /**
         * Whether to log face creations and deletions.
         * @default true
         */
        face?: boolean;
        /**
         * Whether to log prefix registrations.
         * @default true
         */
        prefix?: boolean;
        /**
         * Whether to log prefix announcements.
         * @default true
         */
        ann?: boolean;
        /**
         * Whether to log packets.
         * @default true
         */
        pkt?: boolean;
    }
}
