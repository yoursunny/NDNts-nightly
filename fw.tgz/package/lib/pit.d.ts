/// <reference types="node" />
import { Data, Interest } from "@ndn/packet";
import DefaultMap from "mnemonist/default-map.js";
import type { FaceImpl } from "./face";
import { FwPacket } from "./packet";
/** Downstream of pending Interest. */
interface PitDn {
    /** How many times this downstream has (re)transmitted the Interest. */
    nRx: number;
    /** Expiration time of this pending Interest at downstream. */
    expire: number;
    /** Last nonce from this downstream. */
    nonce: number;
    /** Last InterestToken from this downstream. */
    token: unknown;
}
/** Aggregated pending Interests from one or more downstream faces. */
export declare class PitEntry {
    private readonly pit;
    readonly key: string;
    /** Representative Interest. */
    readonly interest: Interest;
    /** Outgoing numeric PIT token. */
    token?: number;
    /** Downstream records. */
    dnRecords: DefaultMap<FaceImpl, PitDn>;
    /** Last expiration time among downstream. */
    lastExpire: number;
    /** Entry expiration timer; should match this.lastExpire. */
    expireTimer?: NodeJS.Timer | number;
    constructor(pit: Pit, key: string, interest: Interest);
    /** Record Interest from downstream. */
    receiveInterest(face: FaceImpl, { l3: interest, token }: FwPacket<Interest>): void;
    /** Record Interest cancellation from downstream. */
    cancelInterest(face: FaceImpl): void;
    /** Forward Interest to upstream. */
    forwardInterest(face: FaceImpl): void;
    /** Determine which downstream faces should receive Data from upstream. */
    returnData(up: FaceImpl): Iterable<{
        dn: FaceImpl;
        token: unknown;
    }>;
    private updateExpire;
    private expire;
}
/** Pending Interest table. */
export declare class Pit {
    readonly byName: Map<string, PitEntry>;
    readonly byToken: Map<number, PitEntry>;
    private lastToken;
    /**
     * true: try to match Data without token.
     * false: Data without token.
     * callback function: invoked when Data without token matches PIT entry.
     *   return true: deliver matched PIT entry.
     *   return false: drop Data.
     */
    dataNoTokenMatch: boolean | ((data: Data, key: string) => boolean);
    private generateToken;
    insertEntry(entry: PitEntry): void;
    eraseEntry(entry: PitEntry): void;
    /** Find or insert entry. */
    lookup(interest: FwPacket<Interest>): PitEntry;
    /** Find entry, disallow insertion. */
    lookup(interest: FwPacket<Interest>, canInsert: false): PitEntry | undefined;
    /**
     * Satisfy pending Interests with incoming Data.
     * @returns true if Data satisfies any pending Interest, or false if Data is unsolicited.
     */
    satisfy(face: FaceImpl, { l3: data, token }: FwPacket<Data>): Promise<boolean>;
    private findPotentialMatches;
}
export {};
