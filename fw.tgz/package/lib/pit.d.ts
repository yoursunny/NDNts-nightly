import { type Data, Interest } from "@ndn/packet";
import DefaultMap from "mnemonist/default-map.js";
import type { FaceImpl } from "./face.js";
import { FwPacket } from "./packet.js";
/** Downstream of pending Interest. */
interface PitDn {
    /** How many times this downstream has (re)transmitted the Interest. */
    nRx: number;
    /** Expiration time of this pending Interest at downstream. */
    expire: number;
    /** Last nonce from this downstream. */
    nonce: number;
    /** Last PIT token from this downstream. */
    token: unknown;
}
/** Aggregated pending Interests from one or more downstream faces. */
export declare class PitEntry {
    private readonly pit;
    readonly key: string;
    /** Representative Interest. */
    readonly interest: Interest;
    /** Outgoing numeric PIT token. */
    token?: number;
    /** Downstream records. */
    dnRecords: DefaultMap<FaceImpl, PitDn>;
    /** Last expiration time among downstream. */
    lastExpire: number;
    /** Entry expiration timer; should match this.lastExpire. */
    expireTimer?: NodeJS.Timeout | number;
    constructor(pit: Pit, key: string, interest: Interest);
    /** Record Interest from downstream. */
    receiveInterest(face: FaceImpl, { l3: interest, token }: FwPacket<Interest>): void;
    /** Record Interest cancellation from downstream. */
    cancelInterest(face: FaceImpl): void;
    /** Forward Interest to upstream. */
    forwardInterest(face: FaceImpl): void;
    /** Determine which downstream faces should receive Data from upstream. */
    returnData(up: FaceImpl): Iterable<{
        dn: FaceImpl;
        token: unknown;
    }>;
    private updateExpire;
    private expire;
}
/** Pending Interest table. */
export declare class Pit {
    readonly dataNoTokenMatch: boolean;
    constructor(dataNoTokenMatch: boolean);
    private readonly byName;
    private readonly byToken;
    private lastToken;
    private generateToken;
    insertEntry(entry: PitEntry): void;
    eraseEntry(entry: PitEntry): void;
    /**
     * Cancel timers and other I/O resources.
     * This instance should not be used after this operation.
     */
    close(): void;
    /** Find or insert entry. */
    lookup(interest: FwPacket<Interest>): PitEntry;
    /** Find entry, disallow insertion. */
    lookup(interest: FwPacket<Interest>, canInsert: false): PitEntry | undefined;
    /**
     * Satisfy pending Interests with incoming Data.
     * @returns `true` if Data satisfies one or more pending Interests;
     *          `false` if Data is unsolicited.
     */
    satisfy(face: FaceImpl, { l3: data, token }: FwPacket<Data>): Promise<boolean>;
    private findPotentialMatches;
}
export {};
