import { Name } from "@ndn/packet";
import type TypedEmitter from "typed-emitter";
import type { Forwarder, ForwarderImpl } from "./forwarder";
import type { FwPacket } from "./packet";
interface Events {
    /** Emitted upon face closing. */
    close: () => void;
}
declare const FaceImpl_base: new () => TypedEmitter<Events>;
export declare class FaceImpl extends FaceImpl_base {
    readonly fw: ForwarderImpl;
    readonly attributes: FwFace.Attributes;
    private readonly routes;
    private readonly announcements;
    private readonly stopping;
    running: boolean;
    private readonly txQueue;
    txQueueLength: number;
    constructor(fw: ForwarderImpl, rxtx: FwFace.RxTx | FwFace.RxTxTransform, attributes: FwFace.Attributes);
    /** Shutdown the face. */
    close(): void;
    toString(): string;
    /** Determine if a route is present on the face. */
    hasRoute(name: Name): boolean;
    /** Add a route toward the face. */
    addRoute(name: Name, announcement?: FwFace.RouteAnnouncement): void;
    /** Remove a route toward the face. */
    removeRoute(name: Name, announcement?: FwFace.RouteAnnouncement): void;
    /** Add a prefix announcement associated with the face. */
    addAnnouncement(name: Name): void;
    /** Remove a prefix announcement associated with the face. */
    removeAnnouncement(name: Name): void;
    /** Transmit a packet on the face. */
    send(pkt: FwPacket): void;
    private rxLoop;
    private txLoop;
}
export declare namespace FaceImpl {
    interface Options {
        faceRxBuffer: number;
        faceTxBuffer: number;
    }
    const DefaultOptions: Options;
}
/** A socket or network interface associated with forwarding plane. */
export interface FwFace extends Pick<FaceImpl, "attributes" | "close" | "toString" | "hasRoute" | "addRoute" | "removeRoute" | "addAnnouncement" | "removeAnnouncement" | Exclude<keyof TypedEmitter<Events>, "emit">> {
    readonly fw: Forwarder;
    readonly running: boolean;
    readonly txQueueLength: number;
}
export declare namespace FwFace {
    export interface Attributes extends Record<string, any> {
        /** Short string to identify the face. */
        describe?: string;
        /** Whether face is local. Default is false. */
        local?: boolean;
        /** Whether to readvertise registered routes. Default is true. */
        advertiseFrom?: boolean;
    }
    export type RouteAnnouncement = boolean | number | Name;
    interface RxTxBase {
        readonly attributes?: Attributes;
    }
    export interface RxTx extends RxTxBase {
        rx: AsyncIterable<FwPacket>;
        tx: (iterable: AsyncIterable<FwPacket>) => void;
    }
    export interface RxTxTransform extends RxTxBase {
        /**
         * The transform function takes an iterable of packets sent by the forwarder,
         * and returns an iterable of packets received by the forwarder.
         */
        transform: (iterable: AsyncIterable<FwPacket>) => AsyncIterable<FwPacket>;
    }
    export {};
}
export {};
