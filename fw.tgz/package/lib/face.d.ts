import { type NameLike } from "@ndn/packet";
import { TypedEventTarget } from "typescript-event-target";
import { Forwarder, type ForwarderImpl } from "./forwarder.js";
import type { FwPacket } from "./packet.js";
type EventMap = {
    /** Emitted upon face is up as reported by lower layer. */
    up: Event;
    /** Emitted upon face is down as reported by lower layer. */
    down: Event;
    /** Emitted upon face is closed. */
    close: Event;
};
/** A socket or network interface associated with logical forwarder. */
export interface FwFace extends TypedEventTarget<EventMap> {
    readonly fw: Forwarder;
    readonly attributes: FwFace.Attributes;
    readonly running: boolean;
    /** Shutdown the face. */
    close: () => void;
    toString: () => string;
    /** Determine if a route is present on the face. */
    hasRoute: (name: NameLike) => boolean;
    /**
     * Add a route toward the face.
     * @param name - Route name.
     * @param announcement - Prefix announcement name or how to derive it from `name`.
     *
     * @remarks
     * When the logical forwarder receives an Interest matching `name`, it may forward the Interest
     * to this face. Unless `announcement` is set to `false`, this also invokes
     * {@link addAnnouncement} to readvertise the name prefix to remote forwarders.
     */
    addRoute: (name: NameLike, announcement?: FwFace.RouteAnnouncement) => void;
    /** Remove a route toward the face. */
    removeRoute: (name: NameLike, announcement?: FwFace.RouteAnnouncement) => void;
    /**
     * Add a prefix announcement associated with the face.
     * @param name - Prefix announcement name.
     *
     * @remarks
     * The announcement is passed to {@link ReadvertiseDestination}s (e.g. NFD prefix registration
     * client) on the logical forwarder, so that remote forwarders would send Interests matching
     * the prefix to the local logical forwarder.
     *
     * Multiple FwFaces could make the same announcement. When the last FwFace making an announcement
     * is closed, the announcement is withdrawn from {@link ReadvertiseDestination}s.
     *
     * This function has no effect if `FwFace.Attributes.advertiseFrom` is set to `false`.
     */
    addAnnouncement: (name: NameLike) => void;
    /** Remove a prefix announcement associated with the face. */
    removeAnnouncement: (name: NameLike) => void;
}
export declare namespace FwFace {
    /** Attributes of a logical forwarder face. */
    interface Attributes extends Record<string, unknown> {
        /** Short string to identify the face. */
        describe?: string;
        /**
         * Whether face is local.
         * @defaultValue false
         */
        local?: boolean;
        /**
         * Whether to allow prefix announcements.
         * @defaultValue true
         * @remarks
         * If `false`, {@link FwFace.addAnnouncement} has no effect.
         */
        advertiseFrom?: boolean;
        /**
         * Whether routes registered on this face would cause FIB to stop matching onto shorter prefixes.
         * @defaultValue true
         * @see {@link \@ndn/endpoint!ProducerOptions.routeCapture}
         */
        routeCapture?: boolean;
        [k: string]: unknown;
    }
    /**
     * Describe how to derive route announcement from name prefix in {@link FwFace.addRoute}.
     *
     * @remarks
     * - `false`: no announcement is made.
     * - `true`: same as route name.
     * - number: n-component prefix of route name.
     * - {@link Name} or string: specified name.
     */
    type RouteAnnouncement = boolean | number | NameLike;
    type RxTxEventMap = Pick<EventMap, "up" | "down">;
    interface RxTxBase {
        readonly attributes?: Attributes;
        addEventListener?: <K extends keyof RxTxEventMap>(type: K, listener: (ev: RxTxEventMap[K]) => any, options?: AddEventListenerOptions) => void;
        removeEventListener?: <K extends keyof RxTxEventMap>(type: K, listener: (ev: RxTxEventMap[K]) => any, options?: EventListenerOptions) => void;
    }
    /** A logical face with separate RX and TX packet streams. */
    interface RxTx extends RxTxBase {
        /** RX packet stream received by the logical forwarder. */
        rx: AsyncIterable<FwPacket>;
        /** Function to accept TX packet stream sent by the logical forwarder. */
        tx: (iterable: AsyncIterable<FwPacket>) => void;
    }
    /** A logical face with duplex RX and TX packet streams. */
    interface RxTxDuplex extends RxTxBase {
        /**
         * Duplex RX and TX streams.
         * @param iterable - TX packet stream sent by the logical forwarder.
         * @returns RX packet stream received by the logical forwarder.
         */
        duplex: (iterable: AsyncIterable<FwPacket>) => AsyncIterable<FwPacket>;
    }
}
export declare class FaceImpl extends TypedEventTarget<EventMap> implements FwFace {
    readonly fw: ForwarderImpl;
    private readonly rxtx;
    readonly attributes: FwFace.Attributes;
    private readonly routes;
    private readonly announcements;
    running: boolean;
    private readonly txQueue;
    constructor(fw: ForwarderImpl, rxtx: FwFace.RxTx | FwFace.RxTxDuplex, attributes: FwFace.Attributes);
    close(): void;
    toString(): string;
    hasRoute(nameInput: NameLike): boolean;
    addRoute(nameInput: NameLike, announcement?: FwFace.RouteAnnouncement): void;
    removeRoute(nameInput: NameLike, announcement?: FwFace.RouteAnnouncement): void;
    addAnnouncement(nameInput: NameLike): void;
    removeAnnouncement(nameInput: NameLike): void;
    /** Transmit a packet on the face. */
    send(pkt: FwPacket): void;
    private readonly handleLowerUp;
    private readonly handleLowerDown;
    private readonly rxLoop;
    private txLoop;
}
export {};
