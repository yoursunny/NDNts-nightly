import pushable from "it-pushable";
import { FwFace } from "./face";
import type { FwPacket } from "./packet";
/**
 * Create a secondary face by tapping on a primary face.
 *
 * TapFace is useful for sending in-band management commands to a specific neighbor, after being
 * added to a temporary secondary Forwarder. The TapFace shares the same transport as the primary
 * face, but allows independent FIB and PIT settings. The primary Forwarder will see RX packets,
 * but does not see TX packets.
 */
export declare class TapFace implements FwFace.RxTx {
    readonly face: FwFace;
    get attributes(): {
        describe: string;
        local?: boolean | undefined;
        advertiseFrom?: boolean | undefined;
    };
    readonly rx: pushable.Pushable<FwPacket<import("@ndn/packet").Interest | import("@ndn/packet").Data | import("@ndn/packet").Nack>>;
    private readonly ctrl;
    constructor(face: FwFace);
    tx: (iterable: AsyncIterable<FwPacket>) => Promise<void>;
}
export declare namespace TapFace {
    /** Create a new Forwarder and add a TapFace. */
    function create(face: FwFace): FwFace;
}
