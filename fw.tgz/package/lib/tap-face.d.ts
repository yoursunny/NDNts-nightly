import type { FwFace } from "./face.js";
import type { FwPacket } from "./packet.js";
/**
 * Create a secondary face by tapping on a primary face.
 *
 * @remarks
 * TapFace is useful for sending in-band management commands to a specific neighbor, after being
 * added to a temporary secondary Forwarder. The TapFace shares the same transport as the primary
 * face, but allows independent FIB and PIT settings. The primary Forwarder will see RX packets,
 * but does not see TX packets.
 */
export declare class TapFace implements FwFace.RxTx {
    readonly face: FwFace;
    constructor(face: FwFace);
    get attributes(): {
        describe: string;
        local?: boolean | undefined;
        advertiseFrom?: boolean | undefined;
        routeCapture?: boolean | undefined;
    };
    private readonly ctrl;
    readonly rx: import("@ndn/util").Pushable<FwPacket<import("@ndn/packet").Interest | import("@ndn/packet").Data | import("@ndn/packet").Nack>>;
    tx(iterable: AsyncIterable<FwPacket>): Promise<void>;
}
export declare namespace TapFace {
    /**
     * Create a new {@link Forwarder} and add a {@link TapFace}.
     * @param face - FwFace on the existing forwarder.
     * @returns FwFace on a new forwarder. The forwarder may be retrieved in `.fw` property.
     */
    function create(face: FwFace): FwFace;
}
