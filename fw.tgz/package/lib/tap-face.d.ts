import type { FwFace } from "./face.js";
import type { FwPacket } from "./packet.js";
/**
 * Create a secondary face that shares the transport of a primary face.
 *
 * @remarks
 * TapFace is useful for sending in-band management commands to a specific neighbor, after being
 * added to a temporary secondary Forwarder. The TapFace shares the same transport as the primary
 * face, but allows independent FIB and PIT settings. The primary Forwarder will see RX packets,
 * but does not see TX packets.
 */
export declare class TapFace implements FwFace.RxTx {
    readonly face: FwFace;
    /**
     * Create a new secondary {@link Forwarder} and add a {@link TapFace}.
     * @param face - FwFace on the existing primary forwarder.
     * @returns FwFace on a new forwarder. The forwarder may be retrieved in `.fw` property.
     */
    static create(face: FwFace): FwFace;
    private constructor();
    get attributes(): {
        local?: boolean;
        advertiseFrom?: boolean;
        routeCapture?: boolean;
        describe: string;
    };
    private readonly ctrl;
    readonly rx: import("@ndn/util").Pushable<FwPacket<import("@ndn/packet").Data | import("@ndn/packet").Interest | import("@ndn/packet").Nack>>;
    tx(iterable: AsyncIterable<FwPacket>): Promise<void>;
}
