import { AltUriConverter } from "@ndn/packet";
/** Print conventions (rev2) in alternate URI syntax. */
export declare const AltUri2: AltUriConverter;
/** Print conventions (rev3) in alternate URI syntax. */
export declare const AltUri3: AltUriConverter;
/** Print conventions (default format, currently rev3) in alternate URI syntax. */
export declare const AltUri: AltUriConverter;
