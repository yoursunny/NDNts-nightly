import { AltUriConverter } from "@ndn/packet";
/** Print conventions from this package in alternate URI syntax. */
export declare const AltUri: AltUriConverter;
