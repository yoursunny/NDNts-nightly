import { type NamingConvention } from "@ndn/packet";
interface WithType {
    /** TLV-TYPE number. */
    readonly type: number;
}
interface StringConvention extends NamingConvention<string>, WithType {
}
interface NumberConvention<A = never, R extends number | bigint = number> extends NamingConvention<number | bigint | A, R>, NamingConvention.WithAltUri, WithType {
}
interface NumberBigConvention<A = never> extends NumberConvention<A> {
    /** Interpret as bigint instead of number. */
    big: NumberConvention<A, bigint>;
}
interface TimestampConvention extends NumberConvention<Date> {
    /** Timestamp interpreted as number in milliseconds. */
    ms: NumberConvention<Date>;
    /** Timestamp interpreted as number in microseconds. */
    us: NumberConvention<Date>;
}
/**
 * GenericNameComponent enclosing a number.
 *
 * This is not really a naming convention, but it's used in several protocols.
 */
export declare const GenericNumber: NumberBigConvention;
/** KeywordNameComponent (rev2 & rev3), interpreted as string. */
export declare const Keyword: StringConvention;
/** SegmentNameComponent (rev2), interpreted as number. */
export declare const Segment2: NumberBigConvention;
/** SegmentNameComponent (rev3), interpreted as number. */
export declare const Segment3: NumberBigConvention;
/** SegmentNameComponent (default format, currently rev3). */
export declare const Segment: NumberBigConvention<never>;
/** ByteOffsetNameComponent (rev2), interpreted as number. */
export declare const ByteOffset2: NumberBigConvention;
/** ByteOffsetNameComponent (rev3), interpreted as number. */
export declare const ByteOffset3: NumberBigConvention;
/** ByteOffsetNameComponent (default format, currently rev3). */
export declare const ByteOffset: NumberBigConvention<never>;
/** VersionNameComponent (rev2), interpreted as number. */
export declare const Version2: NumberBigConvention;
/** VersionNameComponent (rev3), interpreted as number. */
export declare const Version3: NumberBigConvention;
/** VersionNameComponent (default format, currently rev3). */
export declare const Version: NumberBigConvention<never>;
/** TimestampNameComponent (rev2), interpreted as number in milliseconds. */
export declare const Timestamp2: TimestampConvention;
/** TimestampNameComponent (rev3), interpreted as number in milliseconds. */
export declare const Timestamp3: TimestampConvention;
/** TimestampNameComponent (default format, currently rev3). */
export declare const Timestamp: TimestampConvention;
/** SequenceNumNameComponent (rev2), interpreted as number. */
export declare const SequenceNum2: NumberBigConvention;
/** SequenceNumNameComponent (rev3), interpreted as number. */
export declare const SequenceNum3: NumberBigConvention;
/** SequenceNumNameComponent (default format, currently rev3). */
export declare const SequenceNum: NumberBigConvention<never>;
export {};
