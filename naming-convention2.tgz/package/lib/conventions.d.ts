import { NamingConvention } from "@ndn/packet";
declare type NumberConvention = NamingConvention<number> & NamingConvention.WithAltUri;
declare type TimestampConvention = NamingConvention<number | Date, number> & NamingConvention.WithAltUri;
/** KeywordNameComponent, interpreted as string. */
export declare const Keyword: NamingConvention<string>;
/** SegmentNameComponent, interpreted as number. */
export declare const Segment: NumberConvention;
/** ByteOffsetNameComponent, interpreted as number. */
export declare const ByteOffset: NumberConvention;
/** VersionNameComponent, interpreted as number. */
export declare const Version: NumberConvention;
/** TimestampNameComponent, interpreted as number in milliseconds. */
export declare const Timestamp: NamingConvention<number | Date, number> & NamingConvention.WithAltUri & {
    /** TimestampNameComponent, interpreted as number in milliseconds. */
    ms: TimestampConvention;
    /** TimestampNameComponent, interpreted as number in microseconds. */
    us: TimestampConvention;
};
/** SequenceNumNameComponent, interpreted as number. */
export declare const SequenceNum: NumberConvention;
export {};
