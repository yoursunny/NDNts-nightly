import { type NamingConvention } from "@ndn/packet";
interface NumberConvention extends NamingConvention<number | bigint, number> {
}
/** Segment number marker. */
export declare const Segment: NumberConvention;
/** Byte offset marker. */
export declare const ByteOffset: NumberConvention;
/** Version marker. */
export declare const Version: NumberConvention;
/** Timestamp marker. */
export declare const Timestamp: NumberConvention;
/** Sequence number marker. */
export declare const SequenceNum: NumberConvention;
export {};
