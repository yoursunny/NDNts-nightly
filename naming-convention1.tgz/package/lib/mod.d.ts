import { Component, NamingConvention } from "@ndn/packet";
declare class Markered implements NamingConvention<number> {
    private readonly marker;
    constructor(marker: number);
    match(comp: Component): boolean;
    create(v: number): Component;
    parse(comp: Component): number;
}
/** Segment number marker. */
export declare const Segment: Markered;
/** Byte offset marker. */
export declare const ByteOffset: Markered;
/** Version marker. */
export declare const Version: Markered;
/** Timestamp marker. */
export declare const Timestamp: Markered;
/** Sequence number marker. */
export declare const SequenceNum: Markered;
export {};
