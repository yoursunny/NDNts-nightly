import { type Certificate, type KeyChain } from "@ndn/keychain";
import { type Data, type Name } from "@ndn/packet";
export declare const ContentTypeUnencryptedPrivateKey = 9;
/** NDNd unencrypted private key. */
export declare class UnencryptedPrivateKey {
    readonly data: Data;
    constructor(data: Data);
    /** Retrieve key name. */
    get keyName(): Name;
    /** Retrieve signature type. */
    get sigType(): number;
    /** Retrieve unencrypted private key. */
    get secret(): Uint8Array;
    private cert_?;
    /** Retrieve associated certificate. */
    get cert(): Certificate | undefined;
    /**
     * Assign associated certificate.
     * @throws Error - Certificate does not match the key.
     */
    set cert(value: Certificate | undefined);
    /**
     * Save key pair and certificate to KeyChain.
     * @param keyChain - Destination KeyChain.
     */
    saveKeyPair(keyChain: KeyChain): Promise<void>;
}
