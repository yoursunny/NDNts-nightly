import { Certificate } from "@ndn/keychain";
import { UnencryptedPrivateKey } from "./private-key.js";
/**
 * Parse PEM-encoded unencrypted private key.
 * @param input - *.key file content.
 */
export declare function parseKey(input: string): UnencryptedPrivateKey;
/**
 * Parse PEM-encoded certificate.
 * @param input - *.cert file content.
 */
export declare function parseCert(input: string): Certificate;
