/** A token-based throttle limiter. */
export declare class TokenLimiter {
    private capacity_;
    private readonly queue;
    private nTaken_;
    constructor(capacity_?: number);
    /** How many callers are waiting for a token. */
    get nWaiting(): number;
    /** How many tokens are currently taken. */
    get nTaken(): number;
    /** Capacity of the token bucket. */
    get capacity(): number;
    /** Change total number of tokens. */
    set capacity(v: number);
    /** Wait to take a token. */
    take(): Promise<void>;
    /** Return one or more tokens. */
    put(n?: number): void;
    private unblock;
}
