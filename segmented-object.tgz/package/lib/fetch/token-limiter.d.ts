/** A token-based throttle limiter. */
export declare class TokenLimiter {
    private capacity_;
    private queue;
    private nTaken_;
    constructor(capacity_?: number);
    get nWaiting(): number;
    get nTaken(): number;
    get capacity(): number;
    /** Change total number of tokens. */
    set capacity(v: number);
    /** Wait to take a token. */
    take(): Promise<void>;
    /** Return one or more tokens. */
    put(n?: number): void;
    private unblock;
}
