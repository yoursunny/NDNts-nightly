export declare class Reorder<T> {
    private next;
    private buffer;
    constructor(first?: number);
    get empty(): boolean;
    push(index: number, obj: T): T[];
    private pop;
}
