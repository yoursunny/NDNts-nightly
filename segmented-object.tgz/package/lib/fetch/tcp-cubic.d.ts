import { CongestionAvoidance } from "./congestion-avoidance";
/**
 * TCP CUBIC algorithm.
 * @see https://tools.ietf.org/html/rfc8312
 */
export declare class TcpCubic extends CongestionAvoidance {
    private readonly c;
    private readonly betaCubic;
    private readonly alphaAimd;
    private t0;
    private wMax;
    private wLastMax;
    private k;
    private ssthresh;
    constructor({ iw, c, betaCubic, }?: TcpCubic.Options);
    increase(now: number, rtt: number): void;
    decrease(now: number): void;
}
export declare namespace TcpCubic {
    interface Options {
        /** Initial window. Default is 2. */
        iw?: number;
        /** CUBIC parameter C. Default is 0.4. */
        c?: number;
        /** CUBIC parameter beta_cubic. Default is 0.7. */
        betaCubic?: number;
    }
}
