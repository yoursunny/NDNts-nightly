interface Parameters {
    k: number;
    alpha: number;
    beta: number;
    initRto: number;
    minRto: number;
    maxRto: number;
}
/**
 * RTT estimator.
 * @see {@link https://datatracker.ietf.org/doc/html/rfc6298}
 */
export declare class RttEstimator {
    private params;
    private sRtt_;
    private rttVar;
    private rto_;
    constructor(opts?: RttEstimator.Options);
    get sRtt(): number;
    get rto(): number;
    push(rtt: number, nPending?: number): void;
    backoff(): void;
    private clampRto;
}
export declare namespace RttEstimator {
    type Options = Partial<Parameters>;
}
export {};
