/// <reference types="node" />
import type TypedEmitter from "typed-emitter";
import { CongestionAvoidance } from "./congestion-avoidance";
import { RttEstimator } from "./rtt-estimator";
declare class SegState {
    readonly segNum: number;
    constructor(segNum: number);
    get isRetx(): boolean;
    nRetx: number;
    txTime: number;
    rto: number;
    rtoExpiry?: NodeJS.Timeout;
    interest: any;
}
declare type SegRequest<T> = Pick<Readonly<SegState>, "segNum" | "isRetx" | "rto"> & {
    interest: T;
};
declare const UNBLOCK: unique symbol;
interface Events {
    [UNBLOCK]: () => void;
    /** Fetching finished. */
    end: () => void;
    /** A segment request has exceeded maximum retx limit and will not be retried. */
    exceedRetxLimit: (segNum: number) => void;
}
declare const FetchLogic_base: new () => TypedEmitter<Events>;
/** Congestion control logic. */
export declare class FetchLogic extends FetchLogic_base {
    /** Internal clock. */
    readonly now: import("hirestime").Elapsor;
    private readonly rtte;
    private readonly ca;
    private readonly tl;
    private pending;
    private retxQueue;
    private readonly retxLimit;
    private hiInterestSegNum;
    private hiDataSegNum;
    private finalSegNum;
    private estimatedFinalSegNum;
    private cwndDecreaseSegNum;
    private running;
    private processCancels;
    constructor({ rtte, ca, segmentRange, estimatedFinalSegNum, retxLimit, }: FetchLogic.Options);
    /** Abort. */
    close(): void;
    /** Generate stream of outgoing requests. */
    outgoing<T, C>(makeInterest: (req: SegRequest<unknown>) => T, cancelInterest: (req: SegRequest<T>) => C): AsyncGenerator<T | C>;
    private prepareRequest;
    /**
     * Notify a request has been satisfied.
     * @param now reading of `this.now()` at packet arrival (e.g. before verification)
     */
    satisfy(segNum: number, now?: number): void;
    private rtoTimeout;
    /**
     * Update final segment number (inclusive) when it becomes known.
     * Increasing this above opts.segmentRange[1] or a previous value has no effect.
     */
    setFinalSegNum(finalSegNum: number, estimated?: boolean): void;
}
export declare namespace FetchLogic {
    interface Options {
        /** Use given RttEstimator instance or construct RttEstimator from options. */
        rtte?: RttEstimator | RttEstimator.Options;
        /** Use given congestion avoidance instance. */
        ca?: CongestionAvoidance;
        /**
         * Specify segment number range as [begin, end).
         * The begin segment number is inclusive and the end segment number is exclusive.
         * If the begin segment number is greater than the final segment number, fetching will fail.
         * If the end segment number is undefined or greater than the final segment number,
         * fetching will stop at the final segment.
         */
        segmentRange?: [number, number | undefined];
        /**
         * Estimated final segment number (inclusive).
         * If specified, FetchLogic sends Interests up to this segment number initially as permitted
         * by congestion control, then sends further Interests in a stop-and-wait manner, unless a new
         * estimation or known finalSegNum is provided via setFinalSegNum() function.
         */
        estimatedFinalSegNum?: number;
        /**
         * Maximum number of retransmissions, excluding initial Interest.
         * Default is 15.
         */
        retxLimit?: number;
    }
}
export {};
