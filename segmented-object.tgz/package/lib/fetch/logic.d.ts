/// <reference types="node" />
import { TypedEventTarget } from "typescript-event-target";
import type { CongestionAvoidance } from "./congestion-avoidance.js";
import { RttEstimator } from "./rtt-estimator.js";
declare class SegState {
    readonly segNum: number;
    constructor(segNum: number);
    get isRetx(): boolean;
    nRetx: number;
    txTime: number;
    rto: number;
    rtoExpiry?: NodeJS.Timeout | number;
    interest: any;
}
type SegRequest<T> = Pick<Readonly<SegState>, "segNum" | "isRetx" | "rto"> & {
    interest: T;
};
type EventMap = {
    /** Periodical unblock, for internal use. */
    unblock: Event;
    /** Fetching finished. */
    end: Event;
    /**
     * A segment request has exceeded maximum retx limit and will not be retried.
     * Event detail is the segment number.
     */
    exceedRetxLimit: CustomEvent<number>;
};
/** Congestion control logic. */
export declare class FetchLogic extends TypedEventTarget<EventMap> {
    /** Internal clock. */
    readonly now: () => number;
    private readonly rtte;
    private readonly ca;
    private readonly tl;
    private readonly pending;
    private readonly retxQueue;
    private readonly retxLimit;
    private hiInterestSegNum;
    private hiDataSegNum;
    private finalSegNum;
    private estimatedFinalSegNum;
    private cwndDecreaseSegNum;
    private running;
    private processCancels;
    private paused?;
    constructor({ rtte, ca, segmentRange, estimatedFinalSegNum, retxLimit, }: FetchLogic.Options);
    /** Abort. */
    close(): void;
    /**
     * Pause outgoing Interests, for backpressure from Data consumer.
     * @returns Function for resuming.
     */
    pause(): () => void;
    /** Generate stream of outgoing requests. */
    outgoing<T, C>(makeInterest: (req: SegRequest<unknown>) => T, cancelInterest: (req: SegRequest<T>) => C): AsyncGenerator<T | C>;
    private prepareRequest;
    /**
     * Notify a request has been satisfied.
     * @param now - Reading of `this.now()` at packet arrival (e.g. before verification).
     */
    satisfy(segNum: number, now: number, hasCongestionMark: boolean): void;
    private rtoTimeout;
    /** Decrease congestion window at most once per RTT. */
    private decrease;
    /**
     * Update final segment number (inclusive) when it becomes known.
     *
     * @remarks
     * Increasing this above `.opts.segmentRange[1]` or a previous value has no effect.
     */
    setFinalSegNum(finalSegNum: number, estimated?: boolean): void;
    /** Notify that the incoming stream has ended. */
    end(): boolean;
}
export declare namespace FetchLogic {
    interface Options {
        /** Use given RttEstimator instance or construct RttEstimator from options. */
        rtte?: RttEstimator | RttEstimator.Options;
        /** Use given congestion avoidance instance. */
        ca?: CongestionAvoidance;
        /**
         * Specify segment number range as `[begin, end)`.
         *
         * @remarks
         * The begin segment number is inclusive and the end segment number is exclusive.
         * If the begin segment number is greater than the final segment number, fetching will fail.
         * If the end segment number is undefined or greater than the final segment number,
         * fetching will stop at the final segment.
         */
        segmentRange?: [number, number | undefined];
        /**
         * Estimated final segment number (inclusive).
         *
         * @remarks
         * If specified, FetchLogic sends Interests up to this segment number initially as permitted
         * by congestion control, then sends further Interests in a stop-and-wait manner, unless a new
         * estimation or known finalSegNum is provided via setFinalSegNum() function.
         */
        estimatedFinalSegNum?: number;
        /**
         * Maximum number of retransmissions, excluding initial Interest.
         * @defaultValue 15
         */
        retxLimit?: number;
    }
}
export {};
