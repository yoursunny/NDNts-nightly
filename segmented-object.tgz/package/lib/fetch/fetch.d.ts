import { type Data, type NameLike } from "@ndn/packet";
import { type WritableStreamish } from "streaming-iterables";
import { Fetcher } from "./fetcher.js";
/**
 * Fetch a segmented object.
 *
 * @remarks
 * This function does not perform version discovery. If the segmented object is versioned, `name`
 * must include the version component. You can perform version discovery with
 * {@link discoverVersion} function and pass its result to this function for fetching the
 * versioned and segmented object.
 */
export declare function fetch(name: NameLike, opts?: fetch.Options): fetch.Result;
export declare namespace fetch {
    /** {@link fetch} options. */
    interface Options extends Fetcher.Options {
    }
    /**
     * Return type of {@link fetch} function.
     *
     * @remarks
     * Fetch output may be accessed in one of several formats:
     * - `await result` resolves to the reassembled object as Uint8Array.
     * - `for await (const packet of result)` iterates over Data packets in segment number order.
     * - more formats available as methods.
     *
     * Result is lazy. Fetching starts when an output format is accessed.
     * You may only access one output format on a Result instance.
     * Formats other than `await result` can be accessed only once.
     */
    interface Result extends PromiseLike<Uint8Array>, AsyncIterable<Data> {
        /** Iterate over Data packets as they arrive, not sorted in segment number order. */
        unordered: () => AsyncIterable<Data & {
            readonly segNum: number;
        }>;
        /** Iterate over payload chunks in segment number order. */
        chunks: () => AsyncIterable<Uint8Array>;
        /** Write all chunks to the destination stream. */
        pipe: (dest: WritableStreamish) => Promise<void>;
        /** Number of segments retrieved so far. */
        readonly count: number;
    }
}
