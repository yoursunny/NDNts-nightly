/// <reference types="node" />
import type { Data, Name } from "@ndn/packet";
import { Fetcher } from "./fetcher";
/** Fetch a segment object as AsyncIterable of payload. */
export declare function fetch(name: Name, opts?: fetch.Options): fetch.Result;
export declare namespace fetch {
    type Options = Fetcher.Options;
    /**
     * Return type of fetch() function.
     *
     * Fetch output may be accessed in one of several formats:
     * - `await result` resolves to the reassembled object as Uint8Array.
     * - `for await (const packet of result)` iterates over Data packets in segment number order.
     * - more formats available as methods.
     *
     * Result is lazy. Fetching starts when an output format is accessed.
     * You may only access one output format on a Result instance.
     * Formats other than `await result` can be accessed only once.
     */
    interface Result extends PromiseLike<Uint8Array>, AsyncIterable<Data> {
        /** Iterate over Data packets as they arrive, not sorted in segment number order. */
        unordered: () => AsyncIterable<Data>;
        /** Iterate over payload chunks in segment number order. */
        chunks: () => AsyncIterable<Uint8Array>;
        /** Write all chunks to the destination stream. */
        pipe: (dest: NodeJS.WritableStream) => Promise<void>;
        /** Number of segmented retrieved. */
        readonly count: number;
    }
}
