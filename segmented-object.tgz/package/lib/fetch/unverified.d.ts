import { Forwarder } from "@ndn/fw";
import { Data, Interest, type Name } from "@ndn/packet";
import { type SegmentConvention } from "../convention.js";
import type { CongestionAvoidance } from "./congestion-avoidance.js";
import { RttEstimator } from "./rtt-estimator.js";
export interface UnverifiedFetcherOptions {
    /**
     * Use the specified logical forwarder.
     * @defaultValue `Forwarder.getDefault()`
     */
    fw?: Forwarder;
    /**
     * FwFace description.
     * @defaultValue "fetch" + name
     */
    describe?: string;
    /** AbortSignal that allows canceling the fetch via AbortController. */
    signal?: AbortSignal;
    /**
     * Specify segment number range as `[begin, end)`.
     *
     * @remarks
     * The begin segment number is inclusive and the end segment number is exclusive.
     * If the begin segment number is greater than the final segment number, fetching will fail.
     * If the end segment number is undefined or greater than the final segment number,
     * fetching will stop at the final segment.
     */
    segmentRange?: [number, number | undefined];
    /**
     * Estimated final segment number (inclusive).
     *
     * @remarks
     * This option has no effect at the moment.
     * @alpha
     */
    estimatedFinalSegNum?: number;
    /**
     * Choose a segment number naming convention.
     * @defaultValue `Segment3`
     */
    segmentNumConvention?: SegmentConvention;
    /**
     * Modify Interest according to specified options.
     *
     * @remarks
     * This can also be used to witness Interests without modification.
     */
    modifyInterest?: Interest.Modify;
    /**
     * InterestLifetime added to RTO.
     * @defaultValue 1000ms
     */
    lifetimeAfterRto?: number;
    /** Use given RttEstimator instance or construct RttEstimator from options. */
    rtte?: RttEstimator | RttEstimator.Options;
    /** Use given congestion avoidance instance. */
    ca?: CongestionAvoidance;
    /**
     * Maximum number of retransmissions, excluding initial Interest.
     * @defaultValue 15
     */
    retxLimit?: number;
    /**
     * List of acceptable ContentType values.
     * @defaultValue `[0]`
     */
    acceptContentType?: readonly number[];
}
/** Segmented object fetcher without verification. */
export declare class UnverifiedFetcher {
    private readonly name;
    private readonly signal?;
    /** Next segment number to start fetching. */
    private segNext;
    /** Last segment number (inclusive). */
    private segLast;
    private readonly segmentNumConvention;
    private readonly modifyInterest;
    private readonly lifetimeAfterRto;
    private readonly rtte;
    private readonly ca;
    private readonly retxLimit;
    private readonly acceptContentType;
    private readonly face;
    private count_;
    private nextCwndDecrease;
    /** Segments for which at least one Interest is sent but the Data has not arrived. */
    private readonly pendings;
    /** Segments whose RTO is exceeded and shall be retransmitted. */
    private readonly retxQ;
    /** Interests being sent to logical forwarder. */
    private readonly txQ;
    /** Data being received from logical forwarder. */
    private readonly rxQ;
    constructor(name: Name, { fw, describe, signal, segmentRange: [segFirst, segLast1], segmentNumConvention, modifyInterest, lifetimeAfterRto, rtte, ca, retxLimit, acceptContentType, }: UnverifiedFetcherOptions);
    /** Number of segments retrieved so far. */
    get count(): number;
    /**
     * Retrieve segments without verification.
     * @returns Stream of segments.
     */
    fetch(): AsyncIterable<SegData>;
    private unsafeFetch;
    /**
     * Handle Data arrival.
     * @param data - Data packet.
     * @param seg - Segment number.
     * @param congestionMark - Congestion mark on Data packet; 0 if none.
     * @returns - Successfully retrieved segment, if any.
     */
    private handleData;
    /** Process RTO expirations on pending segments. */
    private processRtoExpiry;
    /**
     * Transmit Interests as needed.
     * @returns `true` if fetching is fully completed.
     */
    private processTx;
    /** Send an Interest and record TX time. */
    private sendInterest;
    /**
     * Decrease congestion window if allowed.
     * @param effAt - Effective time for the decreasing.
     * @returns Whether decreasing was allowed to happen.
     */
    private decreaseCwnd;
}
export interface SegData {
    seg: number;
    data: Data;
}
