import { Endpoint } from "@ndn/endpoint";
import { Data, Interest, Name, Verifier } from "@ndn/packet";
import type { AbortSignal } from "abort-controller";
import type TypedEmitter from "typed-emitter";
import { SegmentConvention } from "../convention";
import { FetchLogic } from "./logic";
interface Events {
    /** Emitted when a Data segment arrives. */
    segment: (segNum: number, data: Data) => void;
    /** Emitted after all data chunks arrive. */
    end: () => void;
    /** Emitted upon error. */
    error: (err: Error) => void;
}
declare const Fetcher_base: new () => TypedEmitter<Events>;
export declare class Fetcher extends Fetcher_base {
    private readonly name;
    private readonly opts;
    private readonly logic;
    private readonly face;
    constructor(name: Name, opts: Fetcher.Options);
    close(): void;
    private tx;
    private rx;
    private handleData;
    private handleAbort;
}
export declare namespace Fetcher {
    interface Options extends FetchLogic.Options {
        /** Use the specified endpoint instead of the default. */
        endpoint?: Endpoint;
        /** FwFace description. */
        describe?: string;
        /**
         * Choose a segment number naming convention.
         * Default is Segment from @ndn/naming-convention2 package.
         */
        segmentNumConvention?: SegmentConvention;
        /**
         * Modify Interest according to specified options.
         * This can also be used to witness Interests without modification.
         */
        modifyInterest?: Interest.Modify;
        /** AbortSignal that allows canceling the Interest via AbortController. */
        signal?: AbortSignal | globalThis.AbortSignal;
        /**
         * InterestLifetime added to RTO.
         * Default is 1000ms.
         * Ignored if `lifetime` is set.
         */
        lifetimeAfterRto?: number;
        /** If specified, verify received Data. */
        verifier?: Verifier;
    }
}
export {};
