import type { ConsumerOptions, Endpoint } from "@ndn/endpoint";
import { Forwarder } from "@ndn/fw";
import { Data, Interest, type Name, type Verifier } from "@ndn/packet";
import { TypedEventTarget } from "typescript-event-target";
import { type SegmentConvention } from "../convention.js";
import { FetchLogic } from "./logic.js";
type EventMap = {
    /** Emitted when a Data segment arrives. */
    segment: Fetcher.SegmentDataEvent;
    /** Emitted after all data chunks arrive. */
    end: Event;
    /** Emitted upon error. */
    error: CustomEvent<Error>;
};
/** Fetch Data packets as guided by FetchLogic. */
export declare class Fetcher extends TypedEventTarget<EventMap> {
    private readonly name;
    /** Number of segments retrieved so far. */
    get count(): number;
    private count_;
    private readonly logic;
    private readonly face;
    private readonly segmentNumConvention;
    private readonly modifyInterest;
    private readonly signal?;
    private readonly lifetimeAfterRto;
    private readonly acceptContentType;
    private readonly verifier?;
    constructor(name: Name, opts: Fetcher.Options);
    close(): void;
    /**
     * Pause outgoing Interests, for backpressure from Data consumer.
     * @returns Function for resuming.
     */
    pause(): () => void;
    private tx;
    private readonly rx;
    private handleData;
    private fail;
    private readonly handleAbort;
}
export declare namespace Fetcher {
    interface Options extends FetchLogic.Options {
        /**
         * Inherit fetcher options from Endpoint consumer options.
         * @deprecated Specify `.cOpts`.
         */
        endpoint?: Endpoint;
        /**
         * Inherit fetcher options from consumer options.
         *
         * @remarks
         * These options are inherited if the corresponding fetcher option is unset:
         * - `describe`
         * - `fw`
         * - `modifyInterest`
         * - `signal`
         * - `verifier`
         *
         * Other options cannot be inherited, notably:
         * - `retx`
         */
        cOpts?: ConsumerOptions;
        /**
         * Use the specified logical forwarder.
         * @defaultValue `Forwarder.getDefault()`
         */
        fw?: Forwarder;
        /**
         * FwFace description.
         * @defaultValue "fetch" + name
         */
        describe?: string;
        /**
         * Choose a segment number naming convention.
         * @defaultValue `Segment3`
         */
        segmentNumConvention?: SegmentConvention;
        /**
         * Modify Interest according to specified options.
         *
         * @remarks
         * This can also be used to witness Interests without modification.
         */
        modifyInterest?: Interest.Modify;
        /** AbortSignal that allows canceling the Interest via AbortController. */
        signal?: AbortSignal;
        /**
         * InterestLifetime added to RTO.
         * @defaultValue 1000ms
         */
        lifetimeAfterRto?: number;
        /**
         * List of acceptable ContentType values.
         * @defaultValue `[0]`
         */
        acceptContentType?: readonly number[];
        /**
         * Data verifier.
         * @defaultValue
         * No verification.
         */
        verifier?: Verifier;
    }
    interface SegmentData {
        segNum: number;
        data: Data;
    }
    class SegmentDataEvent extends Event implements SegmentData {
        readonly segNum: number;
        readonly data: Data;
        constructor(type: string, segNum: number, data: Data);
    }
}
export {};
