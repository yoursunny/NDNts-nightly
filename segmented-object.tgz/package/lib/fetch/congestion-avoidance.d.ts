import type TypedEmitter from "typed-emitter";
interface Events {
    cwndupdate: (cwnd: number) => void;
}
declare const CWND: unique symbol;
declare const CongestionAvoidance_base: new () => TypedEmitter<Events>;
/** Congestion avoidance algorithm. */
export declare abstract class CongestionAvoidance extends CongestionAvoidance_base {
    private [CWND];
    constructor(initialCwnd: number);
    get cwnd(): number;
    protected updateCwnd(v: number): void;
    abstract increase(now: number, rtt: number): void;
    abstract decrease(now: number): void;
}
export {};
