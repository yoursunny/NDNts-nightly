import { TypedEventTarget } from "typescript-event-target";
type EventMap = {
    cwndupdate: Event;
};
/** Congestion avoidance algorithm. */
export declare abstract class CongestionAvoidance extends TypedEventTarget<EventMap> {
    private cwnd_;
    /**
     * Constructor.
     * @param initialCwnd - Initial congestion window.
     */
    constructor(initialCwnd: number);
    /** Congestion window. */
    get cwnd(): number;
    protected updateCwnd(v: number): void;
    /**
     * Increase congestion window.
     * @param now - Timestamp of positive feedback (successful retrieval without congestion mark).
     * @param rtt - Round-trip time when the positive feedback is received.
     */
    abstract increase(now: number, rtt: number): void;
    /**
     * Decrease congestion window upon negative feedback (loss or congestion mark).
     * @param now - Timestamp of negative feedback.
     */
    abstract decrease(now: number): void;
}
export {};
