import { NamingConvention } from "@ndn/packet";
export declare type VersionConvention = NamingConvention<any>;
export declare type VersionConventionFromNumber = NamingConvention<number, unknown>;
export declare const defaultVersionConvention: VersionConventionFromNumber;
export declare type SegmentConvention = NamingConvention<number>;
export declare const defaultSegmentConvention: SegmentConvention;
