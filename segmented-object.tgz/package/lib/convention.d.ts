import type { NamingConvention } from "@ndn/packet";
export type VersionConvention = NamingConvention<any>;
export type VersionConventionFromNumber = NamingConvention<number, unknown>;
export declare const defaultVersionConvention: VersionConventionFromNumber;
export type SegmentConvention = NamingConvention<number>;
export declare const defaultSegmentConvention: SegmentConvention;
