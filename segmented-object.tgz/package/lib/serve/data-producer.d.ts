import type { ProducerHandler } from "@ndn/endpoint";
import { Data, Name, Signer } from "@ndn/packet";
import { SegmentConvention } from "../convention";
import type { Chunk, ChunkSource } from "./chunk-source/mod";
/** Produce Data for requested segment. */
export declare abstract class DataProducer {
    protected readonly source: ChunkSource;
    protected readonly prefix: Name;
    private readonly segmentNumConvention;
    private readonly contentType;
    private readonly freshnessPeriod;
    private readonly signer;
    constructor(source: ChunkSource, prefix: Name, { segmentNumConvention, contentType, freshnessPeriod, signer, }: DataProducer.Options);
    listData(): AsyncIterable<Data>;
    processInterest: ProducerHandler;
    private parseInterest;
    protected makeData({ i, final, payload }: Chunk): Promise<Data>;
    protected abstract getData(i: number): Promise<Data | undefined>;
    close(): void;
}
export declare namespace DataProducer {
    interface Options {
        /**
         * Choose a segment number naming convention.
         * Default is Segment from @ndn/naming-convention2 package.
         */
        segmentNumConvention?: SegmentConvention;
        /**
         * Data ContentType.
         * @default 0
         */
        contentType?: number;
        /**
         * Data FreshnessPeriod (in milliseconds).
         * @default 60000
         */
        freshnessPeriod?: number;
        /**
         * A private key to sign Data.
         * Default is SHA256 digest.
         */
        signer?: Signer;
        /**
         * How many chunks behind latest request to store in buffer.
         * This is ignored if the ChunkSource supports getChunk() function.
         *
         * After processing an Interest requesting segment `i`, subsequent Interests requesting
         * segment before `i - bufferBehind` cannot be answered.
         *
         * A larger number or even `Infinity` allows answering Interests requesting early segments,
         * at the cost of buffering many generated packets in memory.
         * A smaller number reduces memory usage, at the risk of not being able to answer some Interests,
         * which would become a problem in the presence of multiple consumers.
         *
         * @default Infinity
         */
        bufferBehind?: number;
        /**
         * How many chunks ahead of latest request to store in buffer.
         * This is ignored if the ChunkSource supports getChunk() function.
         *
         * A larger number can reduce latency of fulfilling Interests if ChunkSource is slow.
         * A smaller number reduces memory usage.
         *
         * @default 16
         */
        bufferAhead?: number;
    }
    /** Create a DataProducer suitable for the ChunkSource. */
    function create(source: ChunkSource, prefix: Name, opts?: Options): DataProducer;
    /** Produce all Data packets from a ChunkSource. */
    function listData(source: ChunkSource, prefix: Name, opts?: Options): AsyncIterable<Data>;
}
