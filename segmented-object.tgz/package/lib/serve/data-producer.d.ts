import type { ProducerHandler } from "@ndn/endpoint";
import { Data, type Name, type Signer } from "@ndn/packet";
import { type SegmentConvention } from "../convention.js";
import type { Chunk, ChunkSource } from "./chunk-source/mod.js";
/**
 * Produce Data for requested segment.
 * @see {@link DataProducer.create}
 */
export declare abstract class DataProducer {
    protected readonly source: ChunkSource;
    protected readonly prefix: Name;
    private readonly segmentNumConvention;
    private readonly contentType;
    private readonly freshnessPeriod;
    private readonly signer;
    protected constructor(source: ChunkSource, prefix: Name, { segmentNumConvention, contentType, freshnessPeriod, signer, }: DataProducer.Options);
    listData(): AsyncIterable<Data>;
    readonly processInterest: ProducerHandler;
    private parseInterest;
    protected makeData({ i, final, payload }: Chunk): Promise<Data>;
    protected abstract getData(i: number): Promise<Data | undefined>;
    close(): void;
}
export declare namespace DataProducer {
    interface Options {
        /**
         * Choose a segment number naming convention.
         * @defaultValue `Segment3`
         */
        segmentNumConvention?: SegmentConvention;
        /**
         * Data ContentType.
         * @defaultValue 0
         */
        contentType?: number;
        /**
         * Data FreshnessPeriod (in milliseconds).
         * @defaultValue 60000
         */
        freshnessPeriod?: number;
        /**
         * Data signer.
         * @defaultValue digestSigning
         */
        signer?: Signer;
        /**
         * How many chunks behind latest request to store in buffer.
         * @defaultValue Infinity
         *
         * @remarks
         * This is ignored if the ChunkSource supports `getChunk()` function.
         *
         * After processing an Interest requesting segment `i`, subsequent Interests requesting
         * segment before `i - bufferBehind` cannot be answered.
         *
         * A larger number or even `Infinity` allows answering Interests requesting early segments,
         * at the cost of buffering many generated packets in memory.
         * A smaller number reduces memory usage, at the risk of not being able to answer some Interests,
         * which would become a problem in the presence of multiple consumers.
         */
        bufferBehind?: number;
        /**
         * How many chunks ahead of latest request to store in buffer.
         * @defaultValue 16
         *
         * @remarks
         * This is ignored if the ChunkSource supports `getChunk()` function.
         *
         * A larger number can reduce latency of fulfilling Interests if ChunkSource is slow.
         * A smaller number reduces memory usage.
         */
        bufferAhead?: number;
    }
    /** Create a DataProducer suitable for the ChunkSource. */
    function create(source: ChunkSource, prefix: Name, opts?: Options): DataProducer;
    /** Produce all Data packets from a ChunkSource. */
    function listData(source: ChunkSource, prefix: Name, opts?: Options): AsyncIterable<Data>;
}
