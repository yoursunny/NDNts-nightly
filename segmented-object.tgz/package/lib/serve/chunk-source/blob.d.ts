import type { Blob as NodeBlob } from "node:buffer";
import { type ChunkOptions, type ChunkSource, KnownSizeChunkSource } from "./common.js";
/** Generate chunks from a Blob (W3C File API). */
export declare class BlobChunkSource extends KnownSizeChunkSource implements ChunkSource {
    private readonly blob;
    constructor(blob: Blob | NodeBlob, opts?: ChunkOptions);
    protected getPayload(i: number, offset: number, chunkSize: number): Promise<Uint8Array>;
}
