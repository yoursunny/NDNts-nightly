import { ChunkOptions, ChunkSource, KnownSizeChunkSource } from "./common";
/** Generate chunks from a Blob (from W3C File API, browser only). */
export declare class BlobChunkSource extends KnownSizeChunkSource implements ChunkSource {
    private readonly blob;
    constructor(blob: Blob, opts?: ChunkOptions);
    private readonly readBlob;
    protected getPayload(i: number, offset: number, chunkSize: number): Promise<Uint8Array>;
}
