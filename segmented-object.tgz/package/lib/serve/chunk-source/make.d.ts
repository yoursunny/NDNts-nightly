/// <reference types="node" />
import type { AnyIterable } from "streaming-iterables";
import { BufferChunkSource } from "./buffer";
import type { ChunkOptions } from "./common";
import { IterableChunkSource } from "./iterable";
import { StreamChunkSource } from "./stream";
export declare function makeChunkSource(input: Uint8Array, opts?: ChunkOptions): BufferChunkSource;
export declare function makeChunkSource(input: AnyIterable<Uint8Array>, opts?: ChunkOptions): IterableChunkSource;
export declare function makeChunkSource(input: NodeJS.ReadableStream, opts?: ChunkOptions): StreamChunkSource;
