/// <reference types="node" />
/// <reference types="node" />
import type { Blob as NodeBlob } from "node:buffer";
import type { AnyIterable } from "streaming-iterables";
import { BlobChunkSource } from "./blob.js";
import { BufferChunkSource } from "./buffer.js";
import type { ChunkOptions } from "./common.js";
import { IterableChunkSource } from "./iterable.js";
/**
 * Create a {@link BufferChunkSource}.
 * @deprecated Use of this function is discouraged because it pulls in `ChunkSource` subclasses
 * not needed by your application. Instead, construct {@link BufferChunkSource} directly.
 */
export declare function makeChunkSource(input: Uint8Array, opts?: ChunkOptions): BufferChunkSource;
/**
 * Create a {@link BlobChunkSource}.
 * @deprecated Use of this function is discouraged because it pulls in `ChunkSource` subclasses
 * not needed by your application. Instead, construct {@link BlobChunkSource} directly.
 */
export declare function makeChunkSource(input: Blob | NodeBlob, opts?: ChunkOptions): BlobChunkSource;
/**
 * Create a {@link IterableChunkSource}.
 * @deprecated Use of this function is discouraged because it pulls in `ChunkSource` subclasses
 * not needed by your application. Instead, construct {@link IterableChunkSource} directly.
 */
export declare function makeChunkSource(input: AnyIterable<Uint8Array> | NodeJS.ReadableStream, opts?: ChunkOptions): IterableChunkSource;
