import { type Chunk, type ChunkOptions, type ChunkSource } from "./common.js";
/**
 * Generate chunks from a file.
 *
 * @remarks
 * Warning: modifying the file while FileChunkSource is active may cause undefined behavior.
 */
export declare class FileChunkSource implements ChunkSource {
    constructor(path: string, opts?: FileChunkSource.Options);
    private readonly opening;
    listChunks(): AsyncIterable<Chunk>;
    getChunk(i: number): Promise<Chunk | undefined>;
    close(): Promise<void>;
}
export declare namespace FileChunkSource {
    /** {@link FileChunkSource} options. */
    type Options = ChunkOptions & {
        /**
         * Whether to use ZenFS.
         *
         * @remarks
         * - Set `true` to use ZenFS, which is a cross-platform virtual filesystem independent from
         *   the underlying operating system. This is the only choice in browser environment.
         * - Set `false` to use Node.js native filesystem. This is the default in Node.js.
         */
        zenfs?: boolean;
    };
}
