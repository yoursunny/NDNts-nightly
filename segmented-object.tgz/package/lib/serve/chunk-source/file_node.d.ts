import { Chunk, ChunkOptions, ChunkSource } from "./common";
/**
 * Generate chunks from a file.
 *
 * Warning: modifying the file while FileChunkSource is active may cause undefined behavior.
 */
export declare class FileChunkSource implements ChunkSource {
    constructor(path: string, opts?: ChunkOptions);
    private opening;
    listChunks(): AsyncIterable<Chunk>;
    getChunk(i: number): Promise<Chunk | undefined>;
    close(): Promise<void>;
}
