import { type Chunk, type ChunkOptions, type ChunkSource } from "./common.js";
/**
 * Generate chunks from a file.
 *
 * @remarks
 * Warning: modifying the file while FileChunkSource is active may cause undefined behavior.
 */
export declare class FileChunkSource implements ChunkSource {
    constructor(path: string, opts?: ChunkOptions);
    private readonly opening;
    listChunks(): AsyncIterable<Chunk>;
    getChunk(i: number): Promise<Chunk | undefined>;
    close(): Promise<void>;
}
