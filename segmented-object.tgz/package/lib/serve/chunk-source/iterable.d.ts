import type { AnyIterable } from "streaming-iterables";
import { Chunk, ChunkOptions, ChunkSource } from "./common";
/** Generate chunks from an Iterable or AsyncIterable of Uint8Arrays. */
export declare class IterableChunkSource implements ChunkSource {
    private readonly input;
    private readonly opts;
    constructor(input: AnyIterable<Uint8Array>, opts?: ChunkOptions);
    listChunks(): AsyncIterable<Chunk>;
}
