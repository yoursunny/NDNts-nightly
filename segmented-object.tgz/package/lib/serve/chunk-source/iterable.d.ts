/// <reference types="node" />
import { type AnyIterable } from "streaming-iterables";
import { type Chunk, type ChunkOptions, type ChunkSource } from "./common.js";
/**
 * Generate chunks from an Iterable or AsyncIterable of Uint8Arrays.
 * This also accepts NodeJS stream.Readable, which is an AsyncIterable of Buffers.
 */
export declare class IterableChunkSource implements ChunkSource {
    private readonly input;
    constructor(input: AnyIterable<Uint8Array> | NodeJS.ReadableStream, opts?: ChunkOptions);
    private readonly minSize;
    private readonly maxSize;
    listChunks(): AsyncIterable<Chunk>;
}
/** Alias of IterableChunkSource, which accepts NodeJS stream.Readable. */
export declare const StreamChunkSource: typeof IterableChunkSource;
