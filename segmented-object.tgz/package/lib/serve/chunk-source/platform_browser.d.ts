export declare function fsOpen(path: string): Promise<never>;
