import { promises as zenfs } from "@zenfs/core";
export declare function fsOpen(path: string): Promise<zenfs.FileHandle>;
