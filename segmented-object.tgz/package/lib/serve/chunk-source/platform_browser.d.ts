export declare function fsOpen(_path: string): Promise<never>;
