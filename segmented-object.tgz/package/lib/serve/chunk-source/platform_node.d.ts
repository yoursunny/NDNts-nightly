import fs from "node:fs/promises";
import type { FileChunkSource } from "./file.js";
export declare function fsOpen(path: string, _opts: FileChunkSource.Options): Promise<fs.FileHandle>;
