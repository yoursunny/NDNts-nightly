import fs from "node:fs/promises";
import type { FileChunkSource } from "./file.js";
export declare function fsOpen(path: string, opts: FileChunkSource.Options): Promise<fs.FileHandle>;
