/** Index and payload of a chunk. */
export interface Chunk {
    /** Chunk number, starting from zero. */
    i: number;
    /** Final chunk number, if known. */
    final?: number;
    /** Chunk payload. */
    payload: Uint8Array;
}
/** An object that can generate chunks. */
export interface ChunkSource {
    /**
     * Generate chunks sequentially.
     * @returns AsyncIterable of chunks in order.
     */
    listChunks: () => AsyncIterable<Chunk>;
    /**
     * Generate a chunk on-demand.
     * @param i - Chunk number, starting from zero.
     * @returns Promise that resolves to requested chunk, or undefined if out of range.
     */
    getChunk?: (i: number) => Promise<Chunk | undefined>;
    close?: () => void;
}
export declare abstract class KnownSizeChunkSource implements ChunkSource {
    protected readonly chunkSize: number;
    protected readonly totalSize: number;
    constructor(chunkSize: number, totalSize: number);
    protected readonly final: number;
    protected readonly finalChunkSize: number;
    listChunks(): AsyncIterable<Chunk>;
    getChunk(i: number): Promise<Chunk | undefined>;
    private makeChunk;
    protected abstract getPayload(i: number, offset: number, chunkSize: number): Promise<Uint8Array>;
}
interface ChunkSizeRange {
    /**
     * Minimum chunk size.
     * @defaultValue 64
     */
    minChunkSize?: number;
    /**
     * Maximum chunk size.
     * @defaultValue 4096
     */
    maxChunkSize?: number;
}
interface ChunkSizeExact {
    /** Exact chunk size. */
    chunkSize?: number;
}
/** Chunk sizing options. */
export type ChunkOptions = ChunkSizeRange | ChunkSizeExact;
export declare function getMinChunkSize(opts: ChunkOptions): number;
export declare function getMaxChunkSize(opts: ChunkOptions): number;
export {};
