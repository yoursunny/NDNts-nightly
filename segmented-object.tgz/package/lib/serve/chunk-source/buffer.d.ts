import { ChunkOptions, ChunkSource, KnownSizeChunkSource } from "./common";
/** Generate chunks from a fixed buffer. */
export declare class BufferChunkSource extends KnownSizeChunkSource implements ChunkSource {
    private readonly input;
    constructor(input: Uint8Array, opts?: ChunkOptions);
    protected getPayload(i: number, offset: number, chunkSize: number): Promise<Uint8Array>;
}
