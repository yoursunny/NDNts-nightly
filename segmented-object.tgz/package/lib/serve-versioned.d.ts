import { type ComponentLike, type NameLike } from "@ndn/packet";
import { type VersionConventionFromNumber } from "./convention.js";
import { type ChunkSource, serve, type Server } from "./serve/mod.js";
/**
 * Start serving a segmented object with support of CanBePrefix version discovery.
 * @param prefix - Data prefix excluding version and segment components.
 * @param source - Where to read segment payload chunks.
 * @param opts - Other options.
 */
export declare function serveVersioned(prefix: NameLike, source: ChunkSource, opts?: serveVersioned.Options): Server;
export declare namespace serveVersioned {
    interface Options extends serve.Options {
        /**
         * Version component or version number.
         * @defaultValue `Date.now())`
         */
        version?: ComponentLike | number;
        /**
         * Choose a version number naming convention.
         * @defaultValue `Version3`
         *
         * @remarks
         * If `.version` is a number, it's encoded with this convention.
         */
        versionConvention?: VersionConventionFromNumber;
    }
}
