import { ComponentLike, NameLike } from "@ndn/packet";
import { VersionConventionFromNumber } from "./convention";
import { ChunkSource, ServeOptions, Server } from "./serve/mod";
declare type GivenVersionOptions = {
    version: ComponentLike;
};
declare type MakeVersionOptions = {
    versionConvention?: VersionConventionFromNumber;
    version?: number;
};
export declare type ServeVersionedOptions = Omit<ServeOptions, "producerPrefix"> & (GivenVersionOptions | MakeVersionOptions);
export declare function serveVersioned(prefixInput: NameLike, source: ChunkSource, opts?: ServeVersionedOptions): Server;
export {};
