import { type ConsumerOptions } from "@ndn/endpoint";
import { type Name } from "@ndn/packet";
import type { Arrayable } from "type-fest";
import { type SegmentConvention, type VersionConvention } from "./convention.js";
/**
 * Discover version with CanBePrefix.
 * @param name - Name without version component.
 * @returns Promise that resolves to versioned name annotated with identified conventions.
 */
export declare function discoverVersion(name: Name, { cOpts, versionConvention, segmentNumConvention, conventions: conventionsInput, expectedSuffixLen, }?: discoverVersion.Options): Promise<discoverVersion.Result>;
export declare namespace discoverVersion {
    const ANY_SUFFIX_LEN: unique symbol;
    interface Options {
        /**
         * Consumer options.
         *
         * @remarks
         * - `.describe` defaults to "discoverVersion" + name.
         * - `.retx` defaults to 2.
         * - `.verifier` is recommended.
         */
        cOpts?: ConsumerOptions;
        /**
         * Choose a version naming convention.
         * @defaultValue `Version3`
         */
        versionConvention?: VersionConvention;
        /**
         * Choose a segment number naming convention.
         * @defaultValue `Segment3`
         */
        segmentNumConvention?: SegmentConvention;
        /**
         * List of acceptable version+segment naming convention combinations.
         *
         * @remarks
         * If this is specified and non-empty, it overrides `.versionConvention` and
         * `.segmentNumConvention`.
         */
        conventions?: ReadonlyArray<[VersionConvention, SegmentConvention]>;
        /**
         * Expected number of suffix components, including Version and Segment.
         * @defaultValue 2
         *
         * @remarks
         * Minimum and default are 2, i.e. Version and Segment components.
         * This can be a single number or an array of acceptable numbers.
         * {@link ANY_SUFFIX_LEN} allows any suffix length.
         */
        expectedSuffixLen?: Arrayable<number> | typeof ANY_SUFFIX_LEN;
    }
    type Result = Name & {
        /** Recognized version naming convention. */
        versionConvention: VersionConvention;
        /** Recognized segment number naming convention. */
        segmentNumConvention: SegmentConvention;
    };
}
