import { Name } from "@ndn/packet";
import { VersionConvention } from "./convention";
import { fetch } from "./fetch/mod";
/** Discover version with CanBePrefix. */
export declare function discoverVersion(name: Name, opts?: discoverVersion.Options): Promise<Name>;
export declare namespace discoverVersion {
    const ANY_SUFFIX_LEN: unique symbol;
    interface Options extends fetch.Options {
        /**
         * Choose a version naming convention.
         * Default is Version from @ndn/naming-convention2 package.
         */
        versionConvention?: VersionConvention;
        /**
         * Expected number of suffix components, including Version and Segment.
         * Minimum and default are 2, i.e. Version and Segment components.
         * ANY_SUFFIX_LEN allows any suffix length.
         */
        expectedSuffixLen?: number | typeof ANY_SUFFIX_LEN;
    }
}
