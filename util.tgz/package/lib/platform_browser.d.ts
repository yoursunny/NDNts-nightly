export declare function concatBuffers(list: readonly Uint8Array[], totalLength?: number): Uint8Array;
export declare const console: Console;
export declare const crypto: Crypto;
export declare function delay<T = void>(after: number, value?: T): Promise<T>;
export declare function timingSafeEqual(a: Uint8Array, b: Uint8Array): boolean;
