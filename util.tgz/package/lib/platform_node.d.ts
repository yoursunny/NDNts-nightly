import { timingSafeEqual } from "node:crypto";
export { timingSafeEqual };
/** Concatenate Uint8Arrays. */
export declare function concatBuffers(arr: readonly Uint8Array[], totalLength?: number): Uint8Array;
/** Console on stderr. */
export declare const console: import("node:console").Console;
/** Make a Promise that resolves after specified duration. */
export declare const delay: <T = void>(after: number, value?: T) => Promise<T>;
