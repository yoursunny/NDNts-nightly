/// <reference types="node" />
import { timingSafeEqual } from "node:crypto";
export { timingSafeEqual };
/** Concatenate Uint8Arrays. */
export declare function concatBuffers(arr: readonly Uint8Array[], totalLength?: number): Uint8Array;
/** Console on stderr. */
export declare const console: Console;
/** Web Crypto API. */
export declare const crypto: Crypto;
/** CustomEvent object. */
export declare const CustomEvent: typeof globalThis["CustomEvent"];
/** Make a Promise that resolves after specified duration. */
export declare const delay: <T = void>(after: number, value?: T) => Promise<T>;
