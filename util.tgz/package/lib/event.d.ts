/**
 * Keep records on whether an event listener has been added.
 * @param target - EventTarget to override.
 * @returns Map from event type to whether listeners may exist.
 *
 * @remarks
 * This may allow `EventTarget` subclass to skip certain event generation code paths.
 * Tracking is imprecise: it does not consider `options.once` and `options.signal`.
 */
export declare function trackEventListener(target: EventTarget): Record<string, boolean>;
