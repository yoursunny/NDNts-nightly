/** Timing-safe equality comparison. */
export declare function timingSafeEqual(a: Uint8Array, b: Uint8Array): boolean;
/** Compute SHA256 digest. */
export declare function sha256(input: Uint8Array): Promise<Uint8Array<ArrayBuffer>>;
