/// <reference types="node" />
/// <reference types="node" />
import "./polyfill_node.js";
import type { Promisable } from "type-fest";
import type { Semaphore } from "wait-your-turn";
export interface Closer {
    close: () => void;
}
export declare namespace Closer {
    /** Close or dispose an object. */
    function close(c: any): Promisable<void>;
    /** Convert a closable object to AsyncDisposable. */
    function asAsyncDisposable(c: Closer | Disposable | AsyncDisposable): AsyncDisposable;
}
/** A list of objects that can be closed or disposed. */
export declare class Closers extends Array<Closer | Disposable | AsyncDisposable> implements Disposable {
    /**
     * Close all objects and clear the list.
     *
     * @remarks
     * All objects added to this array are closed, in the reversed order as they appear in the array.
     * This is a synchronous function, so that any AsyncDisposable objects in the array would have its
     * asyncDispose method is called but not awaited.
     * This array is cleared and can be reused.
     */
    readonly close: () => void;
    [Symbol.dispose](): void;
    /** Schedule a timeout or interval to be canceled upon close. */
    addTimeout<T extends NodeJS.Timeout | number>(t: T): T;
    /** Wait for close. */
    wait(): Promise<void>;
}
/**
 * Acquire a semaphore for unlocking via Disposable.
 * @param semaphore - Semaphore or Mutex from `wait-your-turn` package.
 */
export declare function lock(semaphore: Pick<Semaphore, "acquire">): Promise<Disposable>;
