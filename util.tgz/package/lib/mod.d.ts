import "./polyfill_node.js";
import assert from "tiny-invariant";
export { assert };
export { console, concatBuffers, delay } from "./platform_node.js";
export * from "./buffer.js";
export * from "./closers.js";
export * from "./crypto.js";
export * from "./event.js";
export * from "./iter.js";
export * from "./key-map.js";
export * from "./number.js";
export * from "./reorder.js";
export * from "./string.js";
export * from "./timer.js";
/** @deprecated Use `crypto` global object instead. */
export declare const crypto: Crypto;
