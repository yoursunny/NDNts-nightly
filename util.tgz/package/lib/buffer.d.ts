/** Convert ArrayBuffer or ArrayBufferView to Uint8Array. */
export declare function asUint8Array(a: BufferSource): Uint8Array;
/** Convert ArrayBuffer or ArrayBufferView to DataView. */
export declare function asDataView(a: BufferSource): DataView;
