/** Convert (Shared)ArrayBuffer(View) to Uint8Array. */
export declare function asUint8Array(a: ArrayBufferLike | ArrayBufferView): Uint8Array;
/** Convert (Shared)ArrayBuffer(View) to DataView. */
export declare function asDataView(a: ArrayBufferLike | ArrayBufferView): DataView;
/** Convert Uint8Array&lt;(Shared)ArrayBuffer&gt; to Uint8Array<ArrayBuffer>. */
export declare function asBufferSource(a: Uint8Array): BufferSource;
