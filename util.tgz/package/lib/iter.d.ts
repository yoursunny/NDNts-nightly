import type { AnyIterable } from "streaming-iterables";
/** An iterable that you can push values into. */
export interface Pushable<T> extends AsyncIterable<T> {
    /** Push a value. */
    push: (value: T) => void;
    /** End the iterable normally. */
    stop: () => void;
    /** End the iterable abnormally. */
    fail: (err: Error) => void;
}
/**
 * Create an iterable that you can push values into.
 * @typeParam T - Value type.
 * @returns AsyncIterable with push method.
 *
 * @remarks
 * Inspired by {@link https://www.npmjs.com/package/it-pushable | it-pushable} but implemented on
 * top of {@link https://www.npmjs.com/package/event-iterator | event-iterator} library.
 */
export declare function pushable<T>(): Pushable<T>;
/**
 * Yield all values from an iterable but catch any error.
 * @param iterable - Input iterable.
 * @param onError - Callback to receive errors thrown by the iterable.
 * @returns Iterable that does not throw errors.
 */
export declare function safeIter<T>(iterable: AnyIterable<T>, onError?: (err?: unknown) => void): AsyncIterableIterator<T>;
/**
 * Perform flatMap on an (async) iterable, but flatten at most once.
 * @remarks
 * flatMap of streaming-iterables recursively flattens the result.
 * This function flattens at most once.
 */
export declare function flatMapOnce<T, R>(f: (item: T) => AnyIterable<R>, iterable: AnyIterable<T>): AsyncIterable<R>;
/**
 * Retrieve or insert value in a Map-like container.
 * @param ct - Map-like container.
 * @param key - Map key.
 * @param make - Function to create the value if needed.
 * @returns Existing or newly created value.
 */
export declare function getOrInsert<C extends getOrInsert.Container>(ct: C, key: Parameters<C["get"]>[0] & Parameters<C["set"]>[0], make: () => Parameters<C["set"]>[1]): Parameters<C["set"]>[1];
export declare namespace getOrInsert {
    interface Container {
        get: (key: any) => any | undefined;
        set: (key: any, value: any) => void;
    }
}
/**
 * Delete keys from a Set or Map until its size is below capacity.
 * @param capacity - Maximum size after eviction.
 * @param ct - Container.
 * @param deleteCallback - Callback before item is deleted.
 */
export declare function evict<K>(capacity: number, ct: evict.Container<K>, deleteCallback?: (key: K) => void): void;
export declare namespace evict {
    type Container<K> = Pick<Set<K> & Map<K, unknown>, "delete" | "size" | "keys">;
}
