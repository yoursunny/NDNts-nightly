import type { AnyIterable } from "streaming-iterables";
/** An iterable that you can push values into. */
export interface Pushable<T> extends AsyncIterable<T> {
    /** Push a value. */
    push: (value: T) => void;
    /** End the iterable normally. */
    stop: () => void;
    /** End the iterable abnormally. */
    fail: (err: Error) => void;
}
/**
 * Create an iterable that you can push values into.
 * @typeParam T - Value type.
 * @returns AsyncIterable with push method.
 *
 * @remarks
 * Inspired by {@link https://www.npmjs.com/package/it-pushable | it-pushable} but implemented on
 * top of {@link https://www.npmjs.com/package/event-iterator | event-iterator} library.
 */
export declare function pushable<T>(): Pushable<T>;
/**
 * Yield all values from an iterable but catch any error.
 * @param iterable - Input iterable.
 * @param onError - Callback to receive errors thrown by the iterable.
 * @returns Iterable that does not throw errors.
 */
export declare function safeIter<T>(iterable: AnyIterable<T>, onError?: (err?: unknown) => void): AsyncIterableIterator<T>;
/**
 * Perform flatMap on an (async) iterable, but flatten at most once.
 * @remarks
 * flatMap of streaming-iterables recursively flattens the result.
 * This function flattens at most once.
 */
export declare function flatMapOnce<T, R>(f: (item: T) => AnyIterable<R>, iterable: AnyIterable<T>): AsyncIterable<R>;
/** Delete keys from a Set or Map until its size is below capacity. */
export declare function evict<K>(capacity: number, ct: evict.Container<K>): void;
export declare namespace evict {
    type Container<K> = Pick<Set<K> & Map<K, unknown>, "delete" | "size" | "keys">;
}
