/** Reorder items according to their index numbers. */
export declare class Reorder<T> {
    private next;
    private readonly buffer;
    constructor(first?: number);
    /** Return number of items in buffer. */
    get size(): number;
    /** Determine whether buffer is empty, i.e. all items emitted. */
    get empty(): boolean;
    /** Add a new item. */
    push(index: number, obj: T): void;
    /** Return and remove in-order items. */
    shift(): T[];
}
