/** Convert byte array to upper-case hexadecimal string. */
export declare function toHex(buf: Uint8Array): string;
export declare namespace toHex {
    /** Conversion table from byte (0x00~0xFF) to upper-case hexadecimal. */
    const TABLE: Readonly<Record<number, string>>;
}
/**
 * Convert hexadecimal string to byte array.
 * @param s - Input hexadecimal string (case insensitive).
 *
 * @remarks
 * The input is expected to be valid hexadecimal string.
 * If the input is invalid, the output would be wrong, but no error would be thrown.
 */
export declare function fromHex(s: string): Uint8Array<ArrayBuffer>;
export declare namespace fromHex {
    /** Conversion table from hexadecimal digit (case insensitive) to nibble. */
    const TABLE: Readonly<Record<string, number>>;
}
/** Convert string to UTF-8 byte array. */
export declare function toUtf8(s: string): Uint8Array<ArrayBuffer>;
/** Convert UTF-8 byte array to string. */
export declare function fromUtf8(buf: Uint8Array): string;
