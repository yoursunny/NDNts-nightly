/**
 * Map that transforms keys.
 * @typeParam K - Input key type.
 * @typeParam V - Value type.
 * @typeParam I - Indexable key type.
 * @typeParam L - Lookup key type.
 */
export declare class KeyMap<K, V, I, L = K> implements Iterable<[key: K, value: V]> {
    private readonly keyOf;
    /**
     * Constructor.
     * @param keyOf - Function to transform input key to indexable key.
     */
    constructor(keyOf: (key: K | L) => I);
    private readonly m;
    get size(): number;
    has(key: K | L): boolean;
    get(key: K | L): V | undefined;
    set(key: K, value: V): this;
    delete(key: K | L): boolean;
    [Symbol.iterator](): IterableIterator<[key: K, value: V]>;
}
/**
 * MultiMap that transforms keys.
 * @typeParam K - Input key type.
 * @typeParam V - Value type.
 * @typeParam I - Indexable key type.
 * @typeParam L - Lookup key type.
 */
export declare class KeyMultiMap<K, V, I, L = K> implements Iterable<[key: K, value: V]> {
    /**
     * Constructor.
     * @param keyOf - Function to transform input key to indexable key.
     */
    constructor(keyOf: (key: K | L) => I);
    private readonly m;
    private size_;
    /** Number of distinct keys. */
    get dimension(): number;
    /** Number of values. */
    get size(): number;
    /** Count values associated with a key. */
    count(key: K | L): number;
    /** List values associated with a key. */
    list(key: K | L): ReadonlySet<V>;
    /**
     * Add a key-value pair.
     * Values are stored in a Set, so duplicates are skipped.
     * @returns count(key) after the operation.
     */
    add(key: K, value: V): number;
    /**
     * Remove a key-value pair.
     * No-op if key-value does not exist.
     * @returns `count(key)` after the operation.
     */
    remove(key: K | L, value: V): number;
    /** Iterate over key and associated values. */
    associations(): IterableIterator<[key: K, values: ReadonlySet<V>]>;
    /** Iterate over key-value pairs. */
    [Symbol.iterator](): IterableIterator<[key: K, value: V]>;
}
/** Container that associates a key with multiple distinct values. */
export declare class MultiMap<K, V> extends KeyMultiMap<K, V, K> {
    constructor();
}
/**
 * MultiSet that transforms keys.
 * @typeParam K - Input key type.
 * @typeParam I - Indexable key type.
 * @typeParam L - Lookup key type.
 */
export declare class KeyMultiSet<K, I, L = K> {
    /**
     * Constructor.
     * @param keyOf - Function to transform input key to indexable key.
     */
    constructor(keyOf: (key: K | L) => I);
    private readonly m;
    private size_;
    /** Number of distinct keys. */
    get dimension(): number;
    /** Number of values. */
    get size(): number;
    /** Count occurrences of a key. */
    count(key: K | L): number;
    /**
     * Add a key.
     * @returns Number of occurrences after the operation.
     */
    add(key: K): number;
    /**
     * Remove a key.
     * No-op if key does not exist.
     * @returns Number of occurrences after the operation.
     */
    remove(key: K): number;
    /** Iterate over key and number of occurrences. */
    multiplicities(): IterableIterator<[key: K, count: number]>;
}
