import { KeyChain } from "@ndn/keychain";
import { Name, Signer } from "@ndn/packet";
/** Open the KeyChain specified by NDNTS_KEYCHAIN environ. */
export declare function openKeyChain(): KeyChain;
export declare function getSignerImpl(prefix?: Name): Promise<Signer>;
/** Get the KeyChain signer specified by NDNTS_KEY environ. */
export declare function getSigner(): Promise<Signer>;
