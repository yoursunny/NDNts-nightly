/// <reference types="node" />
import { Name } from "@ndn/packet";
import { URL } from "url";
export declare const env: import("@strattadb/environment").Env<{
    keychain: string | undefined;
    key: Name | undefined;
    pkttrace: boolean;
    uplink: URL;
    mtu: number;
    nfdreg: boolean;
    nfdregkey: Name | undefined;
}>;
