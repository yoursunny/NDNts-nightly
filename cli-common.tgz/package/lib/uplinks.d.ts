import { FwFace } from "@ndn/fw";
/** Open the uplinks specified by NDNTS_UPLINK environ. */
export declare function openUplinks(): Promise<FwFace[]>;
/** Close the uplinks. */
export declare function closeUplinks(): void;
