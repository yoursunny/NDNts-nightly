import { type FwFace } from "@ndn/fw";
/** Open the uplinks specified by `NDNTS_UPLINK` environ. */
export declare function openUplinks({ autoClose }?: openUplinks.Options): Promise<FwFace[]>;
export declare namespace openUplinks {
    interface Options {
        /**
         * Whether to automatically close uplinks at exit.
         * @defaultValue true
         */
        autoClose?: boolean;
    }
}
/** Close the uplinks. */
export declare function closeUplinks(): void;
