import { Closers } from "@ndn/util";
/** Print diagnostics to help determine why the program cannot exit. */
export declare function wtf(): void;
/** A list of objects to be closed or disposed upon program exit. */
export declare const exitClosers: Closers;
/** SIGINT (CTRL+C) handler. */
export declare function exitHandler(): void;
