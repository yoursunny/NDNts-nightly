import type { Arguments, Argv, CommandModule } from "yargs";
interface Args {
    issuer: string;
    "issuer-id": string;
    "valid-days": number;
    "use-key-name-locator": boolean;
}
export declare class IssueCertCommand implements CommandModule<{}, Args> {
    command: string;
    describe: string;
    builder(argv: Argv): Argv<Args>;
    handler({ issuer, "issuer-id": issuerIdInput, "valid-days": validDays, "use-key-name-locator": useKeyNameKeyLocator, }: Arguments<Args>): Promise<void>;
}
export {};
