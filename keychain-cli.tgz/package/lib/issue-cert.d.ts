import { Component, Name } from "@ndn/packet";
import type { CommandModule } from "yargs";
interface Args {
    issuer: Name;
    "issuer-id": Component;
    "valid-days": number;
    "use-key-name-locator": boolean;
}
export declare const IssueCertCommand: CommandModule<{}, Args>;
export {};
