import type { CommandModule } from "yargs";
export declare class AddCertCommand implements CommandModule {
    command: string;
    describe: string;
    handler(): Promise<void>;
}
