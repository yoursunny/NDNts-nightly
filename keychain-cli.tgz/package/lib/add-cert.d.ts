import type { CommandModule } from "yargs";
export declare const AddCertCommand: CommandModule;
