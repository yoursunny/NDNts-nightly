import type { CommandModule } from "yargs";
export declare class ListCertsCommand implements CommandModule {
    command: string;
    describe: string;
    aliases: string[];
    handler(): Promise<void>;
}
