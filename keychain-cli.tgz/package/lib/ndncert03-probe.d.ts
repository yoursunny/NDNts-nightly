import type { CommandModule } from "yargs";
import { PPOption } from "./util.js";
interface Args {
    profile: string;
    pp: PPOption;
}
export declare const Ndncert03ProbeCommand: CommandModule<{}, Args>;
export {};
