import type { CommandModule } from "yargs";
export declare class ListKeysCommand implements CommandModule {
    command: string;
    describe: string;
    aliases: string[];
    handler(): Promise<void>;
}
