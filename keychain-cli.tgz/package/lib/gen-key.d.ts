import { EcCurve, PrivateKey, PublicKey, RsaModulusLength } from "@ndn/keychain";
import { NameLike } from "@ndn/packet";
import type { Arguments, Argv, CommandModule } from "yargs";
declare type TypeChoice = "ec" | "rsa" | "hmac";
interface Args extends GenKeyCommand.KeyParamArgs {
    name: string;
}
export declare class GenKeyCommand implements CommandModule<{}, Args> {
    command: string;
    describe: string;
    aliases: string[];
    builder(argv: Argv): Argv<Args>;
    handler(args: Arguments<Args>): Promise<void>;
}
export declare namespace GenKeyCommand {
    interface KeyParamArgs {
        type: TypeChoice;
        curve: EcCurve;
        "modulus-length": RsaModulusLength;
    }
    function declareKeyParamArgs<T>(argv: Argv<T>): Argv<T & KeyParamArgs>;
    function generateKey(name: NameLike, { type, curve, "modulus-length": modulusLength, }: KeyParamArgs): Promise<{
        pvt: PrivateKey;
        pub: PublicKey;
        canSelfSign: boolean;
    }>;
}
export {};
