import { EcCurve, RsaModulusLength } from "@ndn/keychain";
import { Name } from "@ndn/packet";
import type { CommandModule } from "yargs";
declare const typeChoices: readonly ["ec", "rsa", "hmac"];
type TypeChoice = typeof typeChoices[number];
interface Args {
    name: Name;
    type: TypeChoice;
    curve: EcCurve;
    "modulus-length": RsaModulusLength;
}
export declare const GenKeyCommand: CommandModule<{}, Args>;
export {};
