import type { CommandModule } from "yargs";
export declare const ListKeysCommand: CommandModule;
export declare const ListCertsCommand: CommandModule;
