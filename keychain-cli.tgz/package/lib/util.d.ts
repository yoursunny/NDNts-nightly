import { Certificate, type KeyChain } from "@ndn/keychain";
import { CaProfile, type ParameterKV } from "@ndn/ndncert";
import { type Decodable } from "@ndn/tlv";
export declare const keyChain: KeyChain;
/** Read base64 object from file or stdin. */
export declare function inputBase64<R>(d: Decodable<R>, filename?: string): Promise<R>;
/** Read base64 certificate from file or stdin. */
export declare function inputCertBase64(filename?: string): Promise<Certificate>;
/**
 * Read or retrieve CA profile from file or name.
 * @param filename - Filename or NDN name.
 * @param strict - If true, must be a binary file; otherwise, retrieval is allowed.
 */
export declare function inputCaProfile(filename: string, strict?: boolean): Promise<CaProfile>;
/** yargs `.pp` (probe parameter) option definition. */
export type PPOption = string | string[];
export declare namespace PPOption {
    /**
     * Define `.pp` option with `.option("pp", PPOption.def)`.
     * It's compatible with {@link promptProbeParameters} `known` parameter.
     */
    const def: {
        readonly desc: "PROBE parameter key value pair";
        readonly default: string[];
        readonly nargs: 2;
        readonly type: "string";
    };
}
/**
 * Prompt for PROBE parameters.
 * @param profile - CA profile.
 * @param known - Alternated key value pairs, such as `["email", "someone@contoso.com"]`.
 */
export declare function promptProbeParameters(profile: CaProfile, known: readonly string[]): Promise<ParameterKV>;
/** Write certificate base64 to stdout. */
export declare function printCertBase64(cert: Certificate): void;
