import { Certificate, KeyChain } from "@ndn/keychain";
import { CaProfile } from "@ndn/ndncert";
import { Decodable } from "@ndn/tlv";
export declare const keyChain: KeyChain;
export declare function inputBase64<R>(d: Decodable<R>, filename?: string): Promise<R>;
export declare function inputCertBase64(filename?: string): Promise<Certificate>;
export declare function inputCaProfile(filename: string): Promise<CaProfile>;
export declare function printCertBase64(cert: Certificate): void;
