import { Name } from "@ndn/packet";
import type { CommandModule } from "yargs";
interface Args {
    out: string;
    prefix: Name;
    info: string;
    cert: Name;
    "valid-days": number;
}
export declare const Ndncert03MakeProfileCommand: CommandModule<{}, Args>;
export {};
