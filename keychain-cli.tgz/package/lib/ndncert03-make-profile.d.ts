import type { Arguments, Argv, CommandModule } from "yargs";
interface Args {
    out: string;
    prefix: string;
    info: string;
    cert: string;
    "valid-days": number;
}
export declare class Ndncert03MakeProfileCommand implements CommandModule<{}, Args> {
    command: string;
    describe: string;
    builder(argv: Argv): Argv<Args>;
    handler(args: Arguments<Args>): Promise<void>;
}
export {};
