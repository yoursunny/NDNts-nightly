import type { Arguments, Argv, CommandModule } from "yargs";
interface Args {
    profile: string;
    store: string;
    challenge: string[];
    "possession-issuer"?: string;
}
export declare class Ndncert03CaCommand implements CommandModule<{}, Args> {
    command: string;
    describe: string;
    builder(argv: Argv): Argv<Args>;
    handler(args: Arguments<Args>): Promise<void>;
}
export {};
