import type { CommandModule } from "yargs";
interface Args {
    profile: string;
    store: string;
    challenge: readonly string[];
    "possession-issuer"?: string;
    "doh-server": string;
}
export declare const Ndncert03CaCommand: CommandModule<{}, Args>;
export {};
