import { Name } from "@ndn/packet";
import type { CommandModule } from "yargs";
import { PPOption } from "./util.js";
interface Args {
    profile: string;
    ndnsec: boolean;
    key?: Name;
    pp: PPOption;
    challenge: readonly string[];
    "pin-named-pipe"?: string;
    email?: string;
    "possession-cert"?: Name;
    "dns-domain"?: string;
}
export declare const Ndncert03ClientCommand: CommandModule<{}, Args>;
export {};
