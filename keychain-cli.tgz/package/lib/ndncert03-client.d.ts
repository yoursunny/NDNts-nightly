import type { Arguments, Argv, CommandModule } from "yargs";
interface Args {
    profile: string;
    ndnsec: boolean;
    key: string;
    challenge: string[];
    email?: string;
    "possession-cert"?: string;
}
export declare class Ndncert03ClientCommand implements CommandModule<{}, Args> {
    command: string;
    describe: string;
    builder(argv: Argv): Argv<Args>;
    handler(args: Arguments<Args>): Promise<void>;
}
export {};
