import type { CommandModule } from "yargs";
interface Args {
    passphrase: string;
}
export declare const ImportSafeBagCommand: CommandModule<{}, Args>;
export {};
