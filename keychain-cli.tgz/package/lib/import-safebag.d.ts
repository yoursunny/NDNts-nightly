import type { Arguments, Argv, CommandModule } from "yargs";
interface Args {
    passphrase: string;
}
export declare class ImportSafeBagCommand implements CommandModule<{}, Args> {
    command: string;
    describe: string;
    builder(argv: Argv): Argv<Args>;
    handler({ passphrase }: Arguments<Args>): Promise<void>;
}
export {};
