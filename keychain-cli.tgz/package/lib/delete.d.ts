import type { Arguments, Argv, CommandModule } from "yargs";
interface Args {
    name: string;
}
export declare class DeleteCommand implements CommandModule<{}, Args> {
    command: string;
    describe: string;
    builder(argv: Argv): Argv<Args>;
    handler({ name }: Arguments<Args>): Promise<void>;
}
export {};
