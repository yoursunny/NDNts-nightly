import { Name } from "@ndn/packet";
import type { CommandModule } from "yargs";
interface Args {
    name: Name;
}
export declare const DeleteCommand: CommandModule<{}, Args>;
export {};
