import type { CommandModule } from "yargs";
export declare class ImportNdnsecCommand implements CommandModule {
    command: string;
    describe: string;
    handler(): Promise<void>;
}
