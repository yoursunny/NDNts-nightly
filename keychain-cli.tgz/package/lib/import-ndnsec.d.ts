import type { CommandModule } from "yargs";
export declare const ImportNdnsecCommand: CommandModule;
