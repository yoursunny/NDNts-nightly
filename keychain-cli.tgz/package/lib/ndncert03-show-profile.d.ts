import type { Arguments, Argv, CommandModule } from "yargs";
interface Args {
    profile: string;
}
export declare class Ndncert03ShowProfileCommand implements CommandModule<{}, Args> {
    command: string;
    describe: string;
    builder(argv: Argv): Argv<Args>;
    handler(args: Arguments<Args>): Promise<void>;
}
export {};
