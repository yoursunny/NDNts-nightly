import type { CommandModule } from "yargs";
interface Args {
    profile: string;
    out?: string;
    json?: boolean;
    clientconf?: boolean;
}
export declare const Ndncert03ShowProfileCommand: CommandModule<{}, Args>;
export {};
