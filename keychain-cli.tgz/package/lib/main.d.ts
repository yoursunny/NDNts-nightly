export declare const COMMAND = "ndnts-keychain";
