import type { Except } from "type-fest";
import type { CaProfile } from "../packet/ca-profile.js";
import { type RetrieveCaProfileOptions } from "./retrieve-profile.js";
/**
 * client.conf format of NDNCERT C++ implementation.
 * @see {@link https://github.com/named-data/ndncert/blob/48903c2f37a737c97dc51481d9a1a72e766990f7/client.conf.sample}
 */
export interface ClientConf {
    "ca-list": ClientConf.CaProfile[];
}
export declare namespace ClientConf {
    interface CaProfile {
        "ca-prefix": string;
        certificate: string;
    }
}
/** Export CA profile as client.conf of NDNCERT C++ implementation. */
export declare function exportClientConf(profile: CaProfile): ClientConf;
/** Retrieve CA profile according to client.conf of NDNCERT C++ implementation. */
export declare function importClientConf(conf: ClientConf, opts?: Except<RetrieveCaProfileOptions, "caPrefix" | "caCertFullName">): Promise<CaProfile>;
