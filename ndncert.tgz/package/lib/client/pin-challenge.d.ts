import type { ParameterKV } from "../packet/mod.js";
import { ClientPinLikeChallenge } from "./pin-like-challenge.js";
/** The "pin" challenge where client receives a pin code through offline means. */
export declare class ClientPinChallenge extends ClientPinLikeChallenge {
    protected readonly prompt: ClientPinLikeChallenge.Prompt;
    readonly challengeId = "pin";
    constructor(prompt: ClientPinLikeChallenge.Prompt);
    start(): Promise<ParameterKV>;
}
