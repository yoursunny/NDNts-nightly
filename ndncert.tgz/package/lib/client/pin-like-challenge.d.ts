import type { ParameterKV } from "../packet/mod.js";
import type { ClientChallenge, ClientChallengeContext } from "./challenge.js";
/** Base of a challenge where client submits a server-generated pin code. */
export declare abstract class ClientPinLikeChallenge implements ClientChallenge {
    abstract readonly challengeId: string;
    protected abstract readonly prompt: ClientPinLikeChallenge.Prompt;
    abstract start(): Promise<ParameterKV>;
    next(context: ClientChallengeContext): Promise<ParameterKV>;
}
export declare namespace ClientPinLikeChallenge {
    /** Callback to prompt the user to enter a pin code. */
    type Prompt = (context: ClientChallengeContext) => Promise<string>;
}
