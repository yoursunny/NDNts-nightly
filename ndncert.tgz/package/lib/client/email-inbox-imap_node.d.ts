import type { Config as ImapConfig } from "imap";
import type { ClientPinLikeChallenge } from "./pin-like-challenge.js";
/** Receive email via IMAP for automatically solving email challenge. */
export declare class ClientEmailInboxImap {
    readonly address: string;
    private readonly extract;
    constructor(address: string, imap: ImapConfig, extract?: ClientEmailInboxImap.ExtractOptions);
    private readonly client;
    private readonly connectPromise;
    private since;
    /** Close IMAP connection. */
    close(): Promise<void>;
    /** ClientEmailChallenge prompt callback. */
    readonly promptCallback: ClientPinLikeChallenge.Prompt;
    private checkEmails;
    private extractFrom;
    private checkToAddress;
}
export declare namespace ClientEmailInboxImap {
    /** Options for extracting PIN from email message. */
    interface ExtractOptions {
        /**
         * Whether to check To header contains requesting email address.
         * @defaultValue true
         */
        checkTo?: boolean;
        /**
         * Whether to extract PIN from email subject.
         * @defaultValue true
         */
        useSubject?: boolean;
        /**
         * Whether to extract PIN from email text.
         * @defaultValue true
         */
        useText?: boolean;
        /**
         * Whether to extract PIN from email HTML.
         * @defaultValue false
         */
        useHtml?: boolean;
        /**
         * Regular Expression to extract PIN into capture group 1.
         * @defaultValue
         * Accepting any 6-digit token.
         */
        regex?: RegExp;
    }
}
