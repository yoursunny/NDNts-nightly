import { type ConsumerOptions } from "@ndn/endpoint";
import type { Name } from "@ndn/packet";
import { CaProfile } from "../packet/mod.js";
/** {@link retrieveCaProfile} options. */
export interface RetrieveCaProfileOptions {
    /**
     * Consumer options.
     *
     * @remarks
     * - `.describe` defaults to "NDNCERT-client" + CA prefix.
     * - `.retx` defaults to 4.
     */
    cOpts?: ConsumerOptions;
    /**
     * CA prefix.
     * @defaultValue
     * Using the subject name of CA certificate name.
     */
    caPrefix?: Name;
    /** CA certificate name with implicit digest. */
    caCertFullName: Name;
}
/** Retrieve and validate CA profile. */
export declare function retrieveCaProfile({ cOpts, caPrefix, caCertFullName, }: RetrieveCaProfileOptions): Promise<CaProfile>;
