import { type ConsumerOptions } from "@ndn/endpoint";
import { Certificate, type NamedSigner, type NamedVerifier } from "@ndn/keychain";
import { type ValidityPeriod } from "@ndn/packet";
import { type CaProfile } from "../packet/mod.js";
import type { ClientChallenge } from "./challenge.js";
/** {@link requestCertificate} options. */
export interface ClientOptions {
    /**
     * Consumer options.
     *
     * @remarks
     * - `.describe` defaults to "NDNCERT-client" + CA prefix + key name.
     * - `.retx` defaults to 4.
     * - `.verifier` is overridden.
     */
    cOpts?: ConsumerOptions;
    /** CA profile. */
    profile: CaProfile;
    /** Private key corresponding to the public key. */
    privateKey: NamedSigner.PrivateKey;
    /** Public key to request certificate for. */
    publicKey: NamedVerifier.PublicKey;
    /**
     * ValidityPeriod of the certificate request.
     *
     * @remarks
     * This will be truncated to the maximum allowed by CA profile.
     */
    validity?: ValidityPeriod;
    /** Challenges in preferred order. */
    challenges: ClientChallenge[];
}
/** Request a certificate for the given key. */
export declare function requestCertificate({ cOpts, profile, privateKey, publicKey, validity, challenges, }: ClientOptions): Promise<Certificate>;
