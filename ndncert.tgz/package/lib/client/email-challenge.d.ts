import type { ParameterKV } from "../packet/mod.js";
import { ClientPinLikeChallenge } from "./pin-like-challenge.js";
/** The "email" challenge where client receives a pin code via email. */
export declare class ClientEmailChallenge extends ClientPinLikeChallenge {
    private readonly email;
    protected readonly prompt: ClientPinLikeChallenge.Prompt;
    readonly challengeId = "email";
    constructor(email: string, prompt: ClientPinLikeChallenge.Prompt);
    start(): Promise<ParameterKV>;
}
