import { type ConsumerOptions, type Endpoint } from "@ndn/endpoint";
import type { Name } from "@ndn/packet";
import { type CaProfile, type ParameterKV, ProbeResponse } from "../packet/mod.js";
/** {@link requestProbe} options. */
export interface ClientProbeOptions {
    /**
     * Endpoint for communication.
     * @deprecated Specify `.cOpts`.
     */
    endpoint?: Endpoint;
    /**
     * Consumer options.
     *
     * @remarks
     * - `.describe` defaults to "NDNCERT-client" + CA prefix.
     * - `.retx` defaults to 4.
     * - `.verifier` is overridden.
     */
    cOpts?: ConsumerOptions;
    /** CA profile. */
    profile: CaProfile;
    /** PROBE parameters. */
    parameters: ParameterKV;
}
/** Run PROBE command to determine available names. */
export declare function requestProbe({ endpoint, // eslint-disable-line etc/no-deprecated
cOpts, profile, parameters, }: ClientProbeOptions): Promise<ProbeResponse.Fields>;
/**
 * Determine if a subject name is acceptable according to probe response.
 * @param probeResponse - Probe response from CA.
 * @param name - Subject name, key name, or certificate name.
 * Only the subject name portion is considered.
 */
export declare function matchProbe(probeResponse: ProbeResponse.Fields, name: Name): boolean;
