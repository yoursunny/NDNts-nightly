import type { Promisable } from "type-fest";
import { ParameterKV } from "../packet/mod.js";
import type { ClientChallenge, ClientChallengeContext } from "./challenge.js";
declare abstract class ClientDnsChallengeBase {
    protected readonly domain: string;
    protected readonly prompt: ClientDnsChallenge.Prompt;
    private recordName;
    private recordValue;
    constructor(domain: string, prompt: ClientDnsChallenge.Prompt);
    start(): Promise<ParameterKV>;
    next(context: ClientChallengeContext): Promise<ParameterKV>;
    protected abstract handleNeedRecord(context: ClientChallengeContext): Promisable<[recordName: string, recordValue: string]>;
}
/** The "dns" challenge where client creates a DNS TXT record containing a challenge token. */
export declare class ClientDnsChallenge extends ClientDnsChallengeBase implements ClientChallenge {
    readonly challengeId = "dns";
    protected handleNeedRecord({ parameters }: ClientChallengeContext): [record: string, expected: string];
}
export declare namespace ClientDnsChallenge {
    /** Callback to prompt the user to insert a DNS TXT record. */
    type Prompt = (context: ClientChallengeContext, recordName: string, recordValue: string) => Promise<void>;
}
/** The "dns-01" challenge where client creates a DNS TXT record containing a key authorization value. */
export declare class ClientDns01Challenge extends ClientDnsChallengeBase implements ClientChallenge {
    readonly challengeId = "dns-01";
    protected handleNeedRecord({ certRequest, parameters }: ClientChallengeContext): Promise<[recordName: string, recordValue: string]>;
}
export {};
