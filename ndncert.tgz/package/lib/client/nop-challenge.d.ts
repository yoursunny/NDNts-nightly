import type { ParameterKV } from "../packet/mod.js";
import type { ClientChallenge } from "./challenge.js";
/** The "nop" challenge where the server would approve every request. */
export declare class ClientNopChallenge implements ClientChallenge {
    readonly challengeId = "nop";
    start(): Promise<ParameterKV>;
    next(): Promise<ParameterKV>;
}
