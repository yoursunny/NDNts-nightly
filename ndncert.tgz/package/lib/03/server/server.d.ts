import { Endpoint } from "@ndn/endpoint";
import type { FwHint, Signer } from "@ndn/packet";
import { ComponentLike, Data } from "@ndn/packet";
import { CaProfile } from "../packet/mod";
import type { ServerChallenge } from "./challenge";
export interface ServerOptions {
    /** Endpoint for communication. */
    endpoint?: Endpoint;
    /** Repo for storing issued certificates. */
    repo: RepoDataStore;
    /** Forwarding hint to retrieve certificates from the repo. */
    repoFwHint?: FwHint;
    /** The CA profile. */
    profile: CaProfile;
    /** CA private key, must match the certificate in the CA profile. */
    signer: Signer;
    /** Supported challenges. */
    challenges: readonly ServerChallenge[];
    /** IssuerId on issued certificates. */
    issuerId?: ComponentLike;
}
interface RepoDataStore {
    insert: (data: Data) => Promise<void>;
}
/** NDNCERT server. */
export declare class Server {
    private readonly repo;
    private readonly repoFwHint;
    private readonly profile;
    private readonly signer;
    private readonly challenges;
    private readonly issuerId;
    static create({ endpoint, repo, repoFwHint, profile, signer, challenges, issuerId, }: ServerOptions): Server;
    private readonly state;
    private cleanupTimer;
    private readonly producers;
    private readonly signedInterestPolicy;
    private constructor();
    close(): void;
    private handleInfoInterest;
    private handleProbeInterest;
    private handleNewInterest;
    private handleChallengeInterest;
    private startChallenge;
    private continueChallenge;
    private finishChallenge;
    private makeResponseCommon;
    private lookupContext;
    private deleteContext;
    private cleanupContext;
}
export {};
