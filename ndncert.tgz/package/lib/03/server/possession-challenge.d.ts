import { Certificate } from "@ndn/keychain";
import { Name, Verifier } from "@ndn/packet";
import type { ChallengeRequest } from "../packet/mod";
import type { ServerChallenge, ServerChallengeContext, ServerChallengeResponse } from "./challenge";
interface State {
    cert: Uint8Array;
    nonce: Uint8Array;
}
/** The "possession" challenge where client must present an existing certificate. */
export declare class ServerPossessionChallenge implements ServerChallenge<State> {
    private readonly verifier;
    private readonly assignmentPolicy?;
    readonly challengeId = "possession";
    readonly timeLimit = 60000;
    readonly retryLimit = 1;
    /**
     * Constructor.
     * @param verifier a verifier to accept or reject an existing certificate presented by client.
     *                 This may be a public key of the expected issuer or a trust schema validator.
     * @param assignmentPolicy name assignment policy callback. Default permits all assignments.
     */
    constructor(verifier: Verifier, assignmentPolicy?: ServerPossessionChallenge.AssignmentPolicy | undefined);
    process(request: ChallengeRequest, context: ServerChallengeContext<State>): Promise<ServerChallengeResponse>;
    private process0;
    private process1;
}
export declare namespace ServerPossessionChallenge {
    /**
     * Callback to determine whether the owner of `oldCert` is allowed to obtain a certificate
     * of `newSubjectName`. It should throw to disallow assignment.
     */
    type AssignmentPolicy = (newSubjectName: Name, oldCert: Certificate) => Promise<void>;
}
export {};
