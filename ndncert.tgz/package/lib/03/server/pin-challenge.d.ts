import type TypedEmitter from "typed-emitter";
import type { ChallengeRequest } from "../packet/mod";
import type { ServerChallenge } from "./challenge";
import { ServerPinLikeChallenge } from "./pin-like-challenge";
interface Events {
    /** Emitted when a pin code has been generated. */
    newpin: (requestId: Uint8Array, pin: string) => void;
}
declare const ServerPinChallenge_base: new () => TypedEmitter<Events>;
/** The "pin" challenge where client receives a pin code through offline means. */
export declare class ServerPinChallenge extends ServerPinChallenge_base implements ServerChallenge {
    readonly challengeId = "pin";
    readonly timeLimit = 3600000;
    readonly retryLimit = 3;
    protected start(request: ChallengeRequest): Promise<ServerPinLikeChallenge.State>;
}
export interface ServerPinChallenge extends ServerPinLikeChallenge {
}
export {};
