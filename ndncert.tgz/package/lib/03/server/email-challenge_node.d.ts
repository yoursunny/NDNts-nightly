import type { Name } from "@ndn/packet";
import type { SendMailOptions, SentMessageInfo, Transporter } from "nodemailer";
import type TypedEmitter from "typed-emitter";
import type { ChallengeRequest } from "../packet/mod";
import type { ServerChallenge, ServerChallengeContext, ServerChallengeResponse } from "./challenge";
import { ServerPinLikeChallenge } from "./pin-like-challenge";
declare type State = ServerPinLikeChallenge.State;
interface Events {
    /** Emitted after sending an email. */
    emailsent: (requestId: Uint8Array, sent: SentMessageInfo) => void;
    /** Emitted after failure to send an email. */
    emailerror: (requestId: Uint8Array, err: Error) => void;
}
declare const ServerEmailChallenge_base: new () => TypedEmitter<Events>;
/** The "email" challenge where client receives a pin code via email. */
export declare class ServerEmailChallenge extends ServerEmailChallenge_base implements ServerChallenge {
    readonly challengeId = "email";
    readonly timeLimit = 300000;
    readonly retryLimit = 3;
    private readonly assignmentPolicy?;
    private readonly mail;
    private readonly template;
    constructor(opts: ServerEmailChallenge.Options);
    protected start({ requestId, parameters: { email } }: ChallengeRequest, { profile, subjectName, keyName }: ServerChallengeContext<State>): Promise<State | ServerChallengeResponse>;
    private prepareMail;
}
export interface ServerEmailChallenge extends ServerPinLikeChallenge {
}
export declare namespace ServerEmailChallenge {
    /**
     * Callback to determine whether the owner of `email` is allowed to obtain a certificate
     * of `newSubjectName`. It should throw to disallow assignment.
     */
    type AssignmentPolicy = (newSubjectName: Name, email: string) => Promise<void>;
    /**
     * Email template.
     *
     * In subject, text, and html fields, the following variables will be replaced:
     * - $caPrefix$
     * - $requestId$
     * - $subjectName$
     * - $keyName$
     * - $pin$
     *
     * disableUrlAccess and disableFileAccess are set to true by default,
     * but they may be overridden in the template object.
     */
    type Template = {
        from: string;
        subject: string;
        text: string;
        html?: string;
    } & Omit<SendMailOptions, "to" | "text" | "html" | "raw">;
    interface Options {
        assignmentPolicy?: AssignmentPolicy;
        mail: Transporter;
        template: Template;
    }
}
export {};
