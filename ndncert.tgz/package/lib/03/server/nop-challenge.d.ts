import type { ServerChallenge, ServerChallengeResponse } from "./challenge";
/** The "nop" challenge where the server would approve every request. */
export declare class ServerNopChallenge implements ServerChallenge<never> {
    readonly challengeId = "nop";
    readonly timeLimit = 60000;
    readonly retryLimit = 1;
    process(): Promise<ServerChallengeResponse>;
}
