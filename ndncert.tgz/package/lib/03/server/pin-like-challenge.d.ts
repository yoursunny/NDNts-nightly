import type { ChallengeRequest } from "../packet/mod";
import type { ServerChallenge, ServerChallengeContext, ServerChallengeResponse } from "./challenge";
/** Base of a challenge where client submits a server-generated pin code. */
export declare abstract class ServerPinLikeChallenge<State extends ServerPinLikeChallenge.State = ServerPinLikeChallenge.State> implements ServerChallenge<State> {
    abstract readonly challengeId: string;
    abstract readonly timeLimit: number;
    abstract readonly retryLimit: number;
    /**
     * Validate a new request, create State object, and deliver PIN to client if applicable.
     * @param request the CHALLENGE request packet.
     * @param context the challenge context, which contains the certificate request.
     * @returns a State to continue the challenge, or a ServerChallengeResponse to fail the challenge.
     */
    protected abstract start(request: ChallengeRequest, context: ServerChallengeContext<State>): Promise<State | ServerChallengeResponse>;
    process(request: ChallengeRequest, context: ServerChallengeContext<State>): Promise<ServerChallengeResponse>;
}
export declare namespace ServerPinLikeChallenge {
    class State {
        readonly pin: Uint8Array;
        get pinString(): string;
        verify(code: Uint8Array): boolean;
    }
}
