import { Certificate } from "@ndn/keychain";
import { LLSign, Signer } from "@ndn/packet";
import type { ParameterKV } from "../packet/mod";
import type { ClientChallenge, ClientChallengeContext } from "./challenge";
/** The "possession" challenge where client must present an existing certificate. */
export declare class ClientPossessionChallenge implements ClientChallenge {
    private readonly cert;
    readonly challengeId = "possession";
    private readonly llSign;
    /**
     * Constructor.
     * @param cert existing certificate, typically issued by another CA.
     * @param pvt private key corresponding to `cert`.
     *            This is preferably a low-level signer, but can also accept a high-level signer
     *            that unconditionally signs the input regardless of the packet name.
     */
    constructor(cert: Certificate, pvt: LLSign | Signer);
    start(): Promise<ParameterKV>;
    next({ parameters }: ClientChallengeContext): Promise<ParameterKV>;
}
