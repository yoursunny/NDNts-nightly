import { Endpoint, RetxPolicy } from "@ndn/endpoint";
import { Certificate, NamedSigner, NamedVerifier, ValidityPeriod } from "@ndn/keychain";
import { CaProfile } from "../packet/mod";
import type { ClientChallenge } from "./challenge";
export interface ClientOptions {
    /** Endpoint for communication. */
    endpoint?: Endpoint;
    /** Interest retransmission policy, default is 4 retransmissions. */
    retx?: RetxPolicy;
    profile: CaProfile;
    privateKey: NamedSigner.PrivateKey;
    publicKey: NamedVerifier.PublicKey;
    /** ValidityPeriod, will be truncated to the maximum allowed by CA profile. */
    validity?: ValidityPeriod;
    /** Challenges in preferred order. */
    challenges: ClientChallenge[];
}
/** Request a certificate for the given key. */
export declare function requestCertificate({ endpoint, retx, profile, privateKey, publicKey, validity, challenges, }: ClientOptions): Promise<Certificate>;
