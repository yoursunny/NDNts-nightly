import { NamedSigner, NamedVerifier } from "@ndn/keychain";
import { Interest, LLDecrypt, LLEncrypt, SignedInterestPolicy } from "@ndn/packet";
import * as crypto from "../crypto-common";
import type { CaProfile } from "./ca-profile";
import * as parameter_kv from "./parameter-kv";
interface RequestInfo {
    sessionKey: Pick<crypto.SessionKey, "sessionDecrypter">;
    certRequestPub: NamedVerifier.PublicKey;
}
/** CHALLENGE request packet. */
export declare class ChallengeRequest {
    readonly interest: Interest;
    static fromInterest(interest: Interest, { profile, signedInterestPolicy, lookupRequest, }: ChallengeRequest.Context): Promise<ChallengeRequest>;
    private constructor();
    get requestId(): Uint8Array;
}
export interface ChallengeRequest extends Readonly<ChallengeRequest.Fields> {
}
export declare namespace ChallengeRequest {
    interface ContextBase {
        profile: CaProfile;
        signedInterestPolicy: SignedInterestPolicy;
    }
    export interface Context extends ContextBase {
        lookupRequest: (requestId: Uint8Array) => Promise<RequestInfo | undefined>;
    }
    export interface Fields {
        selectedChallenge: string;
        parameters: parameter_kv.ParameterKV;
    }
    export interface Options extends ContextBase, Fields {
        requestId: Uint8Array;
        sessionEncrypter: LLEncrypt.Key;
        sessionLocalDecrypter: LLDecrypt.Key;
        publicKey: NamedVerifier.PublicKey;
        privateKey: NamedSigner.PrivateKey;
    }
    export function build({ profile, signedInterestPolicy, requestId, sessionEncrypter, sessionLocalDecrypter, publicKey, privateKey, selectedChallenge, parameters, }: Options): Promise<ChallengeRequest>;
    export {};
}
export {};
