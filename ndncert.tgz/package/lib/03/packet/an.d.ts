import { Component } from "@ndn/packet";
export declare const TT: {
    CaPrefix: number;
    CaInfo: number;
    ParameterKey: number;
    ParameterValue: number;
    CaCertificate: number;
    MaxValidityPeriod: number;
    ProbeResponse: number;
    MaxSuffixLength: number;
    EcdhPub: number;
    CertRequest: number;
    Salt: number;
    RequestId: number;
    Challenge: number;
    Status: number;
    InitializationVector: number;
    EncryptedPayload: number;
    SelectedChallenge: number;
    ChallengeStatus: number;
    RemainingTries: number;
    RemainingTime: number;
    IssuedCertName: number;
    ErrorCode: number;
    ErrorInfo: number;
    AuthenticationTag: number;
    CertToRevoke: number;
    ProbeRedirect: number;
};
export declare const C: {
    CA: Component;
    INFO: Component;
    PROBE: Component;
    NEW: Component;
    CHALLENGE: Component;
};
export declare enum Status {
    BEFORE_CHALLENGE = 0,
    CHALLENGE = 1,
    PENDING = 2,
    SUCCESS = 3,
    FAILURE = 4
}
export declare namespace Status {
    const MIN = 0;
    const MAX = 4;
}
export declare enum ErrorCode {
    BadInterestFormat = 1,
    BadParameterFormat = 2,
    BadSignature = 3,
    InvalidParameters = 4,
    NameNotAllowed = 5,
    BadValidityPeriod = 6,
    OutOfTries = 7,
    OutOfTime = 8,
    NoAvailableName = 9
}
