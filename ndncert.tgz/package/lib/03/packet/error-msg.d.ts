import { Data, Interest, Signer } from "@ndn/packet";
import { ErrorCode } from "./an";
export interface ErrorMsg {
    errorCode: number;
    errorInfo: string;
}
export declare namespace ErrorMsg {
    /** Create error message packet. */
    function makeData(errorCode: ErrorCode, { name }: Interest, signer: Signer): Promise<Data>;
    /** Parse error message packet. */
    function fromData({ content }: Data): ErrorMsg;
    /** Throw an exception if the given packet is an error message packet. */
    function throwOnError(data: Data): void;
}
