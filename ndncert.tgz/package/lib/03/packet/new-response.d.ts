import { Data, Signer } from "@ndn/packet";
import type { CaProfile } from "./ca-profile";
import type { NewRequest } from "./new-request";
/** NEW response packet. */
export declare class NewResponse {
    readonly data: Data;
    static fromData(data: Data, profile: CaProfile): Promise<NewResponse>;
    private constructor();
    private ecdhPub_;
    get ecdhPub(): CryptoKey;
}
export interface NewResponse extends Readonly<NewResponse.Fields> {
}
export declare namespace NewResponse {
    interface Fields {
        ecdhPubRaw: Uint8Array;
        salt: Uint8Array;
        requestId: Uint8Array;
        challenges: string[];
    }
    type Options = Omit<Fields, "ecdhPubRaw"> & {
        profile: CaProfile;
        request: NewRequest;
        ecdhPub: CryptoKey;
        signer: Signer;
    };
    function build({ profile, request: { interest: { name } }, ecdhPub, salt, requestId, challenges, signer, }: Options): Promise<NewResponse>;
}
