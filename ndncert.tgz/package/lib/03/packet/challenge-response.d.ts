import { Data, FwHint, LLDecrypt, LLEncrypt, Name, Signer } from "@ndn/packet";
import { Status } from "./an";
import type { CaProfile } from "./ca-profile";
import type { ChallengeRequest } from "./challenge-request";
import * as parameter_kv from "./parameter-kv";
/** CHALLENGE response packet. */
export declare class ChallengeResponse {
    readonly data: Data;
    static fromData(data: Data, profile: CaProfile, requestId: Uint8Array, sessionDecrypter: LLDecrypt.Key): Promise<ChallengeResponse>;
    private constructor();
}
export interface ChallengeResponse extends Readonly<ChallengeResponse.Fields> {
}
export declare namespace ChallengeResponse {
    interface Fields {
        status: Status;
        challengeStatus?: string;
        remainingTries?: number;
        remainingTime?: number;
        parameters?: parameter_kv.ParameterKV;
        issuedCertName?: Name;
        fwHint?: FwHint;
    }
    interface Options extends Fields {
        profile: CaProfile;
        sessionEncrypter: LLEncrypt.Key;
        sessionLocalDecrypter: LLDecrypt.Key;
        request: ChallengeRequest;
        signer: Signer;
    }
    function build(opts: Options): Promise<ChallengeResponse>;
}
