import { Encodable, EvDecoder } from "@ndn/tlv";
/** Parameter key-value pair. */
export declare type ParameterKV = Record<string, Uint8Array>;
export declare function parseEvDecoder<R extends {
    parameters?: ParameterKV;
}>(evd: EvDecoder<R>, order: number): void;
export declare function encode(kv?: ParameterKV): Encodable[];
