import { Certificate, NamedVerifier } from "@ndn/keychain";
import { Data, Name, Signer } from "@ndn/packet";
/** CA profile packet. */
export declare class CaProfile {
    readonly data: Data;
    static fromData(data: Data): Promise<CaProfile>;
    private constructor();
    private publicKey_;
    get publicKey(): NamedVerifier.PublicKey;
    private certDigest_;
    get certDigest(): Uint8Array;
    toString(): string;
}
export interface CaProfile extends Readonly<CaProfile.Fields> {
}
export declare namespace CaProfile {
    interface Fields {
        prefix: Name;
        info: string;
        probeKeys: string[];
        maxValidityPeriod: number;
        cert: Certificate;
    }
    type Options = Fields & {
        signer: Signer;
        version?: number;
    };
    function build({ prefix, info, probeKeys, maxValidityPeriod, cert, signer, version, }: Options): Promise<CaProfile>;
}
