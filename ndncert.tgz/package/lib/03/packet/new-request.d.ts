import { Certificate, NamedSigner, NamedVerifier, ValidityPeriod } from "@ndn/keychain";
import { Interest, SignedInterestPolicy } from "@ndn/packet";
import type { CaProfile } from "./ca-profile";
/** NEW request packet. */
export declare class NewRequest {
    readonly interest: Interest;
    static fromInterest(interest: Interest, { profile, signedInterestPolicy }: NewRequest.Context): Promise<NewRequest>;
    private constructor();
    private ecdhPub_;
    get ecdhPub(): CryptoKey;
    private publicKey_;
    get publicKey(): NamedVerifier.PublicKey;
}
export interface NewRequest extends Readonly<NewRequest.Fields> {
}
export declare namespace NewRequest {
    interface Context {
        profile: CaProfile;
        signedInterestPolicy: SignedInterestPolicy;
    }
    interface Fields {
        ecdhPubRaw: Uint8Array;
        certRequest: Certificate;
    }
    interface Options extends Context {
        ecdhPub: CryptoKey;
        publicKey: NamedVerifier.PublicKey;
        privateKey: NamedSigner.PrivateKey;
        validity?: ValidityPeriod;
    }
    function build({ profile, signedInterestPolicy, ecdhPub, publicKey, privateKey, validity, }: Options): Promise<NewRequest>;
}
