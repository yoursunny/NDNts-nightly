import type { SendMailOptions, SentMessageInfo, Transporter } from "nodemailer";
import type { OverrideProperties } from "type-fest";
import { type ChallengeRequest } from "../packet/mod.js";
import { ServerChallenge, type ServerChallengeContext, type ServerChallengeResponse } from "./challenge.js";
import { ServerPinLikeChallenge } from "./pin-like-challenge.js";
type State = ServerPinLikeChallenge.State;
type EventMap = {
    /** Emitted after sending an email. */
    emailsent: ServerEmailChallenge.SentEvent;
    /** Emitted after failure to send an email. */
    emailerror: ServerEmailChallenge.ErrorEvent;
};
/** The "email" challenge where client receives a pin code via email. */
export declare class ServerEmailChallenge extends ServerPinLikeChallenge<ServerPinLikeChallenge.State, EventMap> {
    readonly challengeId = "email";
    readonly timeLimit = 300000;
    readonly retryLimit = 3;
    private readonly assignmentPolicy?;
    private readonly mail;
    private readonly template;
    constructor(opts: ServerEmailChallenge.Options);
    protected start({ requestId, parameters: { email } }: ChallengeRequest, { profile, subjectName, keyName }: ServerChallengeContext<State>): Promise<State | ServerChallengeResponse>;
    private prepareMail;
}
export declare namespace ServerEmailChallenge {
    /**
     * Callback to determine whether the owner of an email address is allowed to obtain
     * a certificate of `newSubjectName`. It should throw or return false to disallow assignment.
     */
    type AssignmentPolicy = ServerChallenge.AssignmentPolicy<[string]>;
    /**
     * Email template.
     *
     * @remarks
     * In subject, text, and html fields, the following variables will be replaced:
     * - $caPrefix$
     * - $requestId$
     * - $subjectName$
     * - $keyName$
     * - $pin$
     *
     * `disableUrlAccess` and `disableFileAccess` are set to true by default,
     * but they may be overridden in the template object.
     */
    type Template = OverrideProperties<SendMailOptions, {
        from: string;
        subject: string;
        text: string;
        html?: string;
    }>;
    interface Options {
        /**
         * Name assignment policy.
         * If omitted, any email can obtain any certificate.
         */
        assignmentPolicy?: AssignmentPolicy;
        mail: Transporter;
        template: Template;
    }
    class SentEvent extends Event {
        readonly requestId: Uint8Array;
        readonly sent: SentMessageInfo;
        constructor(type: string, requestId: Uint8Array, sent: SentMessageInfo);
    }
    class ErrorEvent extends Event {
        readonly requestId: Uint8Array;
        readonly error: Error;
        constructor(type: string, requestId: Uint8Array, error: Error);
    }
}
export {};
