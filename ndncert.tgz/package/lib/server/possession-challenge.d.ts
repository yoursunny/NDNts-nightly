import { Certificate, type SigningAlgorithm } from "@ndn/keychain";
import { type Name, type Verifier } from "@ndn/packet";
import type { ChallengeRequest } from "../packet/mod.js";
import type { ServerChallenge, ServerChallengeContext, ServerChallengeResponse } from "./challenge.js";
interface State {
    cert: Uint8Array;
    nonce: Uint8Array;
}
/** The "possession" challenge where client must present an existing certificate. */
export declare class ServerPossessionChallenge implements ServerChallenge<State> {
    private readonly verifier;
    private readonly assignmentPolicy?;
    private readonly algoList;
    readonly challengeId = "possession";
    readonly timeLimit = 60000;
    readonly retryLimit = 1;
    /**
     * Constructor.
     * @param verifier - Verifier to accept or reject an existing certificate presented by client.
     *                   This may be a public key of the expected issuer or a trust schema validator.
     * @param assignmentPolicy - Name assignment policy callback. Default permits all assignments.
     * @param algoList - List of recognized algorithms for client certificates.
     * Default is {@link SigningAlgorithmListSlim}.
     */
    constructor(verifier: Verifier, assignmentPolicy?: ServerPossessionChallenge.AssignmentPolicy | undefined, algoList?: readonly SigningAlgorithm<any, any, any>[]);
    process(request: ChallengeRequest, context: ServerChallengeContext<State>): Promise<ServerChallengeResponse>;
    private process0;
    private process1;
}
export declare namespace ServerPossessionChallenge {
    /**
     * Callback to determine whether the owner of `oldCert` is allowed to obtain a certificate
     * of `newSubjectName`. It should throw to disallow assignment.
     */
    type AssignmentPolicy = (newSubjectName: Name, oldCert: Certificate) => Promise<void>;
}
export {};
