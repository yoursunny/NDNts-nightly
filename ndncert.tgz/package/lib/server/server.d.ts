import { type ProducerOptions } from "@ndn/endpoint";
import { type ComponentLike, type Data, type FwHint, type Signer } from "@ndn/packet";
import { type CaProfile, type ParameterKV, ProbeResponse } from "../packet/mod.js";
import type { ServerChallenge } from "./challenge.js";
export interface ServerOptions {
    /**
     * Producer options.
     *
     * @remarks
     * - `.describe` defaults to "NDNCERT-CA" + CA prefix.
     * - `.announcement` is overridden as CA prefix + "/CA".
     */
    pOpts?: ProducerOptions;
    /** Repo for storing issued certificates. */
    repo: RepoDataStore;
    /** Forwarding hint to retrieve certificates from the repo. */
    repoFwHint?: FwHint;
    /** The CA profile. */
    profile: CaProfile;
    /** CA private key, must match the certificate in the CA profile. */
    signer: Signer;
    /** PROBE command handler. */
    probe?: ServerOptions.ProbeHandler;
    /** Supported challenges. */
    challenges: readonly ServerChallenge[];
    /** IssuerId on issued certificates. */
    issuerId?: ComponentLike;
}
export declare namespace ServerOptions {
    type ProbeHandler = (parameters: ParameterKV) => Promise<Partial<ProbeResponse.Fields>>;
}
interface RepoDataStore {
    insert: (data: Data) => Promise<void>;
}
/** NDNCERT server. */
export declare class Server {
    private readonly repo;
    private readonly repoFwHint;
    private readonly profile;
    private readonly signer;
    private readonly probe;
    private readonly challenges;
    private readonly issuerId;
    static create({ pOpts, repo, repoFwHint, profile, signer, probe, challenges, issuerId, }: ServerOptions): Server;
    private readonly state;
    private cleanupTimer;
    private readonly producers;
    private readonly signedInterestPolicy;
    private constructor();
    close(): void;
    private readonly handleInfoInterest;
    private readonly handleProbeInterest;
    private readonly handleNewInterest;
    private readonly handleChallengeInterest;
    private startChallenge;
    private continueChallenge;
    private finishChallenge;
    private makeResponseCommon;
    private readonly lookupContext;
    private deleteContext;
    private readonly cleanupContext;
}
export {};
