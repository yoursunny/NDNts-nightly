import type { ChallengeRequest } from "../packet/mod.js";
import { ServerPinLikeChallenge } from "./pin-like-challenge.js";
type EventMap = {
    /** Emitted when a pin code has been generated. */
    newpin: ServerPinChallenge.PinEvent;
};
/** The "pin" challenge where client receives a pin code through offline means. */
export declare class ServerPinChallenge extends ServerPinLikeChallenge<ServerPinLikeChallenge.State, EventMap> {
    readonly challengeId = "pin";
    readonly timeLimit = 3600000;
    readonly retryLimit = 3;
    protected start(request: ChallengeRequest): Promise<ServerPinLikeChallenge.State>;
}
export declare namespace ServerPinChallenge {
    class PinEvent extends Event {
        readonly requestId: Uint8Array;
        readonly pin: string;
        constructor(type: string, requestId: Uint8Array, pin: string);
    }
}
export {};
