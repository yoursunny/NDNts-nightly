import { TypedEventTarget } from "typescript-event-target";
import type { ChallengeRequest } from "../packet/mod.js";
import type { ServerChallenge, ServerChallengeContext, ServerChallengeResponse } from "./challenge.js";
/** Base of a challenge where client submits a server-generated pin code. */
export declare abstract class ServerPinLikeChallenge<State extends ServerPinLikeChallenge.State = ServerPinLikeChallenge.State, EventMap extends Record<string, Event> = {}> extends TypedEventTarget<EventMap> implements ServerChallenge<State> {
    abstract readonly challengeId: string;
    abstract readonly timeLimit: number;
    abstract readonly retryLimit: number;
    /**
     * Validate a new request, create State object, and deliver PIN to client if applicable.
     * @param request - CHALLENGE request packet.
     * @param context - Challenge context, which contains the certificate request.
     * @returns State to continue the challenge, or ServerChallengeResponse to fail the challenge.
     */
    protected abstract start(request: ChallengeRequest, context: ServerChallengeContext<State>): Promise<State | ServerChallengeResponse>;
    process(request: ChallengeRequest, context: ServerChallengeContext<State>): Promise<ServerChallengeResponse>;
}
export declare namespace ServerPinLikeChallenge {
    class State {
        readonly pin: Uint8Array;
        get pinString(): string;
        verify(code: Uint8Array): boolean;
    }
}
