import type { Promisable } from "type-fest";
import { type ChallengeRequest, type ParameterKV } from "../packet/mod.js";
import { ServerChallenge, type ServerChallengeContext, type ServerChallengeResponse } from "./challenge.js";
interface State {
    recordName: string;
    recordValue: string;
}
declare abstract class ServerDnsChallengeBase {
    private readonly assignmentPolicy?;
    private readonly dohServer;
    constructor({ assignmentPolicy, dohServer, }?: ServerDnsChallenge.Options);
    process(request: ChallengeRequest, context: ServerChallengeContext<State>): Promise<ServerChallengeResponse>;
    private process0;
    protected abstract makeNeedRecord(context: ServerChallengeContext<State>, recordName: string, token: string): Promisable<[parameters: ParameterKV, recordValue: string]>;
    private process1;
    private checkRecord;
}
/** The "dns" challenge where client creates a DNS TXT record containing a challenge token. */
export declare class ServerDnsChallenge extends ServerDnsChallengeBase implements ServerChallenge<State> {
    readonly challengeId = "dns";
    readonly timeLimit = 300000;
    readonly retryLimit = 3;
    protected makeNeedRecord(context: ServerChallengeContext<State>, recordName: string, token: string): [parameters: ParameterKV, expected: string];
}
export declare namespace ServerDnsChallenge {
    /**
     * Callback to determine whether the owner of a DNS domain is allowed to obtain
     * a certificate of `newSubjectName`. It should throw or return false to disallow assignment.
     */
    type AssignmentPolicy = ServerChallenge.AssignmentPolicy<[string]>;
    interface Options {
        /**
         * Name assignment policy.
         * If omitted, any domain can obtain any certificate.
         */
        assignmentPolicy?: AssignmentPolicy;
        /**
         * DNS-over-HTTPS server with application/dns-json capability.
         * Common choices includes:
         * - https://cloudflare-dns.com/dns-query
         * - https://dns.google/resolve
         */
        dohServer?: string;
    }
}
/** The "dns-01" challenge where client creates a DNS TXT record containing a key authorization value. */
export declare class ServerDns01Challenge extends ServerDnsChallengeBase implements ServerChallenge<State> {
    readonly challengeId = "dns-01";
    readonly timeLimit = 3600000;
    readonly retryLimit = 5;
    protected makeNeedRecord(context: ServerChallengeContext<State>, record: string, token: string): Promise<[parameters: ParameterKV, recordValue: string]>;
}
export {};
