import type { Certificate } from "@ndn/keychain";
import type { Name } from "@ndn/packet";
import type { Promisable } from "type-fest";
import type { CaProfile, ChallengeRequest, ErrorCode, ParameterKV } from "../packet/mod.js";
/** Server side of a challenge. */
export interface ServerChallenge<State = any> {
    /** Challenge module identifier. */
    readonly challengeId: string;
    /** Time limit, in milliseconds. */
    readonly timeLimit: number;
    /** Retry limit, including the initial attempt. */
    readonly retryLimit: number;
    /** Process selection or continuation of the challenge. */
    process: (request: ChallengeRequest, context: ServerChallengeContext<State>) => Promise<ServerChallengeResponse>;
}
export declare namespace ServerChallenge {
    /**
     * Callback to determine whether the owner of an authenticable resource is allowed to obtain
     * a certificate of `newSubjectName`. It should throw or return false to disallow assignment.
     */
    type AssignmentPolicy<T extends unknown[]> = (newSubjectName: Name, ...a: T) => Promisable<void | boolean>;
    function callAssignmentPolicy<T extends unknown[]>(policy: AssignmentPolicy<T> | undefined, newSubjectName: Name, ...a: T): Promise<boolean>;
}
/** Contextual information for challenge processing. */
export interface ServerChallengeContext<State = unknown> {
    /** CA profile packet. */
    readonly profile: CaProfile;
    /** Self-signed certificate request. */
    readonly certRequest: Certificate;
    /** Subject name of the requested certificate. */
    readonly subjectName: Name;
    /** Key name of the requested certificate. */
    readonly keyName: Name;
    /**
     * Server-side state of the challenge on a request session.
     *
     * @remarks
     * For a newly selected challenge, this field is `undefined`.
     * The challenge module can store state information in this field and retrieve it when processing
     * subsequently CHALLENGE request packets.
     */
    challengeState?: State;
}
/** Result of challenge processing. */
export interface ServerChallengeResponse {
    /**
     * If true, challenge has succeeded and server will issue the certificate.
     * @defaultValue false
     */
    success?: boolean;
    /** If specified, challenge has failed permanently and server will return error. */
    fail?: ErrorCode;
    /**
     * If true, this request counts as one failed try and decrements remaining tries.
     * @defaultValue false
     */
    decrementRetry?: boolean;
    /**
     * ChallengeStatus to convey to the client.
     * @defaultValue "error"
     */
    challengeStatus?: string;
    /** Parameter key-value pairs to convey to the client. */
    parameters?: ParameterKV;
}
