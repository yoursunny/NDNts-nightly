import { type LLDecrypt, type LLEncrypt, SignedInterestPolicy } from "@ndn/packet";
export declare function generateEcdhKey(): Promise<[pvt: CryptoKey, pub: CryptoKey]>;
export declare function importEcdhPub(raw: Uint8Array): Promise<CryptoKey>;
export declare function exportEcdhPub(key: CryptoKey): Promise<Uint8Array>;
export declare function makeSalt(): Uint8Array;
export declare function checkSalt(input: Uint8Array): void;
export declare function makeRequestId(): Uint8Array;
export declare function checkRequestId(input: Uint8Array): void;
export interface SessionKey {
    sessionEncrypter: LLEncrypt.Key;
    sessionLocalDecrypter: LLDecrypt.Key;
    sessionDecrypter: LLDecrypt.Key;
}
export declare function makeSessionKey(ecdhPvt: CryptoKey, ecdhPub: CryptoKey, salt: Uint8Array, requestId: Uint8Array): Promise<SessionKey>;
export declare function makeSignedInterestPolicy(): SignedInterestPolicy;
