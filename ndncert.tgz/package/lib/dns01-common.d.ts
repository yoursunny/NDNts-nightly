export declare function toRecordName(domain: string): string;
export declare function computeRecordValue(token: string, requesterPublicKey: Uint8Array): Promise<string>;
