import type { LLDecrypt, LLEncrypt } from "@ndn/packet";
export declare function decode(wire: Uint8Array): LLDecrypt.Params;
export declare function encode({ iv, authenticationTag, ciphertext }: LLEncrypt.Result): Uint8Array;
