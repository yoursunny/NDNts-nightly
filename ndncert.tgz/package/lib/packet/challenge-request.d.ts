import type { NamedSigner, NamedVerifier } from "@ndn/keychain";
import { Interest, type LLDecrypt, type LLEncrypt, type SignedInterestPolicy } from "@ndn/packet";
import type { Promisable } from "type-fest";
import * as crypto from "../crypto-common.js";
import type { CaProfile } from "./ca-profile.js";
import * as parameter_kv from "./parameter-kv.js";
interface RequestInfo {
    sessionKey: Pick<crypto.SessionKey, "sessionDecrypter">;
    certRequestPub: NamedVerifier.PublicKey;
}
/** CHALLENGE request packet. */
export declare class ChallengeRequest {
    readonly interest: Interest;
    /** Decode CHALLENGE request from Interest packet. */
    static fromInterest(interest: Interest, { profile, signedInterestPolicy, lookupRequest, }: ChallengeRequest.Context): Promise<ChallengeRequest>;
    private constructor();
    get requestId(): Uint8Array;
}
export interface ChallengeRequest extends Readonly<ChallengeRequest.Fields> {
}
export declare namespace ChallengeRequest {
    interface ContextBase {
        /** CA profile packet. */
        profile: CaProfile;
        /** Signed Interest validation policy. */
        signedInterestPolicy: SignedInterestPolicy;
    }
    /** Contextual information to decode and verify CHALLENGE request packet. */
    export interface Context extends ContextBase {
        /**
         * Callback to locate request session.
         * @param requestId - Request session ID.
         * @returns Request session information, or `undefined` if not found.
         */
        lookupRequest: (requestId: Uint8Array) => Promisable<RequestInfo | undefined>;
    }
    /** Fields of CHALLENGE request packet. */
    export interface Fields {
        /** Selected challenge type. */
        selectedChallenge: string;
        /** Challenge parameter key-value pairs. */
        parameters: parameter_kv.ParameterKV;
    }
    /** Options to construct CHALLENGE request packet. */
    export interface Options extends ContextBase, Fields {
        /** Request session ID. */
        requestId: Uint8Array;
        /**
         * Request session encrypter.
         * @see {@link crypto.makeSessionKey}
         */
        sessionEncrypter: LLEncrypt.Key;
        /**
         * Request session local decrypter.
         * @see {@link crypto.makeSessionKey}
         */
        sessionLocalDecrypter: LLDecrypt.Key;
        /** Certificate request public key. */
        publicKey: NamedVerifier.PublicKey;
        /** Certificate request private key. */
        privateKey: NamedSigner.PrivateKey;
    }
    /** Construct CHALLENGE request packet. */
    export function build({ profile, signedInterestPolicy, requestId, sessionEncrypter, sessionLocalDecrypter, publicKey, privateKey, selectedChallenge, parameters, }: Options): Promise<ChallengeRequest>;
    export {};
}
export {};
