import { Certificate, type NamedSigner, type NamedVerifier, type SigningAlgorithm } from "@ndn/keychain";
import { Interest, type SignedInterestPolicy, ValidityPeriod } from "@ndn/packet";
import type { CaProfile } from "./ca-profile.js";
/** NEW request packet. */
export declare class NewRequest {
    readonly interest: Interest;
    readonly ecdhPub: CryptoKey;
    readonly publicKey: NamedVerifier.PublicKey;
    /**
     * Decode NEW request from Interest packet.
     * @param algoList - List of recognized algorithms for certificate request.
     * Default is {@link SigningAlgorithmListSlim}.
     */
    static fromInterest(interest: Interest, { profile, signedInterestPolicy }: NewRequest.Context, algoList?: readonly SigningAlgorithm<any, any, any>[]): Promise<NewRequest>;
    private constructor();
}
export interface NewRequest extends Readonly<NewRequest.Fields> {
}
export declare namespace NewRequest {
    /** Contextual information to decode and verify NEW request packet. */
    interface Context {
        /** CA profile packet. */
        profile: CaProfile;
        /** Signed Interest validation policy. */
        signedInterestPolicy: SignedInterestPolicy;
    }
    /** Fields of NEW request packet. */
    interface Fields {
        /** Client ECDH public key. */
        ecdhPubRaw: Uint8Array;
        /** Client certificate request as self-signed certificate. */
        certRequest: Certificate;
    }
    /** Options to construct NEW request packet. */
    interface Options extends Context {
        /** Client ECDH public key. */
        ecdhPub: CryptoKey;
        /** Certificate request public key. */
        publicKey: NamedVerifier.PublicKey;
        /** Certificate request private key. */
        privateKey: NamedSigner.PrivateKey;
        /**
         * Desired ValidityPeriod.
         *
         * @remarks
         * This will be truncated to maximum validity permitted by the CA profile.
         */
        validity?: ValidityPeriod;
        /**
         * List of recognized algorithms for certificate request.
         * @defaultValue `SigningAlgorithmListSlim`
         */
        algoList?: readonly SigningAlgorithm[];
    }
    /** Construct NEW request packet. */
    function build({ profile, signedInterestPolicy, ecdhPub, publicKey, privateKey, validity, algoList, }: Options): Promise<NewRequest>;
}
