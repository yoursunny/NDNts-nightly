import { Data, type Signer } from "@ndn/packet";
import type { Except } from "type-fest";
import type { CaProfile } from "./ca-profile.js";
import type { NewRequest } from "./new-request.js";
/** NEW response packet. */
export declare class NewResponse {
    readonly data: Data;
    readonly ecdhPub: CryptoKey;
    /** Decode NEW response from Data packet. */
    static fromData(data: Data, profile: CaProfile): Promise<NewResponse>;
    private constructor();
}
export interface NewResponse extends Readonly<NewResponse.Fields> {
}
export declare namespace NewResponse {
    /** Fields of NEW response packet. */
    interface Fields {
        /** Server ECDH public key. */
        ecdhPubRaw: Uint8Array;
        /** Salt for session key generation. */
        salt: Uint8Array;
        /** Request session ID. */
        requestId: Uint8Array;
        /** Available challenge types. */
        challenges: string[];
    }
    /** Options to construct NEW response packet. */
    interface Options extends Except<Fields, "ecdhPubRaw"> {
        /** CA profile packet. */
        profile: CaProfile;
        /** NEW request packet. */
        request: NewRequest;
        /** Server ECDH public key. */
        ecdhPub: CryptoKey;
        /** Signing key correspond to CA certificate. */
        signer: Signer;
    }
    /** Construct NEW response packet. */
    function build({ profile, request: { interest: { name } }, ecdhPub, salt, requestId, challenges, signer, }: Options): Promise<NewResponse>;
}
