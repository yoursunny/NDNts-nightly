import { Certificate, type NamedVerifier, type SigningAlgorithm } from "@ndn/keychain";
import { Data, Name, type Signer } from "@ndn/packet";
/** CA profile packet. */
export declare class CaProfile {
    readonly data: Data;
    readonly publicKey: NamedVerifier.PublicKey;
    readonly certDigest: Uint8Array;
    /**
     * Decode CA profile from Data packet.
     * @param algoList - List of recognized algorithms for CA certificate.
     * Default is {@link SigningAlgorithmListSlim}.
     */
    static fromData(data: Data, algoList?: readonly SigningAlgorithm<any, any, any>[]): Promise<CaProfile>;
    private constructor();
    toString(): string;
    toJSON(): CaProfile.ToJSON;
}
export interface CaProfile extends Readonly<CaProfile.Fields> {
}
export declare namespace CaProfile {
    /** JSON representation of CA profile. */
    interface ToJSON {
        prefix: string;
        info: string;
        probeKeys: string[];
        maxValidityPeriod: number;
        certName: string;
        certDigest: string;
    }
    /** Fields of CA profile packet. */
    interface Fields {
        /**
         * CA name prefix.
         *
         * @remarks
         * Typically, this should not have "CA" as its last component.
         */
        prefix: Name;
        /** CA description. */
        info: string;
        /** Property keys for PROBE command. */
        probeKeys: string[];
        /** Maximum ValidityPeriod for issued certificates, in milliseconds. */
        maxValidityPeriod: number;
        /** CA certificate. */
        cert: Certificate;
    }
    /** Options to construct CA profile packet. */
    interface Options extends Fields {
        /** Signing key correspond to CA certificate. */
        signer: Signer;
        /**
         * Version number in the CA profile packet name.
         * @defaultValue `Date.now()`
         */
        version?: number;
        /**
         * List of recognized algorithms for CA certificate.
         * This must contain the crypto algorithm used by the CA certificate.
         * @defaultValue `SigningAlgorithmListSlim`
         */
        algoList?: readonly SigningAlgorithm[];
    }
    /** Construct CA profile packet. */
    function build({ prefix, info, probeKeys, maxValidityPeriod, cert, signer, version, algoList, }: Options): Promise<CaProfile>;
}
