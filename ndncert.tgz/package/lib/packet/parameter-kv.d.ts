import type { Encodable, EvDecoder } from "@ndn/tlv";
/** Parameter key-value pair. */
export type ParameterKV = Record<string, Uint8Array>;
/**
 * Define fields on EvDecoder to recognize pairs of ParameterKey and ParameterValue TLVs.
 * @param evd - EvDecoder of parent TLV.
 * @param order - Field order for both ParameterKey and ParameterValue.
 */
export declare function parseEvDecoder<R extends {
    parameters?: ParameterKV;
}>(evd: EvDecoder<R>, order: number): void;
/** Encode pairs of ParameterKey and ParameterValue TLVs. */
export declare function encode(kv?: ParameterKV): Encodable[];
