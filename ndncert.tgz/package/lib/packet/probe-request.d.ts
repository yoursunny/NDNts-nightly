import { Interest } from "@ndn/packet";
import type { CaProfile } from "./ca-profile.js";
import * as parameter_kv from "./parameter-kv.js";
/** PROBE request packet. */
export declare class ProbeRequest {
    readonly interest: Interest;
    /** Decode PROBE request from Interest packet. */
    static fromInterest(interest: Interest, { profile }: ProbeRequest.Context): Promise<ProbeRequest>;
    private constructor();
}
export interface ProbeRequest extends Readonly<ProbeRequest.Fields> {
}
export declare namespace ProbeRequest {
    /** Contextual information to decode and verify PROBE request packet. */
    interface Context {
        /** CA profile packet. */
        profile: CaProfile;
    }
    /** Fields of PROBE request packet. */
    interface Fields {
        parameters: parameter_kv.ParameterKV;
    }
    /** Options to construct PROBE request packet. */
    interface Options extends Context, Fields {
    }
    /** Construct PROBE request packet. */
    function build({ profile, parameters, }: Options): Promise<ProbeRequest>;
}
