import { Data, FwHint, type LLDecrypt, type LLEncrypt, Name, type Signer } from "@ndn/packet";
import { Status } from "./an.js";
import type { CaProfile } from "./ca-profile.js";
import type { ChallengeRequest } from "./challenge-request.js";
import * as parameter_kv from "./parameter-kv.js";
/** CHALLENGE response packet. */
export declare class ChallengeResponse {
    readonly data: Data;
    /** Decode CHALLENGE response from Data packet. */
    static fromData(data: Data, profile: CaProfile, requestId: Uint8Array, sessionDecrypter: LLDecrypt.Key): Promise<ChallengeResponse>;
    private constructor();
}
export interface ChallengeResponse extends Readonly<ChallengeResponse.Fields> {
}
export declare namespace ChallengeResponse {
    /** Fields of CHALLENGE response packet. */
    interface Fields {
        /** Request session status. */
        status: Status;
        /** Challenge specific status string. */
        challengeStatus?: string;
        /** Number of remaining tries to complete challenge. */
        remainingTries?: number;
        /** Remaining time to complete challenge, in milliseconds. */
        remainingTime?: number;
        /** Challenge parameter key-value pairs. */
        parameters?: parameter_kv.ParameterKV;
        /**
         * Issued certificate name.
         *
         * @remarks
         * This should end with an implicit digest component.
         */
        issuedCertName?: Name;
        /** Forwarding hint needed for retrieving issued certificate. */
        fwHint?: FwHint;
    }
    /** Options to construct CHALLENGE response packet. */
    interface Options extends Fields {
        /** CA profile packet. */
        profile: CaProfile;
        /**
         * Request session encrypter.
         * @see {@link crypto.makeSessionKey}
         */
        sessionEncrypter: LLEncrypt.Key;
        /**
         * Request session local decrypter.
         * @see {@link crypto.makeSessionKey}
         */
        sessionLocalDecrypter: LLDecrypt.Key;
        /** CHALLENGE request packet. */
        request: ChallengeRequest;
        /** Signing key correspond to CA certificate. */
        signer: Signer;
    }
    /** Construct CHALLENGE response packet. */
    function build(opts: Options): Promise<ChallengeResponse>;
}
