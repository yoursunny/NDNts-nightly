import { Data, Name, type Signer } from "@ndn/packet";
import type { CaProfile } from "./ca-profile.js";
import type { ProbeRequest } from "./probe-request.js";
/** PROBE response packet. */
export declare class ProbeResponse {
    readonly data: Data;
    /** Decode PROBE response from Data packet. */
    static fromData(data: Data, profile: CaProfile): Promise<ProbeResponse>;
    private constructor();
}
export interface ProbeResponse extends Readonly<ProbeResponse.Fields> {
}
export declare namespace ProbeResponse {
    /** Available name response entry. */
    interface Entry {
        prefix: Name;
        maxSuffixLength?: number;
    }
    /** Redirection response entry. */
    interface Redirect {
        caCertFullName: Name;
    }
    /** Fields of PROBE response packet. */
    interface Fields {
        entries: Entry[];
        redirects: Redirect[];
    }
    /** Options to construct PROBE response packet. */
    interface Options extends Partial<Fields> {
        /** CA profile packet. */
        profile: CaProfile;
        /** PROBE request packet. */
        request: ProbeRequest;
        /** Signing key correspond to CA certificate. */
        signer: Signer;
    }
    /** Construct PROBE response packet. */
    function build({ profile, request: { interest: { name } }, signer, entries, redirects, }: Options): Promise<ProbeResponse>;
    function isCaCertFullName(name: Name): boolean;
    function checkCaCertFullName(name: Name): void;
}
