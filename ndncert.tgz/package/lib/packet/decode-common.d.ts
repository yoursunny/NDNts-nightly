import { Component, type Data, type Interest, type Name, type NamingConvention } from "@ndn/packet";
import { type EvDecoder } from "@ndn/tlv";
import type { Promisable } from "type-fest";
/**
 * Verify packet name.
 *
 * @remarks
 * Function parameters are:
 * 1. Interest or Data packet.
 * 2. CA profile.
 * 3. Matchers for name components after "CA" component.
 *    Each matcher is a component, a convention, or `undefined` to match anything.
 */
export declare function checkName({ name }: {
    name: Name;
}, { prefix: caPrefix }: {
    prefix: Name;
}, ...comps: Array<Component | NamingConvention<any> | undefined>): void;
/**
 * Decode from Interest AppParameters.
 * @param interest - Source Interest.
 * @param evd - Fields decoder.
 * @param fn - Function to create result packet; fields will be assigned onto it.
 * @returns Result packet.
 */
export declare function fromInterest<T extends Readonly<Fields>, Fields extends {}>(interest: Interest, evd: EvDecoder<Fields>, fn: (fields: Fields) => Promisable<T>): Promise<T>;
/**
 * Decode from Data Content.
 * @param data - Source Data.
 * @param evd - Fields decoder.
 * @param fn - Function to create result packet; fields will be assigned onto it.
 * @returns Result packet.
 */
export declare function fromData<T extends Readonly<Fields>, Fields extends {}>(data: Data, evd: EvDecoder<Fields>, fn: (fields: Fields) => Promisable<T>): Promise<T & Fields>;
