import { Component } from "@ndn/packet";
export declare const TT: {
    readonly CaPrefix: 129;
    readonly CaInfo: 131;
    readonly ParameterKey: 133;
    readonly ParameterValue: 135;
    readonly CaCertificate: 137;
    readonly MaxValidityPeriod: 139;
    readonly ProbeResponse: 141;
    readonly MaxSuffixLength: 143;
    readonly EcdhPub: 145;
    readonly CertRequest: 147;
    readonly Salt: 149;
    readonly RequestId: 151;
    readonly Challenge: 153;
    readonly Status: 155;
    readonly InitializationVector: 157;
    readonly EncryptedPayload: 159;
    readonly SelectedChallenge: 161;
    readonly ChallengeStatus: 163;
    readonly RemainingTries: 165;
    readonly RemainingTime: 167;
    readonly IssuedCertName: 169;
    readonly ErrorCode: 171;
    readonly ErrorInfo: 173;
    readonly AuthenticationTag: 175;
    readonly CertToRevoke: 177;
    readonly ProbeRedirect: 179;
};
export declare const C: {
    CA: Component;
    INFO: Component;
    PROBE: Component;
    NEW: Component;
    CHALLENGE: Component;
};
export declare enum Status {
    BEFORE_CHALLENGE = 0,
    CHALLENGE = 1,
    PENDING = 2,
    SUCCESS = 3,
    FAILURE = 4
}
export declare namespace Status {
    const MIN = 0;
    const MAX = 4;
}
export declare enum ErrorCode {
    BadInterestFormat = 1,
    BadParameterFormat = 2,
    BadSignature = 3,
    InvalidParameters = 4,
    NameNotAllowed = 5,
    BadValidityPeriod = 6,
    OutOfTries = 7,
    OutOfTime = 8,
    NoAvailableName = 9
}
