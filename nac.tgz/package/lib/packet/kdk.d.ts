import { type CryptoAlgorithm, type NamedEncrypter } from "@ndn/keychain";
import { SafeBag } from "@ndn/ndnsec";
import { Data, type LLDecrypt, type Name, type Signer } from "@ndn/packet";
import { type KeyEncryptionKey } from "./kek.js";
/** NAC key decryption key. */
export declare class KeyDecryptionKey {
    readonly data: Data;
    /** Parse key decryption key from Data packet. */
    static fromData(data: Data): Promise<KeyDecryptionKey>;
    private constructor();
    get name(): Name;
    loadKeyPair(decrypter: LLDecrypt.Key, extractable?: boolean): Promise<CryptoAlgorithm.GeneratedKeyPair>;
}
export interface KeyDecryptionKey extends Readonly<KeyDecryptionKey.NameParts>, Readonly<KeyDecryptionKey.Fields> {
}
export declare namespace KeyDecryptionKey {
    interface NameParts extends KeyEncryptionKey.NameParts {
        memberKeyName: Name;
    }
    interface Fields {
        safeBag: SafeBag;
        encryptedPassphrase: Uint8Array;
    }
    /** Parse key decryption key Data name. */
    function parseName(name: Name): NameParts;
    /** Create key decryption key Data name. */
    function makeName(parts: NameParts): Name;
    interface Options {
        kek: KeyEncryptionKey;
        /** KEK-KDK RSA-OAEP key pair. */
        keyPair: CryptoAlgorithm.GeneratedKeyPair;
        /** Member RSA-OAEP public key. */
        member: NamedEncrypter.PublicKey;
        signer: Signer;
    }
    /** Create key decryption key packet. */
    function build({ kek, keyPair, member, signer, }: Options): Promise<KeyDecryptionKey>;
}
