import { LLDecrypt, LLEncrypt, Name } from "@ndn/packet";
import { Decoder, Encoder } from "@ndn/tlv";
/**
 * NAC encrypted content.
 *
 * This is only applicable for application data, encrypted by AES-CBC.
 * Do not use this type for KDK and CK packets.
 */
export declare class EncryptedContent implements LLDecrypt.Params {
    static decodeFrom(decoder: Decoder): EncryptedContent;
    static create({ ciphertext, iv }: LLEncrypt.Result, name: Name): EncryptedContent;
    private constructor();
    ciphertext: Uint8Array;
    iv: Uint8Array;
    name: Name;
    encodeTo(encoder: Encoder): void;
}
