import { type NamedEncrypter } from "@ndn/keychain";
import { type Component, Data, type LLEncrypt, type Name, type Signer } from "@ndn/packet";
import type { Except } from "type-fest";
/** NAC key encryption key. */
export declare class KeyEncryptionKey {
    readonly data: Data;
    /** Parse key encryption key from Data packet. */
    static fromData(data: Data): Promise<KeyEncryptionKey>;
    private constructor();
    get name(): Name;
    /** Public key in SubjectPublicKeyInfo (SPKI) binary format. */
    get publicKeySpki(): Uint8Array;
    private encrypter_;
    get encrypter(): LLEncrypt.Key;
}
export interface KeyEncryptionKey extends Readonly<KeyEncryptionKey.NameParts> {
}
export declare function parseNameInternal(name: Name, keyword2: Component, type?: string): KeyEncryptionKey.NameParts;
export declare function makeNameInternal(parts: KeyEncryptionKey.NameParts, keyword2: Component): Name;
export declare namespace KeyEncryptionKey {
    interface NameParts {
        prefix: Name;
        subset: Name;
        keyId: Component;
    }
    /** Parse key encryption key Data name. */
    function parseName(name: Name): NameParts;
    /** Create subject name for RSA-OAEP key generation. */
    function makeSubjectName({ prefix, subset }: Except<NameParts, "keyId">): Name;
    /** Create key encryption key Data name. */
    function makeName(parts: NameParts): Name;
    interface Options {
        /** KEK RSA-OAEP public key. */
        publicKey: NamedEncrypter.PublicKey;
        signer: Signer;
    }
    /** Create key encryption key packet. */
    function build({ publicKey, signer, }: Options): Promise<KeyEncryptionKey>;
}
