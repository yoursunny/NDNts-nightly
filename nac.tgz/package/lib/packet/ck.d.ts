import { type CryptoAlgorithm } from "@ndn/keychain";
import { type Component, Data, type LLDecrypt, type Name, type Signer } from "@ndn/packet";
import { type KeyEncryptionKey } from "./kek.js";
/** NAC content key. */
export declare class ContentKey {
    readonly data: Data;
    /** Parse content key from Data packet. */
    static fromData(data: Data): Promise<ContentKey>;
    private constructor();
    get locator(): Name;
    get name(): Name;
    loadKey(decrypter: LLDecrypt.Key): Promise<CryptoAlgorithm.GeneratedSecretKey>;
}
export interface ContentKey extends Readonly<ContentKey.NameParts>, Readonly<ContentKey.Fields> {
}
export declare namespace ContentKey {
    interface LocatorParts {
        ckPrefix: Name;
        ckId: Component;
    }
    interface NameParts extends LocatorParts, KeyEncryptionKey.NameParts {
    }
    interface Fields {
        encryptedKey: Uint8Array;
    }
    /**
     * Parse content key locator name.
     * @remarks
     * In an encrypted application packet, it appears in EncryptedPayload.Name field.
     * @throws Error
     * Thrown if `name` is not a valid content key locator name.
     */
    function parseLocator(name: Name): LocatorParts;
    /** Create content key locator name. */
    function makeLocator({ ckPrefix, ckId }: LocatorParts): Name;
    /** Parse content key Data name. */
    function parseName(name: Name): NameParts;
    /** Create content key Data name. */
    function makeName(parts: NameParts): Name;
    interface Options {
        kek: KeyEncryptionKey;
        /** AES-CBC secret key. */
        key: CryptoAlgorithm.GeneratedSecretKey;
        ckPrefix: Name;
        ckId?: Component;
        signer: Signer;
    }
    /** Create content key packet. */
    function build({ kek, key, ckPrefix, ckId, signer, }: Options): Promise<ContentKey>;
}
