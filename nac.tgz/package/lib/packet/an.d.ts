import { Component } from "@ndn/packet";
export declare const TT: {
    readonly EncryptedContent: 130;
    readonly EncryptedPayload: 132;
    readonly InitializationVector: 133;
    readonly EncryptedPayloadKey: 134;
};
export declare const ContentTypeKEY = 2;
export declare const DefaultFreshness = 3600000;
export declare const Keyword: {
    NAC: Component;
    KEK: Component;
    KDK: Component;
    CK: Component;
    ENCRYPTED_BY: Component;
    KEY: Component;
};
