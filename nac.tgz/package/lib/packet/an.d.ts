import { Component } from "@ndn/packet";
export declare const TT: {
    EncryptedContent: number;
    EncryptedPayload: number;
    InitializationVector: number;
    EncryptedPayloadKey: number;
};
export declare const ContentTypeKEY = 2;
export declare const DefaultFreshness = 3600000;
export declare const Keyword: {
    NAC: Component;
    KEK: Component;
    KDK: Component;
    CK: Component;
    ENCRYPTED_BY: Component;
    KEY: Component;
};
