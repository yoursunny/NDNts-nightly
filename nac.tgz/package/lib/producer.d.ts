import type { Encrypter, Name, Signer } from "@ndn/packet";
import type { DataStore as S } from "@ndn/repo-api";
import { type KeyEncryptionKey } from "./packet/mod.js";
/** NAC producer. */
export declare class Producer {
    private readonly dataStore;
    private readonly ckPrefix;
    private readonly signer;
    static create({ dataStore, ckPrefix, signer, }: Producer.Options): Producer;
    private constructor();
    private readonly keys;
    /**
     * Create an encrypter for application data.
     * CK will be generated if necessary.
     */
    createEncrypter(kek: KeyEncryptionKey): Promise<Encrypter>;
}
export declare namespace Producer {
    /** Subset of repo DataStore functions needed by Producer. */
    interface DataStore extends S.Insert {
    }
    /** {@link Producer.create} options. */
    interface Options {
        /** Repo for publishing CK packets. */
        dataStore: DataStore;
        /** Content key prefix. */
        ckPrefix: Name;
        /** Signer for CK. */
        signer: Signer;
    }
}
