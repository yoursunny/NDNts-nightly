import { Endpoint } from "@ndn/endpoint";
import { Certificate, NamedDecrypter, NamedEncrypter } from "@ndn/keychain";
import { Component, Name, Signer, Verifier } from "@ndn/packet";
import type { DataStore as S } from "@ndn/repo-api";
import { KeyDecryptionKey, KeyEncryptionKey } from "./packet/mod";
/** NAC access manager. */
export declare class AccessManager {
    private readonly endpoint;
    private readonly dataStore;
    private readonly prefix;
    private readonly keys;
    static create({ endpoint, dataStore, prefix, keys, }: AccessManager.Options): AccessManager;
    private constructor();
    /** Create a new Key Encryption Key. */
    createKek(subset: Name): Promise<AccessManager.KekHandle>;
    /** Find an existing Key Encryption Key. */
    lookupKek(subset: Name, keyId?: Component): Promise<AccessManager.KekHandle>;
    private makeKekHandle;
    private extractMemberKey;
    private makeKdk;
}
export declare namespace AccessManager {
    /** Subset of repo DataStore functions needed by AccessManager. */
    interface DataStore extends S.Get, S.Find, S.Insert {
    }
    interface Keys {
        /** Signer for KEK, KDK, and KDK SafeBag. */
        signer: Signer;
        /**
         * Verifier for member RSA-OAEP certificates.
         * This is only used if a Name is passed to KeyHandle.grant function.
         * If unspecified, KeyHandle.grant does not accept Name.
         */
        memberVerifier?: Verifier;
        /** Encrypter for own KDK. */
        ownKdkEncrypter: NamedEncrypter;
        /** Decrypter for own KDK. */
        ownKdkDecrypter: NamedDecrypter;
        /**
         * Verifier for own KDK.
         * This is only needed if the dataStore cannot be trusted.
         * Default is no verification.
         */
        ownKdkVerifier?: Verifier;
    }
    interface Options {
        /**
         * Endpoint for communication.
         * Default is an Endpoint on the default forwarder with 2 retransmissions.
         */
        endpoint?: Endpoint;
        /** Store for publishing KEK and KDK packets. */
        dataStore: DataStore;
        /** Access policy prefix. */
        prefix: Name;
        /** Set of keys. */
        keys: Keys;
    }
    /** Handle of a key encryption key. */
    interface KekHandle {
        readonly kek: KeyEncryptionKey;
        /**
         * Grant access to a new member.
         *
         * Caller is responsible for verifying authenticity of the PublicKey or Certificate.
         * If passing a key name or certificate name, the retrieved certificate will be verified by Options.memberVerifier.
         */
        grant: (member: NamedEncrypter.PublicKey | Certificate | Name) => Promise<KeyDecryptionKey>;
    }
}
