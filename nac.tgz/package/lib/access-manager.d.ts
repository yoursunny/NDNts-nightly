import { type ConsumerOptions } from "@ndn/endpoint";
import { Certificate, type NamedDecrypter, type NamedEncrypter } from "@ndn/keychain";
import { type Component, Name, type Signer, type Verifier } from "@ndn/packet";
import type { DataStore as S } from "@ndn/repo-api";
import { KeyDecryptionKey, KeyEncryptionKey } from "./packet/mod.js";
/** NAC access manager. */
export declare class AccessManager {
    private readonly cOpts;
    private readonly dataStore;
    private readonly prefix;
    private readonly keys;
    static create({ cOpts, dataStore, prefix, keys, }: AccessManager.Options): AccessManager;
    private constructor();
    /** Create a new Key Encryption Key. */
    createKek(subset: Name): Promise<AccessManager.KekHandle>;
    /** Find an existing Key Encryption Key. */
    lookupKek(subset: Name, keyId?: Component): Promise<AccessManager.KekHandle>;
    private makeKekHandle;
    private extractMemberKey;
    private makeKdk;
}
export declare namespace AccessManager {
    /** Subset of repo DataStore functions needed by AccessManager. */
    interface DataStore extends S.Get, S.Find, S.Insert {
    }
    /** Set of keys used by AccessManager. */
    interface Keys {
        /** Signer for KEK, KDK, and KDK SafeBag. */
        signer: Signer;
        /**
         * Verifier for member RSA-OAEP certificates.
         *
         * @remarks
         * This is only used if a Name would be passed to {@link KekHandle.grant} function.
         * If unspecified, {@link KekHandle.grant} does not accept Name.
         */
        memberVerifier?: Verifier;
        /** Encrypter for own KDK. */
        ownKdkEncrypter: NamedEncrypter;
        /** Decrypter for own KDK. */
        ownKdkDecrypter: NamedDecrypter;
        /**
         * Verifier for own KDK.
         *
         * @remarks
         * This is only needed if {@link Options.dataStore} cannot be trusted (e.g. it's a network
         * based repo). Otherwise, no verification is needed.
         */
        ownKdkVerifier?: Verifier;
    }
    /** {@link AccessManager.create} options. */
    interface Options {
        /**
         * Consumer options.
         *
         * @remarks
         * - `.describe` defaults to "NAC-AccessManager" + `.prefix`.
         * - `.retx` defaults to 2.
         * - `.verifier` is overridden.
         */
        cOpts?: ConsumerOptions;
        /** Repo for publishing KEK and KDK packets. */
        dataStore: DataStore;
        /** Access policy prefix. */
        prefix: Name;
        /** Set of keys. */
        keys: Keys;
    }
    /** Handle of a key encryption key. */
    interface KekHandle {
        readonly kek: KeyEncryptionKey;
        /**
         * Grant access to a new member.
         *
         * @remarks
         * Caller is responsible for verifying authenticity of the public key or certificate.
         * If passing a key name or certificate name, the retrieved certificate will be verified by
         * {@link Keys.memberVerifier}.
         */
        grant: (member: NamedEncrypter.PublicKey | Certificate | Name) => Promise<KeyDecryptionKey>;
    }
}
