import { type ConsumerOptions } from "@ndn/endpoint";
import { type NamedDecrypter } from "@ndn/keychain";
import { type Data, type Decrypter, type Verifier } from "@ndn/packet";
/** NAC consumer. */
export declare class Consumer implements Decrypter {
    private readonly cOpts;
    private readonly memberDecrypter;
    static create({ cOpts, verifier, memberDecrypter, }: Consumer.Options): Consumer;
    private constructor();
    decrypt(data: Data): Promise<void>;
}
export declare namespace Consumer {
    /** {@link Consumer.create} options. */
    interface Options {
        /**
         * Consumer options.
         *
         * @remarks
         * - `.describe` defaults to "NAC-Consumer" + member name.
         * - `.retx` defaults to 2.
         * - `.verifier` is overridden.
         */
        cOpts?: ConsumerOptions;
        /** Verifier for KDK and CK. */
        verifier: Verifier;
        /** RSA-OAEP private key for decrypting KDK. */
        memberDecrypter: NamedDecrypter;
    }
}
