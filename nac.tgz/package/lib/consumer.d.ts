import { type ConsumerOptions, type Endpoint } from "@ndn/endpoint";
import { type NamedDecrypter } from "@ndn/keychain";
import { type Data, type Decrypter, type Verifier } from "@ndn/packet";
/** NAC consumer. */
export declare class Consumer implements Decrypter {
    private readonly cOpts;
    private readonly memberDecrypter;
    static create({ endpoint, // eslint-disable-line etc/no-deprecated
    cOpts, verifier, memberDecrypter, }: Consumer.Options): Consumer;
    private constructor();
    decrypt(data: Data): Promise<void>;
}
export declare namespace Consumer {
    /** {@link Consumer.create} options. */
    interface Options {
        /**
         * Endpoint for communication.
         * @deprecated Specify `.cOpts`.
         */
        endpoint?: Endpoint;
        /**
         * Consumer options.
         *
         * @remarks
         * - `.describe` defaults to "NAC-Consumer" + member name.
         * - `.retx` defaults to 2.
         * - `.verifier` is overridden.
         */
        cOpts?: ConsumerOptions;
        /** Verifier for KDK and CK. */
        verifier: Verifier;
        /** RSA-OAEP private key for decrypting KDK. */
        memberDecrypter: NamedDecrypter;
    }
}
