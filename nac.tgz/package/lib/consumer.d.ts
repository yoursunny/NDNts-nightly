import { Endpoint } from "@ndn/endpoint";
import { NamedDecrypter } from "@ndn/keychain";
import { Data, Decrypter, Verifier } from "@ndn/packet";
/** NAC consumer. */
export declare class Consumer implements Decrypter {
    private readonly endpoint;
    private readonly verifier;
    private readonly memberDecrypter;
    static create({ endpoint, verifier, memberDecrypter, }: Consumer.Options): Consumer;
    private constructor();
    decrypt(data: Data): Promise<void>;
}
export declare namespace Consumer {
    interface Options {
        /**
         * Endpoint for communication.
         * Default is an Endpoint on the default forwarder with 2 retransmissions.
         */
        endpoint?: Endpoint;
        /** Verifier for KDK and CK. */
        verifier: Verifier;
        /** RSA-OAEP private keys for decrypting KDK. */
        memberDecrypter: NamedDecrypter;
    }
}
