import { Data, Name } from "@ndn/packet";
import type { AbstractChainedBatch, AbstractDatabaseOptions, AbstractLevel } from "abstract-level";
import type { AbstractChainedBatch as Batch1, AbstractLevel as Level1 } from "abstract-level-1";
import type { Promisable } from "type-fest";
/** Value stored in database. */
export interface Record {
    readonly data: Data;
    readonly name: Name;
    readonly insertTime: number;
    readonly expireTime?: number;
}
/** Required options when creating abstract-level compatible key-value database. */
export declare const AbstractLevelOptions: AbstractDatabaseOptions<Name, Record>;
export type Db2 = AbstractLevel<any, Name, Record>;
/** An abstract-level compatible key-value database. */
export type Db = Db2 | Level1<any, Name, Record>;
/** Function to create Db. */
export type DbOpener = (opts: AbstractDatabaseOptions<Name, Record>) => Promisable<Db>;
/**
 * Constructor of AbstractLevel subclass.
 * @typeParam A - Constructor arguments, excluding the last.
 * @typeParam O - Last constructor argument, which must be the options object.
 */
export type DbCtor<A extends unknown[], O extends {}> = new (...a: [...A, O & AbstractDatabaseOptions<Name, Record>]) => Db;
/** A transaction chain in key-value database. */
export type DbChain = AbstractChainedBatch<Db, Name, Record> | Batch1<Db, Name, Record>;
/** Determine whether `err` represents "not found". */
export declare function isNotFound(err: unknown): boolean;
/** Determine whether a record has expired. */
export declare function isExpired({ expireTime }: Record, now?: number): boolean;
/** Create a filter function for either expired or unexpired records. */
export declare function filterExpired(expired: boolean, now?: number): (record: Record) => boolean;
