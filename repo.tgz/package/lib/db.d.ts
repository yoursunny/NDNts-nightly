/// <reference types="node" />
import { Data, Name } from "@ndn/packet";
import type { AbstractIterator, AbstractLevelDOWN } from "abstract-leveldown";
import EncodingDown from "encoding-down";
import { LevelUp, LevelUpChain } from "levelup";
export interface Record {
    readonly data: Data;
    readonly name: Name;
    readonly insertTime: number;
    readonly expireTime?: number;
    encodedBuffer?: Buffer;
}
export declare type Db = LevelUp<EncodingDown<Name, Record>, AbstractIterator<Name, Record>>;
export declare type DbChain = LevelUpChain<Name, Record>;
export declare function openDb(db: AbstractLevelDOWN): Db;
export declare function isExpired(expireTime?: number, now?: number): boolean;
export declare function filterExpired(expired: boolean, now?: number): (record: Record) => boolean;
