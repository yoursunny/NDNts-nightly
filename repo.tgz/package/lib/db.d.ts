import { Data, Name } from "@ndn/packet";
import type { AbstractChainedBatch, AbstractDatabaseOptions, AbstractLevel } from "abstract-level";
import type { Promisable } from "type-fest";
/** Value stored in database. */
export interface Value {
    readonly data: Data;
    readonly name: Name;
    readonly insertTime: number;
    readonly expireTime?: number;
}
/** Required options when creating abstract-level compatible key-value database. */
export declare const AbstractLevelOptions: AbstractDatabaseOptions<Name, Value>;
/** An abstract-level compatible key-value database. */
export type Db = AbstractLevel<any, Name, Value>;
/** Function to create Db. */
export type DbOpener<D extends Db = Db> = (opts: AbstractDatabaseOptions<Name, Value>) => Promisable<D>;
/**
 * Constructor of AbstractLevel subclass.
 * @typeParam A - Constructor arguments, excluding the last.
 * @typeParam O - Last constructor argument, which must be the options object.
 */
export type DbCtor<A extends unknown[], O extends {}> = new (...a: [...A, O & AbstractDatabaseOptions<Name, Value>]) => Db;
/** A transaction chain in key-value database. */
export type DbBatch = AbstractChainedBatch<Db, Name, Value>;
/** Determine whether a record has expired. */
export declare function isExpired({ expireTime }: Value, now?: number): boolean;
/** Create a filter function for either expired or unexpired records. */
export declare function filterExpired(expired: boolean, now?: number): (record: Value) => boolean;
