import { DataStore } from "./data-store.js";
/** Create an in-memory DataStore with `memory-level`. */
export declare function makeInMemoryDataStore(): Promise<DataStore>;
