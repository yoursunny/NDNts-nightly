export { DataStore, Transaction } from "./data-store.js";
export { makeInMemoryDataStore } from "./data-store-memory.js";
export { makePersistentDataStore } from "./data-store-persistent.js";
export * from "./prefix-reg/mod.js";
export { RepoProducer } from "./producer.js";
import { metadataFallback } from "./metadata-fallback.js";
export { metadataFallback, 
/** @deprecated Use `metadataFallback` instead. */
metadataFallback as respondRdr, };
