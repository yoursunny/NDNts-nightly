import { Data, Interest, Name } from "@ndn/packet";
import { DataStore as S } from "@ndn/repo-api";
import type { AbstractLevelDOWN } from "abstract-leveldown";
import type TypedEmitter from "typed-emitter";
import { Db, Record } from "./db";
interface Events {
    /** Emitted when a new record is inserted. */
    insert: (name: Name) => void;
    /** Emitted when an existing record is deleted. */
    delete: (name: Name) => void;
}
declare const DataStore_base: new () => TypedEmitter<Events>;
/** Data packet storage based on LevelDB or other abstract-leveldown store. */
export declare class DataStore extends DataStore_base implements S.Close, S.ListNames, S.ListData, S.Get, S.Find, S.Insert<InsertOptions>, S.Delete {
    private readonly db;
    readonly mutex: <TResult, TArgs extends any[] = []>(fn: (...args: TArgs) => Promise<TResult>, ...args: TArgs) => Promise<TResult>;
    /**
     * Constructor.
     * @param db an abstract-leveldown compatible store. It must support Buffer as keys.
     */
    constructor(db: AbstractLevelDOWN);
    /** Close the store. */
    close(): Promise<void>;
    private iterRecords;
    /** List Data names, optionally filtered by name prefix. */
    listNames(prefix?: Name): AsyncIterable<Name>;
    /** List Data packets, optionally filtered by name prefix. */
    listData(prefix?: Name): AsyncIterable<Data>;
    /** Retrieve Data by exact name. */
    get(name: Name): Promise<Data | undefined>;
    /** Find Data that satisfies Interest. */
    find(interest: Interest): Promise<Data | undefined>;
    /** Start an update transaction. */
    tx(): Transaction;
    /** Insert one or more Data packets. */
    insert(...args: S.Insert.Args<InsertOptions>): Promise<void>;
    /** Delete Data packets with given names. */
    delete(...names: Name[]): Promise<void>;
    /** Delete all expired records. */
    clearExpired(): Promise<void>;
}
declare type InsertOptions = Pick<Record, "expireTime">;
/** DataStore update transaction. */
export declare class Transaction {
    private readonly db;
    private readonly store;
    private readonly timestamp;
    private readonly chain;
    private readonly diffs;
    private encodePromises;
    private encodeError?;
    constructor(db: Db, store: DataStore);
    /** Insert a Data packet. */
    insert(data: Data, opts?: InsertOptions): this;
    private insertImpl;
    /** Delete a Data packet. */
    delete(name: Name): this;
    /** Commit the transaction. */
    commit(): Promise<void>;
    private commitWithDiff;
}
export {};
