/// <reference types="node" />
import { type Data, type Interest, type Name } from "@ndn/packet";
import { DataStore as S } from "@ndn/repo-api";
import { TypedEventTarget } from "typescript-event-target";
import { Mutex } from "wait-your-turn";
import * as DB from "./db.js";
type EventMap = {
    /** Emitted when a new record is inserted. */
    insert: DataStore.RecordEvent;
    /** Emitted when an existing record is deleted. */
    delete: DataStore.RecordEvent;
};
declare const kMaybeHaveEventListener: unique symbol;
/**
 * Data packet storage based on LevelDB or other abstract-level compatible key-value database.
 *
 * @remarks
 * Create an instance with {@link makeInMemoryDataStore} or {@link makePersistentDataStore}.
 */
export declare class DataStore extends TypedEventTarget<EventMap> implements AsyncDisposable, S.ListNames, S.ListData, S.Get, S.Find, S.Insert<DataStore.InsertOptions>, S.Delete {
    private readonly db;
    /**
     * Create DataStore from an abstract-level opener function.
     * @param open - Function that opens an abstract-level compatible key-value database with
     * the given options.
     */
    static create(open: DB.DbOpener): Promise<DataStore>;
    /**
     * Create DataStore from an abstract-level subclass constructor.
     * @param ctor - Subclass of abstract-level that accepts options as its last parameter.
     * @param args - `ctor` arguments; last should be options object.
     */
    static create<const A extends unknown[], const O extends {}>(ctor: DB.DbCtor<A, O>, ...args: [...A, O]): Promise<DataStore>;
    private constructor();
    readonly mutex: Mutex;
    readonly [kMaybeHaveEventListener]: Record<string, boolean>;
    /** Close the store. */
    [Symbol.asyncDispose](): Promise<void>;
    private iterRecords;
    /** List Data names, optionally filtered by name prefix. */
    listNames(prefix?: Name): AsyncIterable<Name>;
    /** List Data packets, optionally filtered by name prefix. */
    listData(prefix?: Name): AsyncIterable<Data>;
    /** Retrieve Data by exact name. */
    get(name: Name): Promise<Data | undefined>;
    /** Find Data that satisfies Interest. */
    find(interest: Interest): Promise<Data | undefined>;
    /** Start an update transaction. */
    tx(): Transaction;
    /**
     * Insert one or more Data packets.
     * @see {@link Transaction.insert}
     */
    insert(...args: S.Insert.Args<DataStore.InsertOptions>): Promise<void>;
    /**
     * Delete Data packets with given names.
     * @see {@link Transaction.delete}
     */
    delete(...names: readonly Name[]): Promise<void>;
    /** Delete all expired records. */
    clearExpired(): Promise<void>;
}
export declare namespace DataStore {
    /** {@link DataStore.insert} options. */
    interface InsertOptions {
        expireTime?: number;
    }
    /** Packet record event. */
    class RecordEvent extends Event {
        readonly name: Name;
        constructor(type: string, name: Name);
    }
}
/** DataStore update transaction. */
export declare class Transaction {
    private readonly db;
    private readonly store;
    private readonly timestamp;
    private readonly chain;
    private readonly diffs?;
    constructor(db: DB.Db, store: DataStore);
    /** Insert a Data packet. */
    insert(data: Data, opts?: DataStore.InsertOptions): this;
    /** Delete a Data packet. */
    delete(name: Name): this;
    /** Commit the transaction. */
    commit(): Promise<void>;
    private commitWithDiff;
}
export {};
