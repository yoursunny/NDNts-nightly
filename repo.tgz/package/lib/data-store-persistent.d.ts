import { DataStore } from "./data-store.js";
/** Create a persistent DataStore with `level`. */
export declare function makePersistentDataStore(location: string): Promise<DataStore>;
