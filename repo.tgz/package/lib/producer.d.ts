import { Endpoint } from "@ndn/endpoint";
import { Data, Interest } from "@ndn/packet";
import { DataStore } from "./data-store";
import type { PrefixRegController } from "./prefix-reg/types";
/** Make packets in DataStore available for retrieval. */
export declare class Producer {
    private readonly store;
    private readonly fallback;
    static create(store: DataStore, { endpoint, describe, fallback, reg, }?: Producer.Options): Producer;
    private readonly prod;
    private readonly reg;
    private constructor();
    close(): void;
    private processInterest;
}
export declare namespace Producer {
    interface Options {
        endpoint?: Endpoint;
        describe?: string;
        fallback?: FallbackHandler;
        reg?: PrefixRegController;
    }
    type FallbackHandler = (interest: Interest, producer: Producer, store: DataStore) => Promise<Data | undefined>;
}
