/// <reference types="node" />
import { type Endpoint, type ProducerOptions } from "@ndn/endpoint";
import type { Data, Interest } from "@ndn/packet";
import type { DataStore } from "./data-store.js";
import { type PrefixRegController } from "./prefix-reg/mod.js";
/** Make packets in {@link DataStore} available for retrieval. */
export declare class RepoProducer implements Disposable {
    private readonly store;
    private readonly fallback;
    static create(store: DataStore, { endpoint, // eslint-disable-line etc/no-deprecated
    pOpts, describe, fallback, reg, }?: RepoProducer.Options): RepoProducer;
    private readonly prod;
    private readonly reg;
    private constructor();
    /**
     * Close the producer and prefix registration controller.
     * This does not close the DataStore.
     */
    [Symbol.dispose](): void;
    private readonly processInterest;
}
export declare namespace RepoProducer {
    /** {@link RepoProducer.create} options. */
    interface Options {
        /**
         * Endpoint for communication.
         * @deprecated Specify `.pOpts`.
         */
        endpoint?: Endpoint;
        /**
         * Producer options.
         *
         * @remarks
         * - `.describe` defaults to {@link Options.describe}.
         */
        pOpts?: ProducerOptions;
        /**
         * Description for debugging purpose.
         * @defaultValue "repo"
         */
        describe?: string;
        /**
         * Interest handler function for when Data is not found in repo.
         *
         * @remarks
         * To support RDR metadata version discovery, pass {@link respondRdr} as this option.
         */
        fallback?: FallbackHandler;
        /**
         * Prefix registration controller.
         * @defaultValue
         * Register each Data prefix with non-generic components stripped.
         */
        reg?: PrefixRegController;
    }
    type FallbackHandler = (interest: Interest, producer: RepoProducer, store: DataStore) => Promise<Data | undefined>;
}
