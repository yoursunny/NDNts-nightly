import { replyMetadata } from "@ndn/repo-api";
import type { RepoProducer } from "./producer.js";
/**
 * Provide a {@link RepoProducer.FallbackHandler} that replies to metadata discovery Interests.
 *
 * @remarks
 * The returned function should be passed as {@link RepoProducer.Options.fallback}.
 */
export declare function metadataFallback(opts?: replyMetadata.Options): RepoProducer.FallbackHandler;
