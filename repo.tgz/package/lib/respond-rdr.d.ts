import { respondRdr as apiRespondRdr } from "@ndn/repo-api";
import type { Producer } from "./producer";
/**
 * Provide a Producer.FallbackHandler that responds RDR metadata describing latest version
 * among stored Data. This should be passed to Producer.create() options.
 */
export declare function respondRdr(opts?: apiRespondRdr.Options): Producer.FallbackHandler;
