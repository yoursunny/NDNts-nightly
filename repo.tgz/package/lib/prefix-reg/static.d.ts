import type { Name } from "@ndn/packet";
import type { PrefixRegController } from "./types.js";
/** Register a fixed set of prefixes. */
export declare function PrefixRegStatic(...prefixes: Name[]): PrefixRegController;
