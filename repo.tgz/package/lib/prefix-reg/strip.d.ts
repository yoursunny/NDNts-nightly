import { Component, ComponentLike, NamingConvention } from "@ndn/packet";
import type { PrefixRegController } from "./types";
/** Register prefixes after stripping last few components matching a predicate. */
export declare function PrefixRegStrip(...predicates: PrefixRegStrip.ComponentPredicate[]): PrefixRegController;
export declare namespace PrefixRegStrip {
    type ComponentPredicate = ComponentLike | ((comp: Component) => boolean) | NamingConvention<any>;
    /** A predicate that strips non-generic components. */
    function stripNonGeneric(c: Component): boolean;
}
