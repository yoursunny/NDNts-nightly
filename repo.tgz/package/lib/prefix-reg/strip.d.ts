import { Component, type ComponentLike, NamingConvention } from "@ndn/packet";
import type { PrefixRegController } from "./types.js";
/**
 * Register prefixes after stripping last few components matching a predicate.
 *
 * @remarks
 * Warning: this may misbehave when {@link DataStore.InsertOptions.expireTime} is being used.
 */
export declare function PrefixRegStrip(...predicates: readonly PrefixRegStrip.ComponentPredicate[]): PrefixRegController;
export declare namespace PrefixRegStrip {
    type ComponentPredicate = ComponentLike | ((c: Component) => boolean) | NamingConvention<any>;
    /** A predicate that strips non-generic components. */
    function stripNonGeneric(c: Component): boolean;
}
