export type { PrefixRegController } from "./types.js";
export * from "./static.js";
export * from "./dynamic.js";
export * from "./strip.js";
