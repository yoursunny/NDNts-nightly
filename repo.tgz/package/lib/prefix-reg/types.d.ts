import type { FwFace } from "@ndn/fw";
import type { DataStore } from "../data-store";
export interface PrefixRegContext {
    close: () => void;
}
declare type Face = Pick<FwFace, "addRoute" | "removeRoute">;
/** Control prefix registrations of a repo producer. */
export declare type PrefixRegController = (store: DataStore, face: Face) => PrefixRegContext;
export {};
