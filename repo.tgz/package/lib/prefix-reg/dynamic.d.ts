import type { Name } from "@ndn/packet";
import type { PrefixRegController } from "./types";
/**
 * Register prefixes derived from Data names.
 * @param transform a function that accepts Data name and returns registered prefix name;
 *                  it must return the same value for the same argument.
 *
 * Warning: this may misbehave when expireTime option is being used.
 */
export declare function PrefixRegDynamic(transform: (name: Name) => Name): PrefixRegController;
/** Register prefixes k components shorter than Data names. */
export declare function PrefixRegShorter(k: number): PrefixRegController;
