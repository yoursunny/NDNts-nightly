import type { Name } from "@ndn/packet";
import type { PrefixRegController } from "./types.js";
/**
 * Register prefixes derived from Data names.
 * @param transform - Function that accepts Data name and returns registered prefix name.
 * It must be a pure function i.e. returns the same value for the same argument.
 *
 * @remarks
 * Warning: this may misbehave when {@link DataStore.InsertOptions.expireTime} is being used.
 */
export declare function PrefixRegDynamic(transform: (name: Name) => Name): PrefixRegController;
/**
 * Register prefixes k components shorter than Data names.
 * @param k - Number of final name components to strip.
 *
 * @remarks
 * Warning: this may misbehave when {@link DataStore.InsertOptions.expireTime} is being used.
 */
export declare function PrefixRegShorter(k: number): PrefixRegController;
