/// <reference types="node" />
import { L3Face, Transport } from "@ndn/l3face";
import type { AddressInfo } from "net";
import * as udp from "./udp-helper";
/** UDP socket transport. */
export declare class UdpTransport extends Transport {
    readonly rx: Transport.Rx;
    readonly isMulticast: boolean;
    readonly laddr: AddressInfo;
    readonly raddr: AddressInfo;
    private readonly rxSock;
    private readonly txSock;
    constructor(unicast: udp.Socket);
    constructor(multicastTx: udp.Socket, multicastRx: udp.Socket);
    close(): void;
    tx: (iterable: AsyncIterable<Uint8Array>) => Promise<void>;
}
export declare namespace UdpTransport {
    /**
     * Create a unicast transport.
     * @param host remote host.
     * @param port remote port, default is 6363.
     */
    function connect(host: string, port?: number): Promise<UdpTransport>;
    /** Create a unicast transport. */
    function connect(opts: udp.UnicastOptions): Promise<UdpTransport>;
    /** Create a unicast transport and add to forwarder. */
    const createFace: L3Face.CreateFaceFunc<typeof connect>;
    /** Create a multicast transport. */
    function multicast(opts: udp.MulticastOptions): Promise<UdpTransport>;
    /** Create a multicast transport and add to forwarder. */
    const createMulticastFace: L3Face.CreateFaceFunc<typeof multicast>;
    /** Create multicast transports on every interface. */
    function multicasts(opts?: Omit<udp.MulticastOptions, "intf">): Promise<UdpTransport[]>;
    /** Create multicast transports on every interface. */
    const createMulticastFaces: L3Face.CreateFaceFunc<typeof multicasts>;
}
