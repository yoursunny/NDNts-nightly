import dgram from "node:dgram";
import type { AddressInfo } from "node:net";
import { L3Face, Transport } from "@ndn/l3face";
import type { Except } from "type-fest";
import * as udp from "./udp-helper.js";
/** UDP socket transport. */
export declare class UdpTransport extends Transport {
    /**
     * Create a unicast transport.
     * @param host - Remote host or endpoint address (with other options) or existing socket.
     * @param port - Remote port. Default is 6363.
     * @see {@link UdpTransport.createFace}
     */
    static connect(host: string | udp.UnicastOptions | dgram.Socket, port?: number): Promise<UdpTransport>;
    /**
     * Create a multicast transport.
     * @param opts - Network interface and other options.
     * @see {@link UdpTransport.createMulticastFace}
     */
    static multicast(opts: udp.MulticastOptions): Promise<UdpTransport>;
    private constructor();
    private constructor();
    /** Local endpoint address. */
    readonly laddr: AddressInfo;
    /** Remote endpoint or multicast group address. */
    readonly raddr: AddressInfo;
    private readonly rxSock;
    private readonly txSock;
    /**
     * Report MTU as 65487.
     * @see {@link https://superuser.com/a/1697822}
     */
    get mtu(): number;
    readonly rx: Transport.RxIterable;
    tx(iterable: Transport.TxIterable): Promise<void>;
    close(): void;
}
export declare namespace UdpTransport {
    /** Create a unicast transport and add to forwarder. */
    const createFace: L3Face.CreateFaceFunc<[host: string | dgram.Socket | udp.UnicastOptions, port?: number | undefined]>;
    /** Create a multicast transport and add to forwarder. */
    const createMulticastFace: L3Face.CreateFaceFunc<[opts: udp.MulticastOptions]>;
    /** Create multicast transports on every multicast-capable netif. */
    function multicasts(opts?: Except<udp.MulticastOptions, "intf">): Promise<UdpTransport[]>;
    /** Create multicast transports on every multicast-capable netif and add to forwarder. */
    const createMulticastFaces: L3Face.CreateFacesFunc<[opts?: {
        recvBufferSize?: number | undefined;
        sendBufferSize?: number | undefined;
        group?: string;
        port?: number;
        multicastTtl?: number;
        multicastLoopback?: boolean;
    } | undefined]>;
}
