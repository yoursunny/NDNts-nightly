/// <reference types="node" />
import * as dgram from "dgram";
export declare type Socket = dgram.Socket;
declare type SocketOptions = Pick<dgram.SocketOptions, "recvBufferSize" | "sendBufferSize">;
interface AddressFamilyOption {
    /**
     * IPv4 or IPv6.
     * Default is IPv4, unless `host` is an IPv6 address (contains a colon).
     */
    family?: 4 | 6;
}
export declare type OpenSocketOptions = SocketOptions & AddressFamilyOption & {
    /** Bind options, such as local address and port. */
    bind?: dgram.BindOptions;
};
export interface ConnectOptions extends AddressFamilyOption {
    /** Remote address. */
    host: string;
    /** Remote port. */
    port?: number;
}
export declare function connect(sock: Socket, { host, port, }: ConnectOptions): Promise<Socket>;
export declare type UnicastOptions = OpenSocketOptions & ConnectOptions;
export declare function openUnicast(opts: UnicastOptions): Promise<Socket>;
export declare function listMulticastIntfs(): string[];
export declare type MulticastOptions = SocketOptions & {
    /** IPv4 address of local network interface. */
    intf: string;
    /** Multicast group address. */
    group?: string;
    /** Local and group port. */
    port?: number;
    /** Multicast TTL (for unit testing). */
    multicastTtl?: number;
    /** MulticastLoopback flag (for unit testing). */
    multicastLoopback?: boolean;
};
export declare function openMulticastRx(opts: MulticastOptions): Promise<Socket>;
export declare function openMulticastTx(opts: MulticastOptions): Promise<Socket>;
export {};
