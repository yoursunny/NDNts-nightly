import dgram from "node:dgram";
export type SocketBufferOptions = Pick<dgram.SocketOptions, "recvBufferSize" | "sendBufferSize">;
export type AddressFamily = 4 | 6;
/** {@link openSocket} options. */
export interface OpenSocketOptions extends SocketBufferOptions {
    /**
     * IPv4 or IPv6.
     * @defaultValue
     * IPv4, unless hostname is a literal IPv6 address.
     */
    family?: AddressFamily;
    /** Bind options, such as local address and port. */
    bind?: dgram.BindOptions;
}
/** Create a UDP socket and start listening on local endpoint. */
export declare function openSocket({ family, recvBufferSize, sendBufferSize, bind, }: OpenSocketOptions): Promise<dgram.Socket>;
/** {@link connect} options. */
export interface ConnectOptions {
    /** Remote address. */
    host: string;
    /** Remote port. */
    port?: number;
}
/** Connect a UDP socket to remote endpoint. */
export declare function connect(sock: dgram.Socket, { host, port, }: ConnectOptions): Promise<dgram.Socket>;
/** {@link openUnicast} options. */
export interface UnicastOptions extends OpenSocketOptions, ConnectOptions {
}
/** Create a UDP socket and connect to remote endpoint. */
export declare function openUnicast(opts: UnicastOptions): Promise<dgram.Socket>;
/**
 * List network interfaces capable of IPv4 multicast.
 * @returns IPv4 address of each network interface.
 */
export declare function listMulticastIntfs(): string[];
/** {@link openMulticastRx} and {@link openMulticastTx} options. */
export interface MulticastOptions extends SocketBufferOptions {
    /** IPv4 address of local network interface. */
    intf: string;
    /**
     * Multicast group address.
     * @defaultValue 224.0.23.170
     *
     * @remarks
     * On non-Linux platforms, if multiple multicast UDP transports are using the same port number
     * but different group addresses, incoming traffic may be received on all sockets regardless of
     * the group address. This also affects multicast UDP transports in other programs such as YaNFD.
     * To isolate the traffic, the port number must be changed.
     */
    group?: string;
    /**
     * Local and group port.
     * @defaultValue 56363
     */
    port?: number;
    /**
     * Multicast TTL.
     * @defaultValue 1
     *
     * @remarks
     * Changing this option is inadvisable except for unit testing.
     */
    multicastTtl?: number;
    /**
     * MulticastLoopback flag.
     * @defaultValue false
     *
     * @remarks
     * Changing this option is inadvisable except for unit testing.
     */
    multicastLoopback?: boolean;
}
/** Create a UDP socket and prepare for receiving multicast datagrams. */
export declare function openMulticastRx(opts: MulticastOptions): Promise<dgram.Socket>;
/** Create a UDP socket and prepare for transmitting multicast datagrams. */
export declare function openMulticastTx(opts: MulticastOptions): Promise<dgram.Socket>;
