import type { IpcSocketConnectOpts, Socket } from "node:net";
import { L3Face, StreamTransport } from "@ndn/l3face";
/** Unix socket transport. */
export declare class UnixTransport extends StreamTransport<Socket> {
    private readonly connectOpts;
    /**
     * Create a transport and connect to remote endpoint.
     * @param path - Unix socket path or IPC options.
     * @see {@link UnixTransport.createFace}
     */
    static connect(path: string | IpcSocketConnectOpts): Promise<UnixTransport>;
    private constructor();
    /** Reopen the transport by making a new connection with the same options. */
    reopen(): Promise<UnixTransport>;
}
export declare namespace UnixTransport {
    /** Create a transport and add to forwarder. */
    const createFace: L3Face.CreateFaceFunc<[path: string | IpcSocketConnectOpts]>;
}
