/// <reference types="node" />
import { L3Face, StreamTransport } from "@ndn/l3face";
import * as net from "net";
/** Unix socket transport. */
export declare class UnixTransport extends StreamTransport {
    private readonly connectOpts;
    constructor(sock: net.Socket, connectOpts: net.IpcNetConnectOpts);
    reopen(): Promise<UnixTransport>;
}
export declare namespace UnixTransport {
    /**
     * Create a transport and connect to remote endpoint.
     * @param pathOrOpts Unix socket path.
     */
    function connect(pathOrOpts: string | net.IpcNetConnectOpts): Promise<UnixTransport>;
    /** Create a transport and add to forwarder. */
    const createFace: L3Face.CreateFaceFunc<typeof connect>;
}
