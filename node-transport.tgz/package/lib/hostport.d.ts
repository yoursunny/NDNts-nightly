/** Combine host and port into a network address of the form "host:port". */
export declare function joinHostPort(hostname: string, port: number): string;
/** Split a network address of the form "host:port" into host and port. */
export declare function splitHostPort(hostport: string): {
    host: string;
    port?: number;
};
