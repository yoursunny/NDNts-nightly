import type { Socket, TcpSocketConnectOpts } from "node:net";
import { L3Face, StreamTransport } from "@ndn/l3face";
import type { SetOptional } from "type-fest";
/** TCP socket transport. */
export declare class TcpTransport extends StreamTransport<Socket> {
    private readonly connectOpts;
    /**
     * Create a transport and connect to remote endpoint.
     * @param host - Remote host (default is localhost) or endpoint address (with other options).
     * @param port - Remote port. Default is 6363.
     * @param opts - Other options.
     * @see {@link TcpTransport.createFace}
     */
    static connect(host?: string | (SetOptional<TcpSocketConnectOpts, "port"> & TcpTransport.Options), port?: number, opts?: TcpTransport.Options): Promise<TcpTransport>;
    private constructor();
    /** Reopen the transport by making a new connection with the same options. */
    reopen(): Promise<TcpTransport>;
}
export declare namespace TcpTransport {
    /** {@link TcpTransport.connect} options. */
    interface Options {
        /**
         * Connect timeout (in milliseconds).
         * @defaultValue 10000
         */
        connectTimeout?: number;
    }
    /** Create a transport and add to forwarder. */
    const createFace: L3Face.CreateFaceFunc<[host?: string | ({
        host?: string | undefined;
        localAddress?: string | undefined;
        localPort?: number | undefined;
        hints?: number | undefined;
        family?: number | undefined;
        lookup?: import("net").LookupFunction | undefined;
        noDelay?: boolean | undefined;
        keepAlive?: boolean | undefined;
        keepAliveInitialDelay?: number | undefined;
        autoSelectFamily?: boolean | undefined;
        autoSelectFamilyAttemptTimeout?: number | undefined;
        onread?: import("net").OnReadOpts | undefined;
        port?: number | undefined;
    } & Options) | undefined, port?: number | undefined, opts?: Options | undefined]>;
}
