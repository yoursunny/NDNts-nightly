/// <reference types="node" />
import { L3Face, StreamTransport } from "@ndn/l3face";
import type { AbortSignal } from "abort-controller";
import * as net from "net";
/** TCP socket transport. */
export declare class TcpTransport extends StreamTransport {
    private readonly connectOpts;
    constructor(sock: net.Socket, connectOpts: net.TcpNetConnectOpts);
    reopen(): Promise<TcpTransport>;
}
export declare namespace TcpTransport {
    type NetConnectOpts = Omit<net.TcpNetConnectOpts, "port"> & Partial<Pick<net.TcpNetConnectOpts, "port">>;
    interface Options {
        /** Connect timeout (in milliseconds). */
        connectTimeout?: number;
        /** AbortSignal that allows canceling connection attempt via AbortController. */
        signal?: AbortSignal | globalThis.AbortSignal;
    }
    /**
     * Create a transport and connect to remote endpoint.
     * @param host remote host, default is "localhost".
     * @param port remote port, default is 6363.
     * @param opts other options.
     */
    function connect(host?: string, port?: number, opts?: Options): Promise<TcpTransport>;
    /**
     * Create a transport and connect to remote endpoint.
     * @param opts remote endpoint and other options.
     */
    function connect(opts: NetConnectOpts & Options): Promise<TcpTransport>;
    /** Create a transport and add to forwarder. */
    const createFace: L3Face.CreateFaceFunc<typeof connect>;
}
