/// <reference types="node" />
import net from "node:net";
export declare function connectAndWaitConnected(opts: net.NetConnectOpts & {
    connectTimeout?: number;
}): Promise<net.Socket>;
