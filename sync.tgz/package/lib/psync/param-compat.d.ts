import type { IBLT } from "../iblt";
import type { PSyncCodec } from "./codec";
import type { PSyncFull } from "./full";
import { PSyncPartialPublisher } from "./partial-publisher";
import type { PSyncPartialSubscriber } from "./partial-subscriber";
export declare function hash(seed: number, input: Uint8Array): number;
export declare function makeIbltParams(expectedEntries: number, keyToBufferLittleEndian: boolean, serializeLittleEndian?: boolean): IBLT.Parameters;
/** Create algorithm parameters to be compatible with PSync C++ library. */
export declare function makePSyncCompatParam({ keyToBufferLittleEndian, expectedEntries, expectedSubscriptions, ibltCompression, contentCompression, }?: makePSyncCompatParam.Options): PSyncFull.Parameters & PSyncPartialPublisher.Parameters & PSyncPartialSubscriber.Parameters;
export declare namespace makePSyncCompatParam {
    interface Options {
        /**
         * Whether to use little endian when converting uint32 key to Uint8Array.
         * PSync C++ library behaves differently on big endian and little endian machines,
         * https://github.com/named-data/PSync/blob/b60398c5fc216a1b577b9dbcf61d48a21cb409a4/PSync/detail/util.cpp#L126
         * This must be set to match other peers.
         * @default true
         */
        keyToBufferLittleEndian?: boolean;
        /**
         * Expected number of IBLT entries, i.e. expected number of updates in a sync cycle.
         * This is irrelevant to PartialSync consumer.
         * @default 80
         */
        expectedEntries?: number;
        /**
         * Estimated number of subscriptions in PartialSync consumer.
         * @default 16
         */
        expectedSubscriptions?: number;
        /**
         * Whether to use zlib compression on IBLT.
         * Default is no compression. Use `PSyncZlib` to set zlib compression.
         *
         * In PSync C++ library, default for FullSync depends on whether zlib is available at compile
         * time, and default for PartialSync is no compression.
         * This must be set to match other peers.
         */
        ibltCompression?: PSyncCodec.Compression;
        /**
         * Whether to use zlib compression on Data payload.
         * Default is no compression. Use `PSyncZlib` to set zlib compression.
         *
         * In PSync C++ library, default for FullSync depends on whether zlib is available at compile
         * time. For PartialSync, it is always no compression.
         * This must be set to match other peers.
         */
        contentCompression?: PSyncCodec.Compression;
    }
}
