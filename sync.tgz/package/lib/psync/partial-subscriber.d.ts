import { Endpoint } from "@ndn/endpoint";
import { Name, Verifier } from "@ndn/packet";
import { Parameters as BloomParameters } from "@yoursunny/psync-bloom";
import type TypedEmitter from "typed-emitter";
import { Subscriber, Subscription, SyncUpdate } from "../types";
import { PSyncCodec } from "./codec";
import { PSyncCore } from "./core";
declare type Sub = Subscription<Name, SyncUpdate<Name>>;
declare type Update = SyncUpdate<Name>;
interface DebugEntry {
    action: string;
}
interface Events {
    debug: (entry: DebugEntry) => void;
    state: (topics: readonly PSyncPartialSubscriber.TopicInfo[]) => void;
}
declare const PSyncPartialSubscriber_base: new () => TypedEmitter<Events>;
/** PSync - PartialSync subscriber. */
export declare class PSyncPartialSubscriber extends PSyncPartialSubscriber_base implements Subscriber<Name, Update, PSyncPartialSubscriber.TopicInfo> {
    constructor({ p, endpoint, describe, syncPrefix, syncInterestLifetime, syncInterestInterval, verifier, }: PSyncPartialSubscriber.Options);
    readonly describe: string;
    private readonly helloPrefix;
    private readonly syncPrefix;
    private readonly codec;
    private readonly encodeBloom;
    private closed;
    private readonly subs;
    private readonly prevSeqNums;
    private bloom;
    private ibltComp?;
    private readonly cFetcher;
    private readonly cInterval;
    private cTimer;
    private cAbort?;
    private debug;
    /** Stop the protocol operation. */
    close(): void;
    subscribe(topic: PSyncPartialSubscriber.TopicInfo): Sub;
    private handleAddTopic;
    private handleRemoveTopic;
    private scheduleInterest;
    private sendInterest;
    private sendHelloInterest;
    private sendSyncInterest;
    private handleState;
}
export declare namespace PSyncPartialSubscriber {
    interface Parameters extends PSyncCore.Parameters, PSyncCodec.Parameters {
        bloom: BloomParameters;
    }
    interface Options {
        /**
         * Algorithm parameters.
         * They must match the publisher parameters.
         */
        p: Parameters;
        /** Endpoint for communication. */
        endpoint?: Endpoint;
        /** Description for debugging purpose. */
        describe?: string;
        /** Sync producer prefix. */
        syncPrefix: Name;
        /**
         * Sync Interest lifetime in milliseconds.
         * @default 1000
         */
        syncInterestLifetime?: number;
        /**
         * Interval between sync Interests, randomized within the range, in milliseconds.
         * @default [syncInterestLifetime/2+100,syncInterestLifetime/2+500]
         */
        syncInterestInterval?: [min: number, max: number];
        /**
         * Verifier of sync reply Data packets.
         * Default is no verification.
         */
        verifier?: Verifier;
    }
    interface TopicInfo extends PSyncCore.PrefixSeqNum {
    }
}
export {};
