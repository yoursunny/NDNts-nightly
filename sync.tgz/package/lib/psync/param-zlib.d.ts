import type { PSyncCodec } from "./codec";
/** Use zlib compression with PSync. */
export declare const PSyncZlib: PSyncCodec.Compression;
