import { Endpoint } from "@ndn/endpoint";
import { Name, Signer } from "@ndn/packet";
import type TypedEmitter from "typed-emitter";
import type { SyncNode, SyncProtocol } from "../types";
import { PSyncCodec } from "./codec";
import { PSyncCore } from "./core";
interface DebugEntry {
    action: string;
    interestName?: Name;
}
interface Events extends SyncProtocol.Events<Name> {
    debug: (entry: DebugEntry) => void;
}
declare const PSyncPartialPublisher_base: new () => TypedEmitter<Events>;
/** PSync - PartialSync publisher. */
export declare class PSyncPartialPublisher extends PSyncPartialPublisher_base implements SyncProtocol<Name> {
    constructor({ p, endpoint, describe, syncPrefix, helloReplyFreshness, syncReplyFreshness, signer, producerBufferLimit, }: PSyncPartialPublisher.Options);
    private readonly endpoint;
    readonly describe: string;
    private readonly syncPrefix;
    private readonly c;
    private readonly codec;
    private closed;
    private readonly pBuffer;
    private readonly hFreshness;
    private readonly hProducer;
    private readonly sFreshness;
    private readonly sProducer;
    private readonly sPendings;
    private debug;
    /** Stop the protocol operation. */
    close(): void;
    get(prefix: Name): SyncNode<Name> | undefined;
    add(prefix: Name): SyncNode<Name>;
    private handleHelloInterest;
    private handleSyncInterest;
    private handleIncreaseSeqNum;
    private sendStateData;
}
export declare namespace PSyncPartialPublisher {
    interface Parameters extends PSyncCore.Parameters, PSyncCodec.Parameters {
    }
    interface Options {
        /**
         * Algorithm parameters.
         * They must match the subscriber parameters.
         */
        p: Parameters;
        /** Endpoint for communication. */
        endpoint?: Endpoint;
        /** Description for debugging purpose. */
        describe?: string;
        /** Sync producer prefix. */
        syncPrefix: Name;
        /**
         * FreshnessPeriod of hello reply Data packet.
         * @default 1000
         */
        helloReplyFreshness?: number;
        /**
         * FreshnessPeriod of sync reply Data packet.
         * @default 1000
         */
        syncReplyFreshness?: number;
        /**
         * Signer of sync reply Data packets.
         * Default is digest signing.
         */
        signer?: Signer;
        /**
         * How many sync reply segmented objects to keep in buffer.
         * This must be positive.
         * @default 32
         */
        producerBufferLimit?: number;
    }
}
export {};
