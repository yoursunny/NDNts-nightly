import { Endpoint } from "@ndn/endpoint";
import { Name, Signer, Verifier } from "@ndn/packet";
import type TypedEmitter from "typed-emitter";
import { IntervalRange } from "../detail/interval";
import type { IBLT } from "../iblt";
import { SyncNode, SyncProtocol } from "../types";
import { PSyncCodec } from "./codec";
import { PSyncCore } from "./core";
interface DebugEntry {
    action: string;
    ownIblt: IBLT;
    recvIblt?: IBLT;
    state?: PSyncCore.State;
}
interface Events extends SyncProtocol.Events<Name> {
    debug: (entry: DebugEntry) => void;
}
declare const PSyncFull_base: new () => TypedEmitter<Events>;
/** PSync - FullSync participant. */
export declare class PSyncFull extends PSyncFull_base implements SyncProtocol<Name> {
    constructor({ p, endpoint, describe, syncPrefix, addSyncPrefixOnUplinks, syncReplyFreshness, signer, producerBufferLimit, syncInterestLifetime, syncInterestInterval, verifier, }: PSyncFull.Options);
    private readonly endpoint;
    readonly describe: string;
    private readonly syncPrefix;
    private readonly c;
    private readonly codec;
    private readonly uplinkRouteMirror?;
    private closed;
    private readonly pFreshness;
    private readonly pBuffer;
    private readonly pProducer;
    private readonly pPendings;
    private readonly cFetcher;
    private readonly cInterval;
    private cTimer;
    private cAbort?;
    private cCurrentInterestName?;
    private debug;
    /** Stop the protocol operation. */
    close(): void;
    get(prefix: Name): SyncNode<Name> | undefined;
    add(prefix: Name): SyncNode<Name>;
    private handleSyncInterest;
    private handleIncreaseSeqNum;
    private sendSyncData;
    private scheduleSyncInterest;
    private sendSyncInterest;
}
export declare namespace PSyncFull {
    interface Parameters extends PSyncCore.Parameters, PSyncCodec.Parameters {
    }
    interface Options {
        /**
         * Algorithm parameters.
         * They must be the same on every peer.
         */
        p: Parameters;
        /** Endpoint for communication. */
        endpoint?: Endpoint;
        /** Description for debugging purpose. */
        describe?: string;
        /** Sync group prefix. */
        syncPrefix: Name;
        /**
         * Whether to automatically add sync group prefix as a route on uplinks.
         * @default true
         */
        addSyncPrefixOnUplinks?: boolean;
        /**
         * FreshnessPeriod of sync reply Data packet.
         * @default 1000
         */
        syncReplyFreshness?: number;
        /**
         * Signer of sync reply Data packets.
         * Default is digest signing.
         */
        signer?: Signer;
        /**
         * How many sync reply segmented objects to keep in buffer.
         * This must be positive.
         * @default 32
         */
        producerBufferLimit?: number;
        /**
         * Sync Interest lifetime in milliseconds.
         * @default 1000
         */
        syncInterestLifetime?: number;
        /**
         * Interval between sync Interests, randomized within the range, in milliseconds.
         * @default [syncInterestLifetime/2+100,syncInterestLifetime/2+500]
         */
        syncInterestInterval?: IntervalRange;
        /**
         * Verifier of sync reply Data packets.
         * Default is no verification.
         */
        verifier?: Verifier;
    }
}
export {};
