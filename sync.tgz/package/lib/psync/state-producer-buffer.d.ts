import type { Endpoint } from "@ndn/endpoint";
import type { Name, Signer } from "@ndn/packet";
import { Server } from "@ndn/segmented-object";
import type { PSyncCodec } from "./codec";
import { PSyncCore } from "./core";
export declare class PSyncStateProducerBuffer {
    private readonly endpoint;
    private readonly describe;
    private readonly codec;
    private readonly signer;
    private readonly limit;
    constructor(endpoint: Endpoint, describe: string, codec: PSyncCodec, signer: Signer | undefined, limit: number);
    private readonly servers;
    close(): void;
    add(name: Name, state: PSyncCore.State, freshnessPeriod: number): Server;
    private evict;
}
