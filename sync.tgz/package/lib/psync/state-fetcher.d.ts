import type { Endpoint } from "@ndn/endpoint";
import type { Name, Verifier } from "@ndn/packet";
import { AbortController } from "abort-controller";
import type { PSyncCodec } from "./codec";
import { PSyncCore } from "./core";
interface Result {
    versioned: Name;
    state: PSyncCore.State;
}
export declare class PSyncStateFetcher {
    private readonly endpoint;
    private readonly describe;
    private readonly codec;
    private readonly syncInterestLifetime;
    private readonly verifier;
    constructor(endpoint: Endpoint, describe: string, codec: PSyncCodec, syncInterestLifetime: number, verifier: Verifier | undefined);
    fetch(name: Name, { signal }: AbortController, describeSuffix?: string): Promise<Result>;
}
export {};
