import type { Data } from "@ndn/packet";
import { Compression as Compression_, IbltCodec } from "../detail/iblt-codec";
import type { IBLT } from "../iblt";
export declare class SyncpsCodec {
    protected readonly ibltParams: IBLT.PreparedParameters;
    constructor(p: SyncpsCodec.Parameters, ibltParams: IBLT.PreparedParameters);
}
export interface SyncpsCodec extends Readonly<SyncpsCodec.Parameters>, IbltCodec {
}
export declare namespace SyncpsCodec {
    type Compression = Compression_;
    interface Parameters {
        /** Compression method for IBLT in name component. */
        ibltCompression: Compression;
        /** Compute the hash of a publication. */
        hashPub: (pub: Data) => number;
        /** Encode Content to buffer. */
        encodeContent: (pubs: readonly Data[], maxSize: number) => [wire: Uint8Array, count: number];
        /** Decode Content from buffer. */
        decodeContent: (payload: Uint8Array) => Data[];
    }
}
