import { Endpoint } from "@ndn/endpoint";
import { Data, Name, Signer, Verifier } from "@ndn/packet";
import type TypedEmitter from "typed-emitter";
import { IBLT } from "../iblt";
import type { Subscriber, Subscription } from "../types";
import { SyncpsCodec } from "./codec";
interface DebugEntry {
    action: string;
    key?: number;
    name?: Name;
    ownIblt: IBLT;
    recvIblt?: IBLT;
    content?: Name[];
}
interface Events {
    debug: (entry: DebugEntry) => void;
}
declare const SyncpsPubsub_base: new () => TypedEmitter<Events>;
/** syncps - pubsub service. */
export declare class SyncpsPubsub extends SyncpsPubsub_base implements Subscriber<Name, Data> {
    constructor({ p, endpoint, describe, syncPrefix, addSyncPrefixOnUplinks, syncInterestLifetime, syncDataPubSize, syncSigner, syncVerifier, maxPubLifetime, maxClockSkew, modifyPublication, isExpired, filterPubs, pubSigner, pubVerifier, }: SyncpsPubsub.Options);
    private readonly endpoint;
    readonly describe: string;
    private readonly syncPrefix;
    private readonly codec;
    private readonly uplinkRouteMirror?;
    private closed;
    private readonly iblt;
    private readonly pubs;
    private readonly maxPubLifetime;
    private readonly maxClockSkew;
    private readonly subs;
    private readonly dModify;
    private readonly dIsExpired;
    private readonly dSigner;
    private readonly dVerifier?;
    private nOwnPubs;
    /** IBLT of own publications with callback. */
    private readonly dConfirmIblt;
    private readonly pProducer;
    private readonly pFilter;
    private readonly pPubSize;
    private readonly pPendings;
    private readonly cVerifier?;
    private readonly cLifetime;
    private cAbort?;
    private cTimer;
    private cCurrentInterestNonce?;
    private cDelivering;
    private debug;
    /** Stop the protocol operation. */
    close(): void;
    /**
     * Publish a packet.
     * @param pub a Data packet. This does not need to be signed.
     * @param cb a callback to get notified whether publication is confirmed,
     *           i.e. its hash appears in a sync Interest from another participant.
     * @returns a Promise that resolves when the publication is recorded.
     *          It does not mean the publication has reached other participants.
     */
    publish(pub: Data, cb?: SyncpsPubsub.PublishCallback): Promise<void>;
    /**
     * Subscribe to a topic.
     * @param topic a name prefix.
     */
    subscribe(topic: Name): Subscription<Name, Data>;
    private handleSyncInterest;
    private processSyncInterest;
    private processPendingInterests;
    private scheduleSyncInterest;
    private sendSyncInterest;
    private isExpired;
    private addToActive;
    private invokePublishCb;
}
export declare namespace SyncpsPubsub {
    interface Parameters extends SyncpsCodec.Parameters {
        iblt: IBLT.Parameters;
    }
    type ModifyPublicationCallback = (pub: Data) => void;
    /**
     * Callback to determine if a publication is expired.
     *
     * The callback can return either:
     * - boolean to indicate whether the publication is expired.
     * - number, interpreted as Unix timestamp (milliseconds) of publication creation time.
     *   The publication is considered expired if this timestamp is before
     *   `NOW - (maxPubLifetime+maxClockSkew)` or after `NOW + maxClockSkew`.
     */
    type IsExpiredCallback = (pub: Data) => boolean | number;
    interface FilterPubItem {
        /** A publication, i.e. Data packet. */
        readonly pub: Data;
        /** Whether the publication is owned by the local participant. */
        readonly own: boolean;
    }
    /**
     * Callback to decide what publications to be included in a response.
     * Argument contains unexpired publications only.
     * It should return a priority list of publications to be included in the response.
     */
    type FilterPubsCallback = (items: FilterPubItem[]) => FilterPubItem[];
    interface Options {
        /**
         * Algorithm parameters.
         * They must be the same on every peer.
         */
        p: Parameters;
        /** Endpoint for communication. */
        endpoint?: Endpoint;
        /** Description for debugging purpose. */
        describe?: string;
        /** Sync group prefix. */
        syncPrefix: Name;
        /**
         * Whether to automatically add sync group prefix as a route on uplinks.
         * @default true
         */
        addSyncPrefixOnUplinks?: boolean;
        /**
         * Sync Interest lifetime in milliseconds.
         * @default 4000
         */
        syncInterestLifetime?: number;
        /**
         * Advisory maximum size for publications included in a sync reply Data packet.
         * @default 1300
         */
        syncDataPubSize?: number;
        /**
         * Signer of sync reply Data packets.
         * Default is digest signing.
         */
        syncSigner?: Signer;
        /**
         * Verifier of sync reply Data packets.
         * Default is no verification.
         */
        syncVerifier?: Verifier;
        /**
         * Publication lifetime.
         * @default 1000
         */
        maxPubLifetime?: number;
        /**
         * Maximum clock skew, for calculating timers.
         * @default 1000
         */
        maxClockSkew?: number;
        /**
         * Callback to modify publication before it's signed.
         * Default is appending a TimestampNameComponent to the name.
         */
        modifyPublication?: ModifyPublicationCallback;
        /**
         * Callback to determine if a publication is expired.
         * Default is interpreting the last component as TimestampNameComponent;
         * if the last component is not a TimestampNameComponent, it is seen as expired.
         */
        isExpired?: IsExpiredCallback;
        /**
         * Callback to decide what publications to be included in a response.
         * Default is: respond nothing if there's no own publication; otherwise,
         * prioritize own publications over others, and prioritize later timestamp.
         */
        filterPubs?: FilterPubsCallback;
        /**
         * Signer of publications.
         * Default is digest signing.
         */
        pubSigner?: Signer;
        /**
         * Verifier of publications.
         * Default is no verification.
         */
        pubVerifier?: Verifier;
    }
    type PublishCallback = (pub: Data, confirmed: boolean) => void;
}
export {};
