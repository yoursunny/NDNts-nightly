import type { SyncpsPubsub } from "./pubsub";
/** Create algorithm parameters to be compatible with PSync C++ library. */
export declare function makeSyncpsCompatParam({ keyToBufferLittleEndian, expectedEntries, }?: makeSyncpsCompatParam.Options): SyncpsPubsub.Parameters;
export declare namespace makeSyncpsCompatParam {
    interface Options {
        /**
         * Whether to use little endian when converting a uint32 key to a byte array.
         * ndn-ind behaves differently on big endian and little endian machines,
         * https://github.com/operantnetworks/ndn-ind/blob/dd934a7a5106cda6ea14675554427e12df1ce18f/src/lite/util/crypto-lite.cpp#L114
         * This must be set to match other peers.
         * @default true
         */
        keyToBufferLittleEndian?: boolean;
        /**
         * Expected number of IBLT entries, i.e. expected number of updates in a sync cycle.
         * @default 85
         */
        expectedEntries?: number;
    }
}
