export declare type IntervalRange = [min: number, max: number];
export declare type IntervalFunc = () => number;
export declare function computeInterval(input: IntervalRange | undefined, syncInterestLifetime: number): IntervalFunc;
