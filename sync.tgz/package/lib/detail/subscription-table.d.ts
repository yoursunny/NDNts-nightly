import type TypedEmitter from "typed-emitter";
import type { Subscription } from "../types";
declare const Sub_base: new () => TypedEmitter<Subscription.Events<any>>;
declare class Sub<Topic, Update> extends Sub_base implements Subscription<Topic, Update> {
    readonly topic: Topic;
    readonly remove: () => void;
    constructor(topic: Topic, remove: () => void);
}
export declare class SubscriptionTable<Topic, Update, Key = unknown, SubscribeInfo = undefined> implements Iterable<[Key, Set<Subscription<Topic, Update>>]> {
    private readonly topic2key;
    constructor(topic2key: (topic: Topic) => Key);
    handleAddTopic?: (topic: Topic, key: Key, set: Set<Subscription<Topic, Update>>, info: SubscribeInfo) => void;
    handleRemoveTopic?: (topic: Topic, key: Key, set: Set<Subscription<Topic, Update>>) => void;
    private readonly table;
    get(key: Key): Set<Subscription<Topic, Update>> | undefined;
    [Symbol.iterator](): IterableIterator<[Key, Set<Sub<Topic, Update>>]>;
    add(topic: Topic, info: SubscribeInfo): Subscription<Topic, Update>;
    private remove;
    update(set: Set<Subscription<Topic, Update>>, update: Update): void;
}
export {};
