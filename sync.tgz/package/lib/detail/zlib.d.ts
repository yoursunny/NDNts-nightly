import pako from "pako";
import type { Compression } from "./iblt-codec";
export declare function makeZlib(level: pako.DeflateFunctionOptions["level"]): Compression;
