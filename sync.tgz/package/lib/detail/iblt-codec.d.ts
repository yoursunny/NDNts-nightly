import { Component } from "@ndn/packet";
import { IBLT } from "../iblt";
export interface Compression {
    compress: (input: Uint8Array) => Uint8Array;
    decompress: (compressed: Uint8Array) => Uint8Array;
}
export declare class IbltCodec {
    readonly ibltCompression: Compression;
    protected readonly ibltParams: IBLT.PreparedParameters;
    iblt2comp(iblt: IBLT): Component;
    comp2iblt(comp: Component): IBLT;
}
