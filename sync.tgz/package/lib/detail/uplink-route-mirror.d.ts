import { Forwarder } from "@ndn/fw";
import { Name } from "@ndn/packet";
/**
 * Helper to automatically add sync group prefix as a route on uplinks.
 *
 * In most synchronization protocols, all participants register the sync group prefix and also send
 * Interests under the same prefix. Due to the FIB longest prefix match logic in `@ndn/fw` package,
 * sync Interests would match the local participant's own route registration, and would not match the
 * `/` default route on uplink faces.
 *
 * This helper automatically registers sync group prefix on current and future uplink faces in a
 * logical forwarder. A face is considered an uplink if it has a `/` route.
 */
export declare class UplinkRouteMirror {
    private readonly fw;
    private readonly prefix;
    constructor(fw: Forwarder, prefix: Name);
    private readonly added;
    close(): void;
    private handlePrefixAdd;
    private handlePrefixRm;
}
