import { Name } from "@ndn/packet";
import type { CommandModule } from "yargs";
import { type CommonArgs } from "./util.js";
interface Args extends CommonArgs {
    name: Name;
    ver: string;
}
export declare const GetSegmentedCommand: CommandModule<CommonArgs, Args>;
export {};
