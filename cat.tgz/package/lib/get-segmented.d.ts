import type { Arguments, Argv, CommandModule } from "yargs";
import { CommonArgs } from "./util";
declare const discoverVersionChoices: {
    none: boolean;
    cbp: boolean;
    rdr: boolean;
};
declare type DiscoverVersionChoice = keyof typeof discoverVersionChoices;
interface Args extends CommonArgs {
    name: string;
    ver: DiscoverVersionChoice;
}
export declare class GetSegmentedCommand implements CommandModule<CommonArgs, Args> {
    command: string;
    describe: string;
    aliases: string[];
    builder(argv: Argv<CommonArgs>): Argv<Args>;
    handler(args: Arguments<Args>): void;
}
export {};
