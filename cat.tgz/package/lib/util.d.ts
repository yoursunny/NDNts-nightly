import { NamingConvention, Signer } from "@ndn/packet";
export interface CommonArgs {
    convention1: boolean;
}
export declare let versionConvention: NamingConvention<number>;
export declare let segmentNumConvention: NamingConvention<number>;
export declare let signer: Signer;
export declare function applyCommonArgs(args: CommonArgs): Promise<void>;
