import type { NamingConvention, Signer } from "@ndn/packet";
export interface CommonArgs {
    convention: number;
}
export declare let Version: NamingConvention<number>;
export declare let Segment: NamingConvention<number>;
export declare let signer: Signer;
export declare function applyCommonArgs(args: CommonArgs): Promise<void>;
export declare function checkVersionArg(keywords: readonly string[]): (args: {
    ver: string;
}) => boolean;
