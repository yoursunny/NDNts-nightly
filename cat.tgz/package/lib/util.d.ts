import type { Signer } from "@ndn/packet";
export type CommonArgs = {};
export declare let signer: Signer;
export declare function applyCommonArgs(_: CommonArgs): Promise<void>;
export declare function checkVersionArg(keywords: readonly string[]): (args: {
    ver: string;
}) => boolean;
