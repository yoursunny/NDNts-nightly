import type { Arguments, Argv, CommandModule } from "yargs";
import { CommonArgs } from "./util";
interface Args extends CommonArgs {
    name: string;
    rdr: boolean;
    ver: string;
    file?: string;
    "chunk-size": number;
}
export declare class PutSegmentedCommand implements CommandModule<CommonArgs, Args> {
    command: string;
    describe: string;
    aliases: string[];
    builder(argv: Argv<CommonArgs>): Argv<Args>;
    handler(args: Arguments<Args>): void;
}
export {};
