import { Name } from "@ndn/packet";
import type { CommandModule } from "yargs";
import { type CommonArgs } from "./util.js";
interface Args extends CommonArgs {
    name: Name;
    rdr: boolean;
    ver: string;
    file?: string;
    "chunk-size": number;
}
export declare const PutSegmentedCommand: CommandModule<CommonArgs, Args>;
export {};
