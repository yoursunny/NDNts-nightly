export declare const COMMAND = "ndncat";
