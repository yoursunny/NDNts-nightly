import { Name } from "@ndn/packet";
import type { CommandModule } from "yargs";
import { type CommonArgs } from "./util.js";
interface Args extends CommonArgs {
    remote: Name;
    local: string;
    jobs: number;
    retx: number;
}
export declare const FileClientCommand: CommandModule<CommonArgs, Args>;
export {};
