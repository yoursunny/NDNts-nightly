import type { Decoder } from "./decoder";
/** Invoked when a matching TLV element is found. */
declare type ElementCallback<T> = (target: T, tlv: Decoder.Tlv) => void;
interface Rule<T> {
    cb: ElementCallback<T>;
    /**
     * Expected order of appearance.
     * Default to the order in which rules were added to EvDecoder.
     */
    order: number;
    /** Whether TLV element must appear at least once. */
    required: boolean;
    /** Whether TLV element may appear more than once. */
    repeat: boolean;
}
declare type RuleOptions<T> = Partial<Omit<Rule<T>, "cb">>;
/**
 * Invoked when a TLV element does not match any rule.
 * 'order' denotes the order number of last recognized TLV element.
 * Return true if this TLV element is accepted, or false to follow evolvability guidelines.
 */
declare type UnknownElementCallback<T> = (target: T, tlv: Decoder.Tlv, order: number) => boolean;
declare type IsCriticalCallback = (tt: number) => boolean;
declare type TopElementCallback<T> = (target: T, tlv: Decoder.Tlv) => void;
declare type TargetCallback<T> = (target: T) => void;
/** TLV-VALUE decoder that understands Packet Format v0.3 evolvability guidelines. */
export declare class EvDecoder<T> {
    private readonly typeName;
    private readonly topTT;
    private readonly rules;
    private readonly requiredTlvTypes;
    private nextOrder;
    private isCriticalCb;
    private unknownCb;
    /** Callbacks to receive top-level TLV before decoding TLV-VALUE. */
    readonly beforeTopCallbacks: TopElementCallback<T>[];
    /** Callbacks before decoding TLV-VALUE. */
    readonly beforeValueCallbacks: TargetCallback<T>[];
    /** Callbacks after decoding TLV-VALUE. */
    readonly afterValueCallbacks: TargetCallback<T>[];
    /** Callbacks to receive top-level TLV after decoding TLV-VALUE. */
    readonly afterTopCallbacks: TopElementCallback<T>[];
    /**
     * Constructor.
     * @param typeName type name, used in error messages.
     * @param topTT if specified, check top-level TLV-TYPE to be in this list.
     */
    constructor(typeName: string, topTT?: number | readonly number[]);
    /**
     * Add a decoding rule.
     * @param tt TLV-TYPE to match this rule.
     * @param cb callback to handle element TLV.
     * @param options additional rule options.
     */
    add(tt: number, cb: ElementCallback<T> | EvDecoder<T>, options?: RuleOptions<T>): this;
    /** Set callback to determine whether TLV-TYPE is critical. */
    setIsCritical(cb: IsCriticalCallback): this;
    /** Set callback to handle unknown elements. */
    setUnknown(cb: UnknownElementCallback<T>): this;
    /** Decode TLV to target object. */
    decode<R extends T = T>(target: R, decoder: Decoder): R;
    /** Decode TLV-VALUE to target object. */
    decodeValue<R extends T = T>(target: R, vd: Decoder): R;
    private handleUnrecognized;
}
export {};
