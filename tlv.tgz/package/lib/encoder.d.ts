/**
 * An object that knows how to prepend itself to an Encoder.
 */
export interface EncodableObj {
    encodeTo: (encoder: Encoder) => void;
}
/**
 * An encodable TLV structure.
 *
 * First item is a number for TLV-TYPE.
 * Optional second item could be OmitEmpty to omit the TLV if TLV-VALUE is empty.
 * Subsequent items are Encodables for TLV-VALUE.
 */
export declare type EncodableTlv = [number, ...any[]];
/**
 * An object acceptable to Encoder.encode().
 */
export declare type Encodable = Uint8Array | undefined | EncodableObj | EncodableTlv;
/** TLV encoder that accepts objects in reverse order. */
export declare class Encoder {
    private buf;
    private off;
    /** Return encoding output size. */
    get size(): number;
    /** Obtain encoding output. */
    get output(): Uint8Array;
    constructor(initSize?: number);
    /** Obtain part of encoding output. */
    slice(start?: number, length?: number): Uint8Array;
    /**
     * Make room to prepend an object.
     * @param sizeofObject object size.
     * @returns room to write object.
     */
    prependRoom(sizeofObject: number): Uint8Array;
    /** Prepend TLV-TYPE and TLV-LENGTH. */
    prependTypeLength(tlvType: number, tlvLength: number): void;
    /** Prepend TLV-VALUE. */
    prependValue(...tlvValue: Encodable[]): void;
    /**
     * Prepend TLV structure.
     * @param tlvType TLV-TYPE number.
     * @param omitEmpty omit TLV altogether if set to Encoder.OmitEmpty
     * @param tlvValue TLV-VALUE objects.
     */
    prependTlv(tlvType: number, omitEmpty?: typeof Encoder.OmitEmpty | Encodable, ...tlvValue: Encodable[]): void;
    /** Prepend an Encodable object. */
    encode(obj: Encodable | readonly Encodable[]): void;
    private grow;
}
export declare namespace Encoder {
    function asDataView(a: Uint8Array): DataView;
    const OmitEmpty: unique symbol;
    function encode(obj: Encodable | readonly Encodable[], initBufSize?: number): Uint8Array;
    /** Extract the encoding output of an element while writing to a larger encoder. */
    function extract(obj: Encodable | readonly Encodable[], cb: (output: Uint8Array) => void): Encodable;
}
