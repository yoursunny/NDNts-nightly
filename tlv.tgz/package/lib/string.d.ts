/** Pretty-print TLV-TYPE number. */
export declare function printTT(tlvType: number): string;
/** Convert byte array to upper-case hexadecimal string. */
export declare function toHex(buf: Uint8Array): string;
/**
 * Convert hexadecimal string to byte array.
 *
 * This function lacks error handling. Use on trusted input only.
 */
export declare function fromHex(s: string): Uint8Array;
export declare function toUtf8(s: string): Uint8Array;
export declare function fromUtf8(buf: Uint8Array): string;
