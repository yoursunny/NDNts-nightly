import type { Encodable, Encoder } from "./encoder.js";
import type { EvDecoder } from "./ev-decoder.js";
import type { StructFieldType } from "./struct-field.js";
export interface Field<T> extends Required<EvDecoder.RuleOptions> {
    readonly tt: number;
    readonly key: string;
    newValue: () => T;
    encode: (v: T) => Iterable<Encodable | typeof Encoder.OmitEmpty>;
    asString: (v: T) => Iterable<string>;
}
export declare function makeField<T>(tt: number, key: string, type: StructFieldType<T>, opts: EvDecoder.RuleOptions, evd: EvDecoder<any>): Field<T[]> | Field<T | undefined>;
export declare function sortFields(fields: Array<Field<any>>): void;
export declare function encodeFields(fields: ReadonlyArray<Field<any>>, obj: Record<string, any>): Encodable[];
