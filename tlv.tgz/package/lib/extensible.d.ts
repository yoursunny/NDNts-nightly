import type { Encodable } from "./encoder.js";
import { EvDecoder } from "./ev-decoder.js";
import type { StructFieldType } from "./struct-field.js";
/** An TLV element that allows extension sub element. */
export interface Extensible {
    readonly [Extensible.TAG]: ExtensionRegistry<any>;
}
export declare namespace Extensible {
    const TAG: unique symbol;
    /** Clone extension fields of src to dst. */
    function cloneRecord(dst: Extensible, src: Extensible): void;
    /**
     * Define simple getters and setters.
     * @param typ - Extensible subclass constructor.
     * @param exts - Extensions, each key is a property name and each value is the TLV-TYPE number.
     */
    function defineGettersSetters<T extends Extensible>(typ: new () => T, exts: Record<string, number>): void;
}
export declare namespace Extension {
    /** Retrieve value of an extension field. */
    function get(obj: Extensible, tt: number): unknown;
    /** Assign value of an extension field. */
    function set(obj: Extensible, tt: number, value: unknown): void;
    /** Clear value of an extension field. */
    function clear(obj: Extensible, tt: number): void;
}
export interface ExtensionOptions {
    order?: number;
}
/** Registry of known extension fields of a parent TLV element. */
export declare class ExtensionRegistry<T extends Extensible> {
    private hasUnrecognized;
    private readonly evd;
    private readonly fields;
    /** Add an extension. */
    readonly register: <R>(tt: number, type: StructFieldType<R>, opts?: ExtensionOptions) => void;
    /** UnknownElementCallback for EvDecoder. */
    readonly decodeUnknown: EvDecoder.UnknownElementHandler<T>;
    /** Encode extension fields. */
    encode(source: T): Encodable[];
}
