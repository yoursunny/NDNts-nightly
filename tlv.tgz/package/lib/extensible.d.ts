import type { Decoder } from "./decoder";
import type { Encodable } from "./encoder";
/** An TLV element that allows extension sub element. */
export interface Extensible {
    [Extensible.TAG]: Extensible.Records;
}
export declare namespace Extensible {
    const TAG: unique symbol;
    type Records = Map<number, unknown>;
    function newRecords(): Map<number, unknown>;
}
/**
 * An extension sub element on a parent TLV element.
 * T is the parent TLV element type.
 * R is the value type of this extension.
 */
export interface Extension<T, R = unknown> {
    /** TLV-TYPE. */
    readonly tt: number;
    /** Order relative to other extensions, used on encoding only. */
    readonly order?: number;
    /**
     * Decode extension element.
     * @param obj parent object.
     * @param tlv TLV of sub element; its TLV-TYPE would be this.tt .
     * @param accumulator previous decoded value, if extension element appears more than once.
     */
    decode: (obj: T, tlv: Decoder.Tlv, accumulator?: R) => R;
    /**
     * Encode extension element.
     * @param obj parent object.
     * @param value decoded value.
     * @returns encoding of sub element; its TLV-TYPE should be this.tt .
     */
    encode: (obj: T, value: R) => Encodable;
}
export declare namespace Extension {
    function get(obj: Extensible, tt: number): unknown;
    function set(obj: Extensible, tt: number, value: unknown): void;
    function clear(obj: Extensible, tt: number): void;
}
export declare class ExtensionRegistry<T extends Extensible> {
    private table;
    registerExtension: <R>(ext: Extension<T, R>) => void;
    unregisterExtension: (tt: number) => void;
    decodeUnknown: (target: T, tlv: Decoder.Tlv, order: number) => boolean;
    encode(source: T): Encodable[];
}
