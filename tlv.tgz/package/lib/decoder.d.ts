/**
 * An object that knows how to decode itself from TLV.
 * @typeParam R - Result type.
 *
 * @remarks
 * Most commonly, `decodeFrom` is added as a static method of type R, so that the constructor
 * of R implements this interface.
 */
export interface Decodable<R> {
    decodeFrom: (decoder: Decoder) => R;
}
/** TLV decoder. */
export declare class Decoder {
    private readonly input;
    constructor(input: Uint8Array);
    private readonly dv;
    private offset;
    /** Determine whether end of input has been reached. */
    get eof(): boolean;
    /**
     * Ensure EOF has been reached.
     *
     * @throws Error
     * Thrown if EOF has not been reached.
     */
    throwUnlessEof(): void;
    /**
     * Read the next TLV structure from input.
     * @returns TLV structure.
     *
     * @throws Error
     * Thrown if there isn't a complete TLV structure in the input.
     */
    read(): Decoder.Tlv;
    /** Read a Decodable object. */
    decode<R>(d: Decodable<R>): R;
    /**
     * Read a variable-size number.
     * @returns The number up to uint32 or `undefined` if there isn't a complete number.
     */
    private readVarNum;
}
export declare namespace Decoder {
    /** Decoded TLV. */
    interface Tlv {
        /** TLV-TYPE. */
        readonly type: number;
        /** TLV-LENGTH. */
        readonly length: number;
        /** TLV-VALUE. */
        readonly value: Uint8Array;
        /** TLV buffer. */
        readonly tlv: Uint8Array;
        /** Size of TLV. */
        readonly size: number;
        /** TLV as decoder. */
        readonly decoder: Decoder;
        /** TLV-VALUE as decoder. */
        readonly vd: Decoder;
        /** TLV-VALUE as non-negative integer. */
        readonly nni: number;
        /** TLV-VALUE as non-negative integer bigint. */
        readonly nniBig: bigint;
        /** TLV-VALUE as UTF-8 string. */
        readonly text: string;
        /** Siblings before this TLV. */
        readonly before: Uint8Array;
        /** Siblings after this TLV. */
        readonly after: Uint8Array;
    }
    /**
     * Decode a single object from Uint8Array.
     * @param input - Input buffer, which should contain the encoded object and nothing else.
     * @param d - Decodable object type.
     * @returns Decoded object.
     *
     * @throws Error
     * Thrown if the input cannot be decoded as the specified object type, or there's junk leftover.
     */
    function decode<R>(input: Uint8Array, d: Decodable<R>): R;
}
