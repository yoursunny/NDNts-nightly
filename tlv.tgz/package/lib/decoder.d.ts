export interface Decodable<R> {
    decodeFrom: (decoder: Decoder) => R;
}
/** TLV decoder. */
export declare class Decoder {
    private input;
    /** Determine whether end of input has been reached. */
    get eof(): boolean;
    private offset;
    constructor(input: Uint8Array);
    /** Read TLV structure. */
    read(): Decoder.Tlv;
    /** Read a Decodable object. */
    decode<R>(d: Decodable<R>): R;
    private readVarNum;
    private readType;
    private readLength;
    private skipValue;
}
export declare namespace Decoder {
    /** Types acceptable to Decoder.from(). */
    type Input = Decoder | Uint8Array;
    /** Test whether obj is Decoder.Input. */
    function isInput(obj: unknown): obj is Input;
    /** Construct from Decoder.Input, or return existing Decoder. */
    function from(obj: Input): Decoder;
    /** Decoded TLV. */
    interface Tlv {
        /** TLV-TYPE */
        readonly type: number;
        /** TLV-LENGTH */
        readonly length: number;
        /** TLV-VALUE */
        readonly value: Uint8Array;
        /** TLV buffer */
        readonly tlv: Uint8Array;
        /** sizeof tlv */
        readonly size: number;
        /** TLV as decoder */
        readonly decoder: Decoder;
        /** TLV-VALUE as decoder */
        readonly vd: Decoder;
        /** TLV-VALUE as non-negative integer */
        readonly nni: number;
        /** TLV-VALUE as UTF-8 string */
        readonly text: string;
        /** siblings before this TLV */
        readonly before: Uint8Array;
        /** siblings after this TLV */
        readonly after: Uint8Array;
    }
}
