import { Encodable, Encoder } from "./encoder";
declare class Nni1 {
    private readonly n;
    constructor(n: number);
    encodeTo(encoder: Encoder): void;
}
declare class Nni2 {
    private readonly n;
    constructor(n: number);
    encodeTo(encoder: Encoder): void;
}
declare class Nni4 {
    private readonly n;
    constructor(n: number);
    encodeTo(encoder: Encoder): void;
}
declare class Nni8Number {
    private readonly n;
    constructor(n: number);
    encodeTo(encoder: Encoder): void;
}
declare type Len = 1 | 2 | 4 | 8;
interface Options<LenT = Len> {
    /** If set, use/enforce specific TLV-LENGTH. */
    len?: LenT;
    /** If true, allow approximate integers. */
    unsafe?: boolean;
}
declare const EncodeNniClass: {
    1: typeof Nni1;
    2: typeof Nni2;
    4: typeof Nni4;
    8: typeof Nni8Number;
};
/** Create Encodable from non-negative integer. */
export declare function NNI(n: number | bigint, { len, unsafe, }?: Options<Extract<Len, keyof typeof EncodeNniClass>>): Encodable;
export declare namespace NNI {
    /** Determine if len is a valid length of encoded NNI. */
    function isValidLength(len: number): boolean;
    /** Decode non-negative integer as number. */
    function decode(value: Uint8Array, opts?: Options & {
        big?: false;
    }): number;
    /** Decode non-negative integer as bigint. */
    function decode(value: Uint8Array, opts: Options & {
        big: true;
    }): bigint;
    /** Error if n exceeds [0,MAX_SAFE_INTEGER] range. */
    function constrain(n: number, typeName: string): number;
    /** Error if n exceeds [0,max] range. */
    function constrain(n: number, typeName: string, max: number): number;
    /** Error if n exceeds [min,max] range. */
    function constrain(n: number, typeName: string, min: number, max?: number): number;
}
export {};
