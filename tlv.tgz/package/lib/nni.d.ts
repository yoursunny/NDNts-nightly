import type { Encodable } from "./encoder.js";
type Len = 1 | 2 | 4 | 8;
/**
 * Create Encodable from non-negative integer.
 *
 * @throws RangeError
 * Thrown if the number may lose precision and `unsafe` option is not set.
 */
export declare function NNI(n: number | bigint, { len, unsafe, }?: NNI.Options): Encodable;
export declare namespace NNI {
    interface Options {
        /**
         * Encode to specific length.
         * Enforce specific length during decoding.
         */
        len?: Len;
        /**
         * Decode to bigint instead of number.
         * @defaultValue `false`
         */
        big?: boolean;
        /**
         * Permit large numbers that exceed MAX_SAFE_INTEGER, which may lose precision.
         * @defaultValue `false`
         */
        unsafe?: boolean;
    }
    /** Determine if len is a valid length of encoded NNI. */
    function isValidLength(len: number): boolean;
    /** Decode non-negative integer as number. */
    function decode(value: Uint8Array, opts?: Options & {
        big?: false;
    }): number;
    /** Decode non-negative integer as bigint. */
    function decode(value: Uint8Array, opts: Options & {
        big: true;
    }): bigint;
}
export {};
