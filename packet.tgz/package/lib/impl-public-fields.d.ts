export declare const FIELDS: unique symbol;
export declare function definePublicFields<Target extends PublicFields & {
    [FIELDS]: Fields;
}, Fields extends PublicFields, PublicFields extends {}>(typ: new () => Target, fieldDefs: Record<keyof PublicFields, ReadonlyArray<keyof Fields>>): void;
