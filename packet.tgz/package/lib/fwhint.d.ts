import { type Decoder, Encoder } from "@ndn/tlv";
import { Name, type NameLike } from "./name/mod.js";
/** ForwardingHint in Interest. */
export declare class FwHint {
    static decodeValue(vd: Decoder): FwHint;
    constructor(copy?: FwHint);
    constructor(name: NameLike);
    constructor(delegations: readonly NameLike[]);
    delegations: Name[];
    encodeTo(encoder: Encoder): void;
}
