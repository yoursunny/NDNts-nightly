import { Decoder, Encoder } from "@ndn/tlv";
import { Name, NameLike } from "./name/mod";
/** ForwardingHint in Interest. */
export declare class FwHint {
    static decodeValue(value: Uint8Array): FwHint;
    constructor(copy?: FwHint);
    constructor(delegations: readonly FwHint.Delegation[]);
    get delegations(): readonly FwHint.Delegation[];
    private readonly m;
    encodeTo(encoder: Encoder): void;
}
export declare namespace FwHint {
    /** Delegation in ForwardingHint. */
    class Delegation {
        preference: number;
        static decodeFrom(decoder: Decoder): Delegation;
        constructor(name?: NameLike, preference?: number);
        name: Name;
        encodeTo(encoder: Encoder): void;
    }
}
