import { type Decoder, Encoder } from "@ndn/tlv";
import type { Arrayable } from "type-fest";
import { Name, type NameLike } from "./name/mod.js";
/** ForwardingHint in Interest. */
export declare class FwHint {
    static decodeValue(vd: Decoder): FwHint;
    constructor(copy?: FwHint);
    constructor(delegations: Arrayable<NameLike>);
    delegations: Name[];
    encodeTo(encoder: Encoder): void;
}
