import { type Decoder, type Encoder } from "@ndn/tlv";
import type { SigInfo } from "./sig-info.js";
/** Certificate validity period. */
export declare class ValidityPeriod {
    static decodeFrom(decoder: Decoder): ValidityPeriod;
    constructor();
    constructor(notBefore: ValidityPeriod.TimestampInput, notAfter: ValidityPeriod.TimestampInput);
    notBefore: number;
    notAfter: number;
    encodeTo(encoder: Encoder): void;
    /** Determine whether the specified timestamp is within validity period. */
    includes(t: ValidityPeriod.TimestampInput): boolean;
    /** Determine whether this validity period equals another. */
    equals({ notBefore, notAfter }: ValidityPeriod): boolean;
    /** Compute the intersection of this and other validity periods. */
    intersect(...validityPeriods: ValidityPeriod[]): ValidityPeriod;
    toString(): string;
}
export declare namespace ValidityPeriod {
    type TimestampInput = number | Date;
    /** A very long ValidityPeriod. */
    const MAX: ValidityPeriod;
    /** Construct ValidityPeriod for n days from now. */
    function daysFromNow(n: number): ValidityPeriod;
    /**
     * Retrieve ValidityPeriod from SigInfo.
     * @deprecated Retrieve from `si.validity` directly.
     */
    function get(si: SigInfo): ValidityPeriod | undefined;
    /**
     * Assign ValidityPeriod onto SigInfo.
     * @deprecated Assign to `si.validity` directly.
     */
    function set(si: SigInfo, v?: ValidityPeriod): void;
}
