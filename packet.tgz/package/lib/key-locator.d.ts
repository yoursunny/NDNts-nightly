import { Decoder, Encoder } from "@ndn/tlv";
import { Name, NameLike } from "./name/mod";
/** KeyLocator in SigInfo. */
export declare class KeyLocator {
    static decodeFrom(decoder: Decoder): KeyLocator;
    name?: Name;
    digest?: Uint8Array;
    constructor(...args: KeyLocator.CtorArg[]);
    encodeTo(encoder: Encoder): void;
}
export declare namespace KeyLocator {
    type CtorArg = KeyLocator | NameLike | Uint8Array;
    function isCtorArg(arg: unknown): arg is CtorArg;
    /** Throw if KeyLocator is missing or does not have Name. */
    function mustGetName(kl?: KeyLocator): Name;
}
