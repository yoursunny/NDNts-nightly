import { type Decoder, type EncodableObj, Extensible, ExtensionRegistry } from "@ndn/tlv";
import { KeyLocator } from "./key-locator.js";
import { ValidityPeriod } from "./validity-period.js";
/** SignatureInfo on Interest or Data. */
export declare class SigInfo {
    static decodeFrom(decoder: Decoder): SigInfo;
    /**
     * Construct from flexible arguments.
     *
     * Arguments can include, in any order:
     * - {@link SigInfo} to copy from
     * - number as SigType
     * - {@link KeyLocator}, or Name/URI/KeyDigest to construct KeyLocator
     * - {@link SigInfo.Nonce}`(v)`
     * - {@link SigInfo.Time}`(v)`
     * - {@link SigInfo.SeqNum}`(v)`
     * - {@link ValidityPeriod}
     */
    constructor(...args: SigInfo.CtorArg[]);
    type: number;
    keyLocator?: KeyLocator;
    nonce?: Uint8Array;
    time?: number;
    seqNum?: bigint;
    validity?: ValidityPeriod;
    readonly [Extensible.TAG]: ExtensionRegistry<SigInfo>;
    /**
     * Create an Encodable.
     * @param tt - Either `TT.ISigInfo` or `TT.DSigInfo`.
     */
    encodeAs(tt: number): EncodableObj;
    private encodeTo;
}
declare const ctorAssign: unique symbol;
interface CtorTag {
    [ctorAssign]: (si: SigInfo) => void;
}
export declare namespace SigInfo {
    /** Constructor argument to set SigNonce field. */
    function Nonce(v?: Uint8Array | number): CtorTag;
    /** Generate a random nonce. */
    function generateNonce(size?: number): Uint8Array;
    /** Constructor argument to set SigTime field. */
    function Time(v?: number): CtorTag;
    /** Constructor argument to set SigSeqNum field. */
    function SeqNum(v: bigint): CtorTag;
    /** Constructor argument. */
    type CtorArg = SigInfo | number | KeyLocator.CtorArg | CtorTag | ValidityPeriod;
}
export {};
