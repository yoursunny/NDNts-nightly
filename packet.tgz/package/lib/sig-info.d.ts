import { Decoder, EncodableObj, Extensible } from "@ndn/tlv";
import { KeyLocator } from "./key-locator";
/** SignatureInfo on Interest or Data. */
export declare class SigInfo {
    static decodeFrom(decoder: Decoder): SigInfo;
    type: number;
    keyLocator?: KeyLocator;
    nonce?: Uint8Array;
    time?: number;
    seqNum?: number;
    [Extensible.TAG]: Map<number, unknown>;
    /**
     * Construct from flexible arguments.
     *
     * Arguments can include, in any order:
     * - SigInfo to copy from
     * - number as SigType
     * - KeyLocator, or Name/URI/KeyDigest to construct KeyLocator
     * - SigInfo.Nonce(v)
     * - SigInfo.Time(v)
     * - SigInfo.SeqNum(v)
     */
    constructor(...args: SigInfo.CtorArg[]);
    /**
     * Create an Encodable.
     * @param tt either TT.ISigInfo or TT.DSigInfo.
     */
    encodeAs(tt: number): EncodableObj;
    private encodeTo;
}
declare const ctorAssign: unique symbol;
interface CtorTag {
    [ctorAssign]: (si: SigInfo) => void;
}
export declare namespace SigInfo {
    function Nonce(v?: Uint8Array | number): CtorTag;
    /** Generate a random nonce. */
    function generateNonce(size?: number): Uint8Array;
    function Time(v?: number): CtorTag;
    function SeqNum(v: number): {
        [ctorAssign](si: SigInfo): void;
    };
    type CtorArg = SigInfo | number | KeyLocator.CtorArg | CtorTag;
    const registerExtension: <R>(ext: import("@ndn/tlv").Extension<SigInfo, R>) => void;
    const unregisterExtension: (tt: number) => void;
}
export {};
