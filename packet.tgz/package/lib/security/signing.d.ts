import { KeyLocator } from "../key-locator";
import type { Name } from "../name/mod";
import { SigInfo } from "../sig-info";
import { timingSafeEqual as timingSafeEqual_ } from "./helper_node";
/**
 * Low level signing function.
 * It takes a buffer of signed portion, and returns a Promise of signature value.
 */
export declare type LLSign = (input: Uint8Array) => Promise<Uint8Array>;
export declare namespace LLSign {
    const OP: unique symbol;
    interface Signable {
        [OP]: (signer: LLSign) => Promise<void>;
    }
}
/**
 * Low level verification function.
 * It takes a buffer of signed portion and the signature value, and returns a Promise
 * that is resolved upon good signature or rejected upon bad signature.
 */
export declare type LLVerify = (input: Uint8Array, sig: Uint8Array) => Promise<void>;
export declare namespace LLVerify {
    const OP: unique symbol;
    interface Verifiable {
        [OP]: (verifier: LLVerify) => Promise<void>;
    }
    const timingSafeEqual: typeof timingSafeEqual_;
}
interface PacketWithSignature {
    readonly name: Name;
    sigInfo?: SigInfo;
    sigValue: Uint8Array;
}
/** High level signer, such as a private key. */
export interface Signer {
    /** Sign a packet. */
    sign: (pkt: Signer.Signable) => Promise<void>;
}
export declare namespace Signer {
    interface Signable extends PacketWithSignature, LLSign.Signable {
    }
    /**
     * Put SigInfo on packet if it does not exist.
     * @param pkt target packet.
     * @param sigType optionally set sigType.
     * @param keyLocator optionally set keyLocator; false to unset KeyLocator.
     */
    function putSigInfo(pkt: PacketWithSignature, sigType?: number, keyLocator?: KeyLocator.CtorArg | false): SigInfo;
}
/** High level verifier, such as a public key. */
export interface Verifier {
    /**
     * Verify a packet.
     * @returns a Promise is resolved upon good signature/policy or rejected upon bad signature/policy.
     */
    verify: (pkt: Verifier.Verifiable) => Promise<void>;
}
export declare namespace Verifier {
    interface Verifiable extends Readonly<PacketWithSignature>, LLVerify.Verifiable {
    }
    /** Throw if packet does not have expected SigType. */
    function checkSigType(pkt: Readonly<PacketWithSignature>, expectedSigType: number): void;
    /** Throw bad signature error if not OK. */
    function throwOnBadSig(ok: boolean): asserts ok;
}
/** Signer and Verifier that do nothing. */
export declare const noopSigning: Signer & Verifier;
/** Signer and Verifier for SigType.Sha256 digest. */
export declare const digestSigning: Signer & Verifier;
/**
 * Signer for SigType.Null, a packet that is not signed.
 * @see https://redmine.named-data.net/projects/ndn-tlv/wiki/NullSignature
 */
export declare const nullSigner: Signer;
export {};
