export declare function randBytes(size: number): Uint8Array;
export declare function sha256(input: Uint8Array): Promise<Uint8Array>;
export declare function timingSafeEqual(a: Uint8Array, b: Uint8Array): boolean;
