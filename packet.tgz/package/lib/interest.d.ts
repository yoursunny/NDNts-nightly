import { Decoder, Encoder } from "@ndn/tlv";
import { FwHint } from "./fwhint";
import { Name, NameLike } from "./name/mod";
import { LLSign, LLVerify, Signer, Verifier } from "./security/signing";
import { SigInfo } from "./sig-info";
declare const FIELDS: unique symbol;
declare class Fields {
    constructor(...args: Array<Interest | Interest.CtorArg>);
    name: Name;
    canBePrefix: boolean;
    mustBeFresh: boolean;
    fwHint?: FwHint;
    get nonce(): number | undefined;
    set nonce(v: number | undefined);
    get lifetime(): number;
    set lifetime(v: number);
    get hopLimit(): number;
    set hopLimit(v: number);
    appParameters?: Uint8Array;
    sigInfo?: SigInfo;
    sigValue: Uint8Array;
    private nonce_;
    private lifetime_;
    private hopLimit_;
    signedPortion?: Uint8Array;
    paramsPortion?: Uint8Array;
}
/** Interest packet. */
export declare class Interest implements LLSign.Signable, LLVerify.Verifiable, Signer.Signable, Verifier.Verifiable {
    /**
     * Construct from flexible arguments.
     *
     * Arguments can include, in any order:
     * - Interest to copy from
     * - Name or name URI
     * - Interest.CanBePrefix
     * - Interest.MustBeFresh
     * - Interest.Nonce(v)
     * - Interest.Lifetime(v)
     * - Interest.HopLimit(v)
     * - Uint8Array as AppParameters
     */
    constructor(...args: Array<Interest | Interest.CtorArg>);
    readonly [FIELDS]: Fields;
    static decodeFrom(decoder: Decoder): Interest;
    encodeTo(encoder: Encoder): void;
    private encodeParamsPortion;
    private appendParamsDigestPlaceholder;
    updateParamsDigest(): Promise<void>;
    validateParamsDigest(): Promise<void>;
    [LLSign.OP](sign: LLSign): Promise<void>;
    [LLVerify.OP](verify: LLVerify): Promise<void>;
}
export interface Interest extends Fields {
}
declare const ctorAssign: unique symbol;
interface CtorTag {
    [ctorAssign]: (f: Fields) => void;
}
export declare namespace Interest {
    /** Signer that calculates ParamsDigest. */
    const Parameterize: LLSign;
    /** Generate a random nonce. */
    function generateNonce(): number;
    /** Default InterestLifetime. */
    const DefaultLifetime = 4000;
    /** Constructor argument to set CanBePrefix flag. */
    const CanBePrefix: unique symbol;
    /** Constructor argument to set MustBeFresh flag. */
    const MustBeFresh: unique symbol;
    /** Constructor argument to set Nonce field. */
    function Nonce(v?: number): CtorTag;
    /** Constructor argument to set InterestLifetime field. */
    function Lifetime(v: number): CtorTag;
    /** Constructor argument to set HopLimit field. */
    function HopLimit(v: number): CtorTag;
    /** Constructor argument. */
    type CtorArg = NameLike | typeof CanBePrefix | typeof MustBeFresh | FwHint | CtorTag | Uint8Array;
    /** A function to modify an existing Interest. */
    type ModifyFunc = (interest: Interest) => void;
    /** Common fields to assign onto an existing Interest. */
    interface ModifyFields {
        canBePrefix?: boolean;
        mustBeFresh?: boolean;
        fwHint?: FwHint;
        lifetime?: number;
        hopLimit?: number;
    }
    /** A structure to modify an existing Interest. */
    type Modify = ModifyFunc | ModifyFields;
    /** Turn ModifyFields to ModifyFunc; return ModifyFunc as-is. */
    function makeModifyFunc(input?: Modify): ModifyFunc;
}
export {};
