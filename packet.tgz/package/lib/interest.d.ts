import { type Decoder, Encoder } from "@ndn/tlv";
import type { ArrayValues, Except } from "type-fest";
import { FwHint } from "./fwhint.js";
import { FIELDS } from "./impl-public-fields.js";
import { Name, type NameLike } from "./name/mod.js";
import { LLSign, LLVerify, type Signer, type Verifier } from "./security/signing.js";
import { SigInfo } from "./sig-info.js";
declare class Fields {
    constructor(...args: Array<Interest | Interest.CtorArg>);
    name: Name;
    canBePrefix: boolean;
    mustBeFresh: boolean;
    fwHint?: FwHint;
    get nonce(): number | undefined;
    set nonce(v: number | undefined);
    private nonce_;
    get lifetime(): number;
    set lifetime(v: number);
    private lifetime_;
    get hopLimit(): number;
    set hopLimit(v: number);
    private hopLimit_;
    appParameters?: Uint8Array;
    sigInfo?: SigInfo;
    sigValue: Uint8Array;
    paramsPortion?: Uint8Array;
    signedPortion?: Uint8Array;
}
interface PublicFields extends Except<Fields, "paramsPortion" | "signedPortion"> {
}
/** Interest packet. */
export declare class Interest implements LLSign.Signable, LLVerify.Verifiable, Signer.Signable, Verifier.Verifiable {
    /**
     * Construct from flexible arguments.
     *
     * Arguments can include, in any order:
     * - {@link Interest} to copy from
     * - {@link Name} or name URI
     * - {@link Interest.CanBePrefix}
     * - {@link Interest.MustBeFresh}
     * - {@link FwHint}
     * - {@link Interest.Nonce}`(v)`
     * - {@link Interest.Lifetime}`(v)`
     * - {@link Interest.HopLimit}`(v)`
     * - `Uint8Array` as AppParameters
     */
    constructor(...args: Array<Interest | Interest.CtorArg>);
    readonly [FIELDS]: Fields;
    static decodeFrom(decoder: Decoder): Interest;
    encodeTo(encoder: Encoder): void;
    private encodeParamsPortion;
    private appendParamsDigestPlaceholder;
    updateParamsDigest(): Promise<void>;
    validateParamsDigest(requireAppParameters?: boolean): Promise<void>;
    [LLSign.OP](sign: LLSign): Promise<void>;
    [LLVerify.OP](verify: LLVerify): Promise<void>;
}
export interface Interest extends PublicFields {
}
declare const ctorAssign: unique symbol;
interface CtorTag {
    [ctorAssign]: (f: Fields) => void;
}
declare const modifyFields: readonly ["canBePrefix", "mustBeFresh", "fwHint", "lifetime", "hopLimit"];
export declare namespace Interest {
    /** Generate a random nonce. */
    function generateNonce(): number;
    /** Default InterestLifetime. */
    const DefaultLifetime = 4000;
    /** Constructor argument to set CanBePrefix flag. */
    const CanBePrefix: CtorTag;
    /** Constructor argument to set MustBeFresh flag. */
    const MustBeFresh: CtorTag;
    /** Constructor argument to set Nonce field. */
    function Nonce(v?: number): CtorTag;
    /** Constructor argument to set InterestLifetime field. */
    function Lifetime(v: number): CtorTag;
    /** Constructor argument to set HopLimit field. */
    function HopLimit(v: number): CtorTag;
    /** Constructor argument. */
    type CtorArg = NameLike | FwHint | CtorTag | Uint8Array;
    /** A function to modify an existing Interest. */
    type ModifyFunc = (interest: Interest) => void;
    /** Common fields to assign onto an existing Interest. */
    type ModifyFields = Partial<Pick<PublicFields, ArrayValues<typeof modifyFields>>>;
    /** A structure to modify an existing Interest. */
    type Modify = ModifyFunc | ModifyFields;
    /**
     * Turn {@link ModifyFields} to {@link ModifyFunc}.
     * Return {@link ModifyFunc} as-is.
     */
    function makeModifyFunc(input?: Modify): ModifyFunc;
}
export {};
