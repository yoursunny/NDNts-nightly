import { type Decoder, type Encoder } from "@ndn/tlv";
import type { Interest } from "./interest.js";
/** Nack header. */
export declare class NackHeader {
    get reason(): number;
    set reason(v: number);
    private reason_;
    static decodeFrom(decoder: Decoder): NackHeader;
    constructor(reason?: number);
    encodeTo(encoder: Encoder): void;
}
/** Nack packet. */
export declare class Nack {
    interest: Interest;
    get reason(): number;
    set reason(v: number);
    header: NackHeader;
    constructor(interest: Interest, header?: NackHeader | number);
}
