import { Decoder, Encoder } from "@ndn/tlv";
import type { Interest } from "./interest";
/** Nack header. */
export declare class NackHeader {
    get reason(): number;
    set reason(v: number);
    private reason_;
    static decodeFrom(decoder: Decoder): NackHeader;
    constructor(reason?: number);
    encodeTo(encoder: Encoder): void;
}
/** Nack packet. */
export declare class Nack {
    get reason(): number;
    set reason(v: number);
    header: NackHeader;
    interest: Interest;
    constructor(interest: Interest, header?: NackHeader | number);
}
