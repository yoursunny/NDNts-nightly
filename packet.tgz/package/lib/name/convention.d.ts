import type { Component } from "./component";
/**
 * Naming convention, which interprets a name component in a specific way.
 * @template A input type to construct component.
 * @template R output type to interpret component.
 */
export interface NamingConvention<A, R = A> {
    /** Determine if a component follows this naming convention. */
    match: (comp: Component) => boolean;
    /** Create a component from input value following this naming convention. */
    create: (v: A) => Component;
    /** Parse value of a matched component. */
    parse: (comp: Component) => R;
}
export declare namespace NamingConvention {
    /** A naming convention that supports alternate/pretty URI. */
    interface WithAltUri {
        /** Convert to alternate URI. */
        toAltUri: (comp: Component) => string;
        /**
         * Parse from alternate URI.
         * @returns component, or undefined if it cannot be parsed.
         */
        fromAltUri: (input: string) => Component | undefined;
    }
    function isConvention(obj: any): obj is NamingConvention<any>;
}
