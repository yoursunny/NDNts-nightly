import { KeyMap, KeyMultiMap, KeyMultiSet } from "@ndn/util";
import type { Name } from "./name.js";
/**
 * Map keyed by name.
 * Lookups may accept either name or `name.valueHex`.
 */
export declare class NameMap<V> extends KeyMap<Name, V, string, string> {
    constructor();
}
/**
 * MultiMap keyed by name.
 * Lookups may accept either name or `name.valueHex`.
 */
export declare class NameMultiMap<V> extends KeyMultiMap<Name, V, string, string> {
    constructor();
}
/**
 * MultiSet keyed by name.
 * Lookups may accept either name or `name.valueHex`.
 */
export declare class NameMultiSet extends KeyMultiSet<Name, string, string> {
    constructor();
}
