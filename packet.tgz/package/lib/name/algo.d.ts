import type { Name } from "./name";
/**
 * Name longest prefix match algorithm.
 * @param name target name.
 * @param get callback function to retrieve entry by hexadecimal name prefix.
 */
export declare function lpm<Entry>(name: Name, get: (prefixHex: string) => Entry | undefined): Entry | undefined;
