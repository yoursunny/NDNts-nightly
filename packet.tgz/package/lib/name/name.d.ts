import { Decoder, Encoder } from "@ndn/tlv";
import { Component, type ComponentLike } from "./component.js";
import type { NamingConvention } from "./convention.js";
/** Name or Name URI. */
export type NameLike = Name | string;
/**
 * Name.
 *
 * @remarks
 * This type is immutable.
 */
export declare class Name {
    static decodeFrom(decoder: Decoder): Name;
    /**
     * Create Name from Name or Name URI.
     *
     * @remarks
     * This is more efficient than `new Name(input)` if input is already a Name.
     */
    static from(input: NameLike): Name;
    /** Create empty name, or copy from other name, or parse from URI. */
    constructor(input?: NameLike);
    /** Parse from URI, with specific component parser. */
    constructor(uri: string, parseComponent?: (input: string) => Component);
    /** Construct from TLV-VALUE. */
    constructor(value: Uint8Array);
    /** Construct from components. */
    constructor(comps: readonly ComponentLike[]);
    /** List of name components. */
    readonly comps: readonly Component[];
    private readonly valueEncoderBufSize?;
    private value_?;
    private uri_?;
    private hex_?;
    /** Number of name components. */
    get length(): number;
    /** Name TLV-VALUE. */
    get value(): Uint8Array;
    /** Name TLV-VALUE hexadecimal representation, good for map keys. */
    get valueHex(): string;
    /**
     * Retrieve i-th component.
     * @param i - Component index. Negative number counts from the end.
     * @returns i-th component, or `undefined` if it does not exist.
     */
    get(i: number): Component | undefined;
    /**
     * Retrieve i-th component.
     * @param i - Component index. Negative number counts from the end.
     * @returns i-th component.
     *
     * @throws RangeError
     * Thrown if i-th component does not exist.
     */
    at(i: number): Component;
    /** Get URI string. */
    toString(): string;
    /** Get sub name `[begin,end)`. */
    slice(begin?: number, end?: number): Name;
    /** Get prefix of `n` components. */
    getPrefix(n: number): Name;
    /** Append a component from naming convention. */
    append<A>(convention: NamingConvention<A, unknown>, v: A): Name;
    /** Append suffix with one or more components. */
    append(...suffix: readonly ComponentLike[]): Name;
    /** Return a copy of Name with i-th component replaced with `comp`. */
    replaceAt(i: number, comp: ComponentLike): Name;
    /** Compare with other name. */
    compare(other: NameLike): Name.CompareResult;
    /** Determine if this name equals other. */
    equals(other: NameLike): boolean;
    /** Determine if this name is a prefix of other. */
    isPrefixOf(other: NameLike): boolean;
    encodeTo(encoder: Encoder): void;
}
export declare namespace Name {
    /** Determine if obj is Name or Name URI. */
    function isNameLike(obj: any): obj is NameLike;
    /** Name compare result. */
    enum CompareResult {
        /** lhs is less than, but not a prefix of rhs */
        LT = -2,
        /** lhs is a prefix of rhs */
        LPREFIX = -1,
        /** lhs and rhs are equal */
        EQUAL = 0,
        /** rhs is a prefix of lhs */
        RPREFIX = 1,
        /** rhs is less than, but not a prefix of lhs */
        GT = 2
    }
    /** Compare two names. */
    function compare(lhs: Name, rhs: Name): CompareResult;
}
