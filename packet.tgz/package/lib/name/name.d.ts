import { Decoder, Encoder } from "@ndn/tlv";
import { Component, ComponentLike } from "./component";
import type { NamingConvention } from "./convention";
export declare type NameLike = Name | string;
/**
 * Name.
 * This type is immutable.
 */
export declare class Name {
    static decodeFrom(decoder: Decoder): Name;
    /** TLV-VALUE of the Name. */
    readonly value: Uint8Array;
    /** List of name components. */
    readonly comps: readonly Component[];
    /** Create empty name, or copy from other name, or parse from URI. */
    constructor(input?: NameLike);
    /** Parse from URI, with specific component parser. */
    constructor(uri: string, parseComponent?: (input: string) => Component);
    /** Construct from TLV-VALUE. */
    constructor(value: Uint8Array);
    /** Construct from components. */
    constructor(comps: readonly ComponentLike[]);
    get length(): number;
    /** Retrieve i-th component. */
    get(i: number): Component | undefined;
    /**
     * Retrieve i-th component.
     * @throws i-th component does not exist.
     */
    at(i: number): Component;
    /** Get URI string. */
    toString(): string;
    /** Get sub name [begin, end). */
    slice(begin?: number, end?: number): Name;
    /** Get prefix of n components. */
    getPrefix(n: number): Name;
    /** Append a component from naming convention. */
    append<A>(convention: NamingConvention<A, unknown>, v: A): Name;
    /** Append suffix with one or more components. */
    append(...suffix: readonly ComponentLike[]): Name;
    /** Return a copy of Name with a component replaced. */
    replaceAt(i: number, comp: ComponentLike): Name;
    /** Compare with other name. */
    compare(other: NameLike): Name.CompareResult;
    /** Determine if this name equals other. */
    equals(other: NameLike): boolean;
    /** Determine if this name is a prefix of other. */
    isPrefixOf(other: NameLike): boolean;
    encodeTo(encoder: Encoder): void;
}
export declare namespace Name {
    function isNameLike(obj: any): obj is NameLike;
    /** Name compare result. */
    enum CompareResult {
        /** lhs is less than, but not a prefix of rhs */
        LT = -2,
        /** lhs is a prefix of rhs */
        LPREFIX = -1,
        /** lhs and rhs are equal */
        EQUAL = 0,
        /** rhs is a prefix of lhs */
        RPREFIX = 1,
        /** rhs is less than, but not a prefix of lhs */
        GT = 2
    }
}
