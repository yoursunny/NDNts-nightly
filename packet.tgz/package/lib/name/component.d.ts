import { Decoder, Encoder } from "@ndn/tlv";
import type { NamingConvention } from "./convention.js";
declare const FROM: unique symbol;
/** Name component or component URI. */
export type ComponentLike = Component | string;
/**
 * Name component.
 *
 * @remarks
 * This type is immutable.
 */
export declare class Component {
    static decodeFrom(decoder: Decoder): Component;
    /** Parse from URI representation, or return existing Component. */
    static from(input: ComponentLike): Component;
    /**
     * Construct GenericNameComponent from TLV-VALUE.
     * @deprecated Pass `TT.GenericNameComponent` as type.
     */
    constructor(type: undefined, value: Uint8Array | string);
    /**
     * Construct from TLV-TYPE and TLV-VALUE.
     * @param type - TLV-TYPE. Default is GenericNameComponent.
     * @param value - TLV-VALUE. If specified as string, it's encoded as UTF-8 but not interpreted
     *                as URI. Use `Component.from()` to interpret URI.
     *
     * @throws Error
     * Thrown if `type` is not a valid name component TLV-TYPE.
     */
    constructor(type?: number, value?: Uint8Array | string);
    /**
     * Decode from TLV.
     *
     * @throws Error
     * Thrown if `tlv` does not contain a complete name component TLV and nothing else.
     */
    constructor(tlv: Uint8Array);
    /** @internal */
    constructor(type: number, isFrom: typeof FROM, encoder: Encoder, length: number);
    /** Whole TLV. */
    readonly tlv: Uint8Array;
    /** TLV-TYPE. */
    readonly type: number;
    /** TLV-VALUE. */
    readonly value: Uint8Array;
    /** TLV-LENGTH. */
    get length(): number;
    /** TLV-VALUE interpreted as UTF-8 string. */
    get text(): string;
    /** Get URI string. */
    toString(): string;
    encodeTo(encoder: Encoder): void;
    /** Determine if component follows a naming convention. */
    is(convention: NamingConvention<any>): boolean;
    /** Convert with naming convention. */
    as<R>(convention: NamingConvention<any, R>): R;
    /** Compare this component with other. */
    compare(other: ComponentLike): Component.CompareResult;
    /** Determine if this component equals other. */
    equals(other: ComponentLike): boolean;
}
export declare namespace Component {
    /** Component compare result. */
    enum CompareResult {
        /** lhs is less than rhs */
        LT = -2,
        /** lhs and rhs are equal */
        EQUAL = 0,
        /** lhs is greater than rhs */
        GT = 2
    }
}
export {};
