import { Decoder, Encoder } from "@ndn/tlv";
import type { NamingConvention } from "./convention";
export declare type ComponentLike = Component | string;
/**
 * Name component.
 * This type is immutable.
 */
export declare class Component {
    get length(): number;
    /** TLV-VALUE interpreted as UTF-8 string. */
    get text(): string;
    static decodeFrom(decoder: Decoder): Component;
    /** Parse from URI representation, or return existing Component. */
    static from(input: ComponentLike): Component;
    readonly tlv: Uint8Array;
    readonly type: number;
    readonly value: Uint8Array;
    /**
     * Construct from TLV-TYPE and TLV-VALUE.
     * @param type TLV-TYPE, default is GenericNameComponent.
     * @param value TLV-VALUE; if specified as string, it's encoded as UTF-8 but not interpreted
     *              as URI representation. Use from() to interpret URI.
     */
    constructor(type?: number, value?: Uint8Array | string);
    /** Construct from TLV. */
    constructor(tlv: Uint8Array);
    /** Get URI string. */
    toString(): string;
    encodeTo(encoder: Encoder): void;
    /** Determine if component follows a naming convention. */
    is(convention: NamingConvention<any>): boolean;
    /** Convert with naming convention. */
    as<R>(convention: NamingConvention<any, R>): R;
    /** Compare this component with other. */
    compare(other: ComponentLike): Component.CompareResult;
    /** Determine if this component equals other. */
    equals(other: ComponentLike): boolean;
}
export declare namespace Component {
    /** Component compare result. */
    enum CompareResult {
        /** lhs is less than rhs */
        LT = -2,
        /** lhs and rhs are equal */
        EQUAL = 0,
        /** lhs is greater than rhs */
        GT = 2
    }
    /** Compare two components. */
    function compare(lhs: ComponentLike, rhs: ComponentLike): CompareResult;
}
