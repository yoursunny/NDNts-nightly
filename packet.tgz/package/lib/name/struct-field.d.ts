import { StructFieldType } from "@ndn/tlv";
import { Component } from "./component.js";
import { Name } from "./name.js";
/**
 * StructBuilder field type of {@link Name}, where Name TLV is placed into the structure directly.
 *
 * @remarks
 * Example ABNF structure where this can be used:
 * ```abnf
 *  MyType = MY-TYPE-TYPE TLV-LENGTH
 *             OtherTLV
 *             Name
 *             OtherTLV
 * ```
 *
 * The field is defined as `Name`.
 * If the field is required, it is initialized as an empty Name.
 */
export declare const StructFieldName: StructFieldType<Name>;
/**
 * StructBuilder field type of {@link Name}, where Name TLV is nested in an outer TLV.
 *
 * @remarks
 * Example ABNF structure where this can be used:
 * ```abnf
 *  MyType = MY-TYPE-TYPE TLV-LENGTH
 *             OtherTLV
 *             NestedTLV
 *             OtherTLV
 *  NestedTLV = NESTED-TLV-TYPE TLV-LENGTH
 *                Name
 * ```
 *
 * The field is defined as `Name`.
 * If the field is required, it is initialized as an empty Name.
 */
export declare const StructFieldNameNested: StructFieldType<Name>;
/**
 * StructBuilder field type of {@link Component}, where Component TLV is nested in an outer TLV.
 *
 * @remarks
 * Data.FinalBlockId is an example where this might be used.
 */
export declare const StructFieldComponentNested: StructFieldType<Component>;
