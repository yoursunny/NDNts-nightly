import { Decoder, Encoder } from "@ndn/tlv";
import type { Interest } from "./interest";
import { Component, Name, NameLike } from "./name/mod";
import { LLSign, LLVerify, Signer, Verifier } from "./security/signing";
import { SigInfo } from "./sig-info";
declare const FIELDS: unique symbol;
declare class Fields {
    constructor(...args: Array<Data | Data.CtorArg>);
    get isFinalBlock(): boolean;
    set isFinalBlock(v: boolean);
    name: Name;
    get contentType(): number;
    set contentType(v: number);
    get freshnessPeriod(): number;
    set freshnessPeriod(v: number);
    finalBlockId?: Component;
    content: Uint8Array;
    sigInfo: SigInfo;
    sigValue: Uint8Array;
    private contentType_;
    private freshnessPeriod_;
    signedPortion?: Uint8Array;
    topTlv?: Uint8Array;
    topTlvDigest?: Uint8Array;
}
/** Data packet. */
export declare class Data implements LLSign.Signable, LLVerify.Verifiable, Signer.Signable, Verifier.Verifiable {
    /**
     * Construct from flexible arguments.
     *
     * Arguments can include:
     * - Data to copy from
     * - Name or name URI
     * - Data.ContentType(v)
     * - Data.FreshnessPeriod(v)
     * - Data.FinalBlock (must appear after Name)
     * - Uint8Array as Content
     */
    constructor(...args: Array<Data | Data.CtorArg>);
    readonly [FIELDS]: Fields;
    static decodeFrom(decoder: Decoder): Data;
    encodeTo(encoder: Encoder): void;
    private encodeSignedPortion;
    getImplicitDigest(): Uint8Array | undefined;
    computeImplicitDigest(): Promise<Uint8Array>;
    getFullName(): Name | undefined;
    computeFullName(): Promise<Name>;
    /**
     * Determine if a Data can satisfy an Interest.
     * @returns a Promise that will be resolved with the result.
     */
    canSatisfy(interest: Interest): Promise<boolean>;
    [LLSign.OP](sign: LLSign): Promise<void>;
    [LLVerify.OP](verify: LLVerify): Promise<void>;
}
export interface Data extends Fields {
}
declare const ctorAssign: unique symbol;
interface CtorTag {
    [ctorAssign]: (f: Fields) => void;
}
export declare namespace Data {
    /** Constructor argument to set ContentType field. */
    function ContentType(v: number): CtorTag;
    /** Constructor argument to set FreshnessPeriod field. */
    function FreshnessPeriod(v: number): CtorTag;
    /** Constructor argument to set the current packet as FinalBlock. */
    const FinalBlock: unique symbol;
    /** Constructor argument. */
    type CtorArg = NameLike | CtorTag | typeof FinalBlock | Uint8Array;
}
export {};
