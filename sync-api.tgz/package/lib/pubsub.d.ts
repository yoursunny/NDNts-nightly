import type { Name } from "@ndn/packet";
import type { TypedEventTarget } from "typescript-event-target";
import type { SyncUpdate } from "./sync.js";
/** A pubsub protocol subscriber. */
export interface Subscriber<Topic = Name, Update extends Event = SyncUpdate<Topic>, SubscribeInfo = Topic> {
    subscribe: (topic: SubscribeInfo) => Subscription<Topic, Update>;
}
/**
 * A subscription on a topic.
 *
 * @remarks
 * Listen to the 'update' event to receive updates on incoming publications matching the topic.
 * Unsubscribe by disposing the subscription.
 */
export interface Subscription<Topic = Name, Update extends Event = SyncUpdate<Topic>> extends Disposable, TypedEventTarget<Subscription.EventMap<Update>> {
    /** The topic. */
    readonly topic: Topic;
}
export declare namespace Subscription {
    type EventMap<Update extends Event> = {
        /** Emitted when a subscription update is received. */
        update: Update;
    };
}
