import type { TypedEventTarget } from "typescript-event-target";
/** A sync protocol participant. */
export interface SyncProtocol<ID = any> extends TypedEventTarget<SyncProtocol.EventMap<ID>> {
    /** Stop the protocol operation. */
    close: () => void;
    /** Retrieve a node. */
    get: (id: ID) => SyncNode<ID> | undefined;
    /** Retrieve or create a node. */
    add: (id: ID) => SyncNode<ID>;
}
export declare namespace SyncProtocol {
    type EventMap<ID> = {
        /** Emitted when a node is updated, i.e. has new sequence numbers. */
        update: SyncUpdate<ID>;
    };
}
/**
 * A sync protocol node.
 * @typeParam ID - Node identifier type, typically number or Name.
 *
 * @remarks
 * Each sync protocol participant may have zero or more nodes.
 */
export interface SyncNode<ID = any> {
    /** Node identifier. */
    readonly id: ID;
    /**
     * Current sequence number.
     *
     * @remarks
     * It can be increased, but cannot be decreased.
     */
    seqNum: number;
    /**
     * Remove this node from participating in the sync protocol.
     *
     * @remarks
     * This may or may not have effect, depending on the sync protocol.
     */
    remove: () => void;
}
/** A received update regarding a node. */
export declare class SyncUpdate<ID = any> extends Event {
    readonly node: SyncNode<ID>;
    readonly loSeqNum: number;
    readonly hiSeqNum: number;
    /**
     * Constructor.
     * @param node - The node.
     * @param loSeqNum - Low sequence number, inclusive.
     * @param hiSeqNum - High sequence number, inclusive.
     */
    constructor(node: SyncNode<ID>, loSeqNum: number, hiSeqNum: number, eventType?: string);
    /** Node identifier. */
    get id(): ID;
    /** Quantity of new sequence numbers. */
    get count(): number;
    /** Iterate over new sequence numbers. */
    seqNums(): Iterable<number>;
}
