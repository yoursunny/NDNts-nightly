import { type Name, NameMultiMap } from "@ndn/packet";
import type { Subscription } from "./pubsub.js";
/**
 * Track subscriptions in a pubsub protocol.
 * This is primarily useful to pubsub protocol implementors.
 */
export declare class SubscriptionTable<Update extends Event> extends NameMultiMap<Subscription<Name, Update>> {
    /** Callback when the last subscriber of a topic is removed. */
    handleRemoveTopic?: (topic: Name, objKey: object) => void;
    /**
     * Subscribe to a topic.
     * @param topic - Topic name.
     * @returns
     * - `sub`: Subscription object.
     * - `objKey`: WeakMap-compatible key associated with the topic, only provided in the first
     *   subscription.
     */
    subscribe(topic: Name): {
        sub: Subscription<Name, Update>;
        objKey?: object;
    };
    private unsubscribe;
    /**
     * Deliver an update to a set of subscriptions.
     *
     * @remarks
     * The caller should ensure the update matches the subscription topic name.
     */
    update(set: Iterable<Subscription<Name, Update>>, update: Update): void;
}
