/// <reference types="node" />
import { Forwarder, type FwFace } from "@ndn/fw";
import type { NameLike } from "@ndn/packet";
import { type Except } from "type-fest";
/**
 * A bridge passes packets between two logical forwarders.
 * Disposing the bridge severs the link.
 */
export interface Bridge extends Disposable {
    readonly fwA: Forwarder;
    readonly fwB: Forwarder;
    /** Face on fwA linking to fwB. */
    readonly faceA: FwFace;
    /** Face on fwB linking to fwA. */
    readonly faceB: FwFace;
    /** Change fw* and face* property names. */
    rename: <A extends string, B extends string>(A: A, B: B) => Bridge.Renamed<A, B>;
}
export declare namespace Bridge {
    /**
     * Function to relay packets between two logical forwarders.
     * @param it - stream of packet buffers received from peer side.
     * @returns stream of packet buffers injected into our side.
     */
    type RelayFunc = (it: AsyncIterable<Uint8Array>) => AsyncIterable<Uint8Array>;
    /** Options to relay packets with loss, delay, and jitter. */
    interface RelayOptions {
        /**
         * Packet loss rate between 0.0 (no loss) and 1.0 (100% loss).
         * @defaultValue 0
         */
        loss?: number;
        /**
         * Median delay in milliseconds.
         * @defaultValue 1
         */
        delay?: number;
        /**
         * Jitter around median delay.
         * @defaultValue 0
         * @see {@link \@ndn/util!randomJitter}
         */
        jitter?: number;
    }
    type Relay = RelayFunc | RelayOptions;
    /** {@link create} options. */
    interface CreateOptions {
        /** Description for debugging purpose. */
        bridgeName?: string;
        /**
         * Forwarder A.
         * @defaultValue `Forwarder.create(.fwOpts)`
         * @remarks
         * Disposing the bridge closes auto-created Forwarder but not passed-in Forwarder.
         */
        fwA?: Forwarder;
        /**
         * Forwarder B.
         * @defaultValue `Forwarder.create(.fwOpts)`
         * @remarks
         * Disposing the bridge closes auto-created Forwarder but not passed-in Forwarder.
         */
        fwB?: Forwarder;
        /**
         * Options for creating Forwarder instances via {@link Forwarder.create}.
         * @remarks
         * Ignored if both `.fwA` and `.fwB` are specified.
         */
        fwOpts?: Forwarder.Options;
        /**
         * Relay options for packets from forwarder A to forwarder B.
         * @defaultValue instant delivery
         */
        relayAB?: Relay;
        /**
         * Relay options for packets from forwarder B to forwarder A.
         * @defaultValue instant delivery
         */
        relayBA?: Relay;
        /**
         * Routes from forwarder A to forwarder B.
         * @defaultValue `["/"]`
         */
        routesAB?: readonly NameLike[];
        /**
         * Routes from forwarder B to forwarder A.
         * @defaultValue `["/"]`
         */
        routesBA?: readonly NameLike[];
    }
    /** Create a bridge that passes packets between two logical forwarders. */
    function create({ bridgeName, fwA, fwB, fwOpts, relayAB, relayBA, routesAB, routesBA, }?: CreateOptions): Bridge;
    type Renamed<A extends string, B extends string> = Except<Bridge, "fwA" | "fwB" | "faceA" | "faceB"> & {
        [k in `fw${A | B}`]: Forwarder;
    } & {
        [k in `face${A | B}`]: FwFace;
    };
    /** {@link star} options, where each edge/leaf can have different options. */
    type StarEdgeOptions = Except<CreateOptions, "fwA">;
    /** {@link star} options, where every edge/leaf has the same options. */
    type StarOptions = Except<StarEdgeOptions, "fwB"> & {
        /** Number of leaf nodes. */
        leaves: number;
    };
    /**
     * Create a star topology made with bridges.
     * @param opts - Per-leaf options.
     * @param fwA - Center logical forwarder node.
     *
     * @remarks
     * The star topology consists of `fwA` as the center node, and `fwB`s from each of `opts` as
     * leaf nodes. A-to-B goes toward the leaf; B-to-A goes toward the center.
     */
    function star(opts: StarOptions | readonly StarEdgeOptions[], fwA?: Forwarder): Bridge[];
}
