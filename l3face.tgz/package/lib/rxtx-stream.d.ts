/// <reference types="node" />
import type { Transport } from "./transport.js";
/**
 * Extract TLVs from continuous byte stream.
 * @param conn - RX byte stream, such as a TCP socket.
 * @returns RX packet stream.
 */
export declare function rxFromStream(conn: NodeJS.ReadableStream): Transport.RxIterable;
/**
 * Pipe encoded packets to output stream.
 * @param conn - TX output stream, such as a TCP socket.
 * @param iterable - TX packet stream.
 *
 * @remarks
 * `conn` will be closed/destroyed upon reaching the end of packet stream.
 */
export declare function txToStream(conn: NodeJS.WritableStream, iterable: Transport.TxIterable): Promise<void>;
