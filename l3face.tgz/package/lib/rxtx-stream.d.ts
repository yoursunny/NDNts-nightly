/// <reference types="node" />
import type { Transport } from "./mod";
export declare function rxFromStream(conn: NodeJS.ReadableStream): Transport.Rx;
export declare function txToStream(conn: NodeJS.WritableStream): Transport.Tx;
