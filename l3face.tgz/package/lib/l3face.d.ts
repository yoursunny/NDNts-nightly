import { Forwarder, type FwFace, FwPacket } from "@ndn/fw";
import { LpService } from "@ndn/lp";
import { type NameLike } from "@ndn/packet";
import type { Promisable } from "type-fest";
import { TypedEventTarget } from "typescript-event-target";
import { Transport } from "./transport.js";
type EventMap = {
    /** Emitted upon face state change. */
    state: L3Face.StateEvent;
    /** Emitted upon state becomes UP. */
    up: Event;
    /** Emitted upon state becomes DOWN. */
    down: CustomEvent<Error>;
    /** Emitted upon state becomes CLOSED. */
    close: Event;
    /** Emitted upon RX decoding error. */
    rxerror: CustomEvent<L3Face.RxError>;
    /** Emitted upon TX preparation error. */
    txerror: CustomEvent<L3Face.TxError>;
};
/** Network layer face for sending and receiving L3 packets. */
export declare class L3Face extends TypedEventTarget<EventMap> implements FwFace.RxTx {
    private transport;
    /**
     * Constructor.
     * @param transport - Initial transport. It may be replaced through reopen mechanism.
     * @param attributes - Additional attributes.
     * L3Face attributes consist of transport attributes overridden by these attributes.
     * @param lpOptions - NDNLPv2 service options.
     */
    constructor(transport: Transport, attributes?: L3Face.Attributes, lpOptions?: LpService.Options);
    /**
     * Attributes of a network layer face.
     *
     * @remarks
     * When L3Face is added to a logical forwarder, this is copied to {@link FwFace.attributes}.
     */
    readonly attributes: L3Face.Attributes;
    readonly lp: LpService;
    readonly rx: AsyncIterable<FwPacket>;
    private readonly wireTokenPrefix;
    /**
     * Obtain face UP/DOWN state.
     * @remarks
     * Caller can get notifications about state transitions via state/up/down/close events.
     */
    get state(): L3Face.State;
    private set state(value);
    private state_;
    private lastError?;
    private readonly rxSources;
    private reopenRetry?;
    private makeRx;
    private rxTransform;
    private txTransform;
    readonly tx: (iterable: AsyncIterable<FwPacket>) => Promise<void>;
    private reopenTransport;
}
export declare namespace L3Face {
    /** Face state. */
    enum State {
        UP = 0,
        DOWN = 1,
        CLOSED = 2
    }
    class StateEvent extends Event {
        readonly state: State;
        readonly prev: State;
        constructor(type: string, state: State, prev: State);
    }
    interface Attributes extends Transport.Attributes {
        /**
         * Whether to readvertise registered routes.
         * @defaultValue `false`.
         * This default is set in {@link CreateFaceFunc} but could be different elsewhere.
         * @remarks
         * This attribute passed to {@link \@ndn/fw!FwFace.Attributes.advertiseFrom}. With the default
         * `false` value, routes "announced" by an L3Face would not be readvertised to
         * {@link \@ndn/fw!ReadvertiseDestination}s, so that remote forwarders would not depend on the
         * local logical forwarder to forward Interests between L3Faces.
         */
        advertiseFrom?: boolean;
    }
    type RxError = LpService.RxError;
    type TxError = LpService.TxError;
    /** Options to `createFace` as first parameter. */
    interface CreateFaceOptions {
        /**
         * Forwarder instance to add the face to.
         * @defaultValue `Forwarder.getDefault()`
         */
        fw?: Forwarder;
        /**
         * Routes to be added on the created face.
         * @defaultValue `["/"]`
         */
        addRoutes?: readonly NameLike[];
        /**
         * L3Face attributes.
         *
         * @remarks
         * `.l3.advertiseFrom` defaults to false in createFace function.
         */
        l3?: Attributes;
        /** NDNLP service options. */
        lp?: LpService.Options;
        /**
         * A callback to receive {@link Transport}, {@link L3Face}, and {@link FwFace} objects.
         *
         * @remarks
         * This can be useful for reading counters or listening to events on these objects.
         */
        callback?: (transport: Transport, l3face: L3Face, fwFace: FwFace) => void;
    }
    type CreateFaceFunc<P extends any[]> = (opts: CreateFaceOptions, ...args: P) => Promise<FwFace>;
    type CreateFacesFunc<P extends any[]> = (opts: CreateFaceOptions, ...args: P) => Promise<FwFace[]>;
    /** Make a function to create a FwFace from a function that creates a transport. */
    function makeCreateFace<P extends any[]>(createTransport: (...args: P) => Promisable<Transport>): CreateFaceFunc<P>;
    /** Make a function to create FwFaces from a function that creates transports. */
    function makeCreateFace<P extends any[]>(createTransports: (...args: P) => Promisable<Transport[]>): CreateFacesFunc<P>;
    /**
     * Add routes to a FwFace.
     * @param fwFace - Target FwFace.
     * @param addRoutes - List of routes.
     * @remarks
     * This function is typically used for implementing {@link CreateFaceOptions.addRoutes}.
     */
    function processAddRoutes(fwFace: FwFace, addRoutes?: readonly NameLike[]): void;
}
export {};
