import { Forwarder, FwFace, FwPacket } from "@ndn/fw";
import { LpService, NumericPitToken } from "@ndn/lp";
import type TypedEmitter from "typed-emitter";
import type { Transport } from "./mod";
interface Events {
    /** Emitted upon face state change. */
    state: (state: L3Face.State) => void;
    /** Emitted upon state becomes UP. */
    up: () => void;
    /** Emitted upon state becomes DOWN. */
    down: (err: Error) => void;
    /** Emitted upon state becomes CLOSED. */
    close: () => void;
    /** Emitted upon RX decoding error. */
    rxerror: (err: L3Face.RxError) => void;
    /** Emitted upon TX preparation error. */
    txerror: (err: L3Face.TxError) => void;
}
declare const L3Face_base: new () => TypedEmitter<Events>;
/** Network layer face for sending and receiving L3 packets. */
export declare class L3Face extends L3Face_base implements FwFace.RxTx {
    private transport;
    readonly attributes: L3Face.Attributes;
    readonly lp: LpService;
    readonly numericPitToken: NumericPitToken;
    readonly rx: AsyncIterable<FwPacket>;
    get state(): L3Face.State;
    private state_;
    constructor(transport: Transport, attributes?: L3Face.Attributes, lpOptions?: LpService.Options);
    private makeRx;
    tx: (iterable: AsyncIterable<FwPacket>) => Promise<void>;
    private txImpl;
    private reopenTransport;
}
export declare namespace L3Face {
    enum State {
        UP = 0,
        DOWN = 1,
        CLOSED = 2
    }
    interface Attributes extends Transport.Attributes {
        advertiseFrom?: boolean;
    }
    type RxError = LpService.RxError;
    type TxError = LpService.TxError;
    interface CreateFaceOptions {
        fw?: Forwarder;
        l3?: Attributes;
        lp?: LpService.Options;
    }
    /**
     * A function to create a transport then add to forwarder.
     * First parameter is CreateFaceOptions.
     * Subsequent parameters are passed to Transport.connect() function.
     * Returns FwFace.
     */
    type CreateFaceFunc<C extends (...args: any) => Promise<Transport | Transport[]>> = <U extends any[] = C extends (...args: infer P) => any ? P : never>(opts: CreateFaceOptions, ...args: U) => C extends ((...args: U) => Promise<Transport>) ? Promise<FwFace> : C extends ((...args: U) => Promise<Transport[]>) ? Promise<FwFace[]> : never;
    function makeCreateFace<C extends (...args: any) => Promise<Transport | Transport[]>>(createTransport: C): CreateFaceFunc<C>;
}
export {};
