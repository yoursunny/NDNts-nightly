import type { Decoder } from "@ndn/tlv";
/**
 * Low-level transport.
 *
 * The transport understands NDN TLV structures, but does not otherwise concern with packet format.
 */
export declare abstract class Transport {
    readonly attributes: Transport.Attributes;
    abstract readonly rx: Transport.Rx;
    abstract readonly tx: Transport.Tx;
    protected constructor(attributes: Transport.Attributes);
    reopen(): Promise<Transport>;
    toString(): string;
}
export declare namespace Transport {
    interface Attributes extends Record<string, any> {
        describe?: string;
        local?: boolean;
        multicast?: boolean;
    }
    /** RX iterable for incoming packets. */
    type Rx = AsyncIterable<Decoder.Tlv>;
    /**
     * TX function for outgoing packets.
     * @returns Promise that resolves when iterable is exhausted, and rejects upon error.
     */
    type Tx = (iterable: AsyncIterable<Uint8Array>) => Promise<void>;
}
