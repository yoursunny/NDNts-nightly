import type { Decoder } from "@ndn/tlv";
/**
 * Low-level transport.
 *
 * @remarks
 * The transport understands NDN TLV structures, but does not otherwise concern with packet format.
 */
export declare abstract class Transport {
    readonly attributes: Transport.Attributes;
    /**
     * Constructor.
     * @param attributes - Attributes of the transport.
     */
    protected constructor(attributes: Transport.Attributes);
    /**
     * Return the transport MTU.
     *
     * @remarks
     * The transport should be able to send TLV structure of up to this size.
     * If not overridden, return a conservative number.
     *
     * Note that this does not restrict incoming packet size.
     */
    get mtu(): number;
    /** Iterable of incoming packets received through the transport. */
    abstract readonly rx: Transport.RxIterable;
    /**
     * Function to accept outgoing packet stream.
     * @param iterable - Iterable of outgoing packets sent through the transport.
     * Size of each packet cannot exceed `.mtu`.
     * @returns Promise that resolves when iterable is exhausted or rejects upon error.
     */
    abstract tx(iterable: Transport.TxIterable): Promise<void>;
    /**
     * Reopen the transport after it has failed.
     * @returns The same transport or a new transport after it has been reconnected.
     *
     * @throws {@link \@ndn/l3face!Transport.ReopenNotSupportedError}
     * Thrown to indicate the transport does not support reopening.
     */
    reopen(): Promise<Transport>;
    toString(): string;
}
export declare namespace Transport {
    interface Attributes extends Record<string, unknown> {
        /**
         * Textual description.
         * @defaultValue
         * Automatically generated from constructor name.
         */
        describe?: string;
        /**
         * Whether the transport connects to a destination on the local machine.
         * @defaultValue `false`
         */
        local?: boolean;
        /**
         * Whether the transport can possibly talk to multiple peers.
         * @defaultValue `false`
         */
        multicast?: boolean;
        [k: string]: unknown;
    }
    /** RX packet stream. */
    type RxIterable = AsyncIterable<Decoder.Tlv>;
    /** TX packet stream. */
    type TxIterable = AsyncIterable<Uint8Array>;
    /**
     * Error thrown by {@link Transport.reopen} to indicate that reopen operation is not supported.
     * No further `.reopen()` should be attempted.
     */
    class ReopenNotSupportedError extends Error {
        constructor();
    }
}
