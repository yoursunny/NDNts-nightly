import type { Transport } from "./mod";
export declare function rxFromPacketIterable(iterable: AsyncIterable<Uint8Array>): Transport.Rx;
