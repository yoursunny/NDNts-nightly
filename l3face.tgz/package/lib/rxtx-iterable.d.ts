import type { Transport } from "./transport.js";
/**
 * Decode TLVs from datagrams.
 * @param iterable - RX datagram stream, such as a UDP socket.
 * @returns RX packet stream.
 */
export declare function rxFromPacketIterable(iterable: AsyncIterable<Uint8Array>): Transport.RxIterable;
