/// <reference types="node" />
import { Transport } from "./transport";
/** Stream-oriented transport. */
export declare class StreamTransport extends Transport {
    readonly rx: Transport.Rx;
    readonly tx: Transport.Tx;
    constructor(conn: NodeJS.ReadWriteStream, attrs?: Record<string, any>);
}
