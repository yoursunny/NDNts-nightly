import { Transport } from "./transport.js";
/** Node.js stream-based transport. */
export declare class StreamTransport<T extends NodeJS.ReadWriteStream = NodeJS.ReadWriteStream> extends Transport {
    protected readonly conn: T;
    constructor(conn: T, attrs?: Record<string, unknown>);
    /** Report MTU as Infinity. */
    get mtu(): number;
    readonly rx: Transport.RxIterable;
    tx(iterable: Transport.TxIterable): Promise<void>;
}
