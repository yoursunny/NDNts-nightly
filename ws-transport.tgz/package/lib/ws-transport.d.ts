import { L3Face, Transport } from "@ndn/l3face";
import type { AbortSignal } from "abort-controller";
/** WebSocket transport. */
export declare class WsTransport extends Transport {
    private readonly sock;
    private readonly opts;
    readonly rx: Transport.Rx;
    private readonly highWaterMark;
    private readonly lowWaterMark;
    constructor(sock: WebSocket, opts: WsTransport.Options);
    close(): void;
    tx: (iterable: AsyncIterable<Uint8Array>) => Promise<void>;
    private waitForTxBuffer;
    reopen(): Promise<WsTransport>;
}
export declare namespace WsTransport {
    interface Options {
        /** Connect timeout (in milliseconds). */
        connectTimeout?: number;
        /** AbortSignal that allows canceling connection attempt via AbortController. */
        signal?: AbortSignal | globalThis.AbortSignal;
        /** Buffer amount (in bytes) to start TX throttling. */
        highWaterMark?: number;
        /** Buffer amount (in bytes) to stop TX throttling. */
        lowWaterMark?: number;
    }
    /**
     * Create a transport and connect to remote endpoint.
     * @param uri server URI.
     * @param opts other options.
     */
    function connect(uri: string, opts?: WsTransport.Options): Promise<WsTransport>;
    /** Create a transport and add to forwarder. */
    const createFace: L3Face.CreateFaceFunc<typeof connect>;
}
