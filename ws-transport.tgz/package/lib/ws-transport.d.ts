import { L3Face, Transport } from "@ndn/l3face";
import type { WebSocket as WsWebSocket } from "ws";
/** WebSocket transport. */
export declare class WsTransport extends Transport {
    private readonly sock;
    private readonly opts;
    /**
     * Create a transport by connecting to WebSocket server or from existing WebSocket instance.
     * @param uri - Server URI or existing WebSocket instance.
     * @see {@link WsTransport.createFace}
     */
    static connect(uri: string | WebSocket | WsWebSocket, opts?: WsTransport.Options): Promise<WsTransport>;
    private constructor();
    /**
     * Report MTU as Infinity.
     * @see {@link https://stackoverflow.com/a/20658569}
     */
    get mtu(): number;
    readonly rx: Transport.RxIterable;
    private readonly highWaterMark;
    private readonly lowWaterMark;
    tx(iterable: Transport.TxIterable): Promise<void>;
    private waitForTxBuffer;
    close(): void;
    /** Reopen the transport by connecting again with the same options. */
    reopen(): Promise<WsTransport>;
}
export declare namespace WsTransport {
    /** {@link WsTransport.connect} options. */
    interface Options {
        /**
         * Connect timeout (in milliseconds).
         * @defaultValue 10000
         */
        connectTimeout?: number;
        /**
         * Buffer amount (in bytes) to start TX throttling.
         * @defaultValue 1 MiB
         */
        highWaterMark?: number;
        /**
         * Buffer amount (in bytes) to stop TX throttling.
         * @defaultValue 16 KiB
         */
        lowWaterMark?: number;
    }
    /** Create a transport and add to forwarder. */
    const createFace: L3Face.CreateFaceFunc<[uri: string | WebSocket | WsWebSocket, opts?: Options | undefined]>;
}
