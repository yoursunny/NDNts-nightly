export declare function makeWebSocket(uri: string): WebSocket;
