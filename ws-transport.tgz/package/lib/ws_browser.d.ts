export declare function makeWebSocket(uri: string): WebSocket;
export declare function changeBinaryType(sock: WebSocket): void;
export declare function extractMessage(evt: MessageEvent<ArrayBuffer>): Uint8Array;
