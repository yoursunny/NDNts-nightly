/// <reference types="node" />
export declare function makeWebSocket(uri: string): WebSocket;
export declare function changeBinaryType(sock: WebSocket): void;
export declare function extractMessage(evt: MessageEvent<Buffer | ArrayBuffer>): Uint8Array;
