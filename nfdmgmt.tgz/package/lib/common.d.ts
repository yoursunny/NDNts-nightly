import type { ConsumerOptions } from "@ndn/endpoint";
import { type Component, Name } from "@ndn/packet";
export declare const localhostPrefix: Name;
export declare const localhopPrefix: Name;
/**
 * Determine the NFD management prefix.
 * @param isLocal - Whether the client is connected to a NFD local face.
 * @returns NFD management prefix.
 */
export declare function getPrefix(isLocal?: boolean): Name;
export interface CommonOptions {
    /**
     * Consumer options.
     *
     * @remarks
     * - `.describe` defaults to "nfdmgmt".
     * - `.verifier` is recommended.
     */
    cOpts?: ConsumerOptions;
    /**
     * NFD management prefix.
     * @defaultValue `getPrefix()`
     */
    prefix?: Name;
}
export declare function concatName(prefix: Name, subName: string, params: readonly Component[]): Name;
