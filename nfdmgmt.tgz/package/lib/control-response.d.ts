import { Decoder } from "@ndn/tlv";
/** NFD Management ControlResponse struct (decoding only). */
export declare class ControlResponse {
    static decodeFrom(decoder: Decoder): ControlResponse;
    statusCode: number;
    statusText: string;
}
