import { type Decoder, type Encodable, Encoder } from "@ndn/tlv";
/** NFD Management ControlResponse struct. */
export declare class ControlResponse {
    statusCode: number;
    statusText: string;
    static decodeFrom(decoder: Decoder): ControlResponse;
    /**
     * Constructor.
     * @param statusCode - Command status code.
     * @param statusText - Command status text.
     * @param body - Additional elements in the response.
     */
    constructor(statusCode?: number, statusText?: string, body?: Encodable);
    private body_;
    /**
     * Additional elements in the response.
     *
     * @remarks
     * For most NFD control commands, this is {@link ControlParameters}.
     * It can be decoded with:
     * ```ts
     * ControlParameters.decodeFromResponseBody(response);
     * ```
     */
    get body(): Uint8Array;
    set body(value: Encodable);
    encodeTo(encoder: Encoder): void;
}
