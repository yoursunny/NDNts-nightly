import { type Interest, type Signer } from "@ndn/packet";
/**
 * Sign an Interest in Signed Interest 0.2 format.
 * @param interest - Input Interest without signed Interest specific components.
 * @param signer - Private key to sign the Interest.
 * @see {@link https://docs.named-data.net/ndn-cxx/0.8.0/specs/signed-interest.html}
 */
export declare function signInterest02(interest: Interest, { signer, timestamp }?: signInterest02.Options): Promise<Interest>;
export declare namespace signInterest02 {
    interface Options {
        signer?: Signer;
        timestamp?: number;
    }
}
