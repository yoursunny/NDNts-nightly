import { Interest, Signer } from "@ndn/packet";
/**
 * Sign an Interest in 2014 Signed Interest format.
 * @param interest input Interest without signed Interest specific components.
 * @param signer private key to sign the Interest.
 * @see https://named-data.net/doc/ndn-cxx/0.6.6/specs/signed-interest.html
 */
export declare function signInterest02(interest: Interest, { signer, timestamp }?: signInterest02.Options): Promise<Interest>;
export declare namespace signInterest02 {
    interface Options {
        signer?: Signer;
        timestamp?: number;
    }
}
