import { SignedInterestPolicy, type Signer } from "@ndn/packet";
import { type Encodable } from "@ndn/tlv";
import { type CommonOptions } from "./common.js";
import { ControlResponse } from "./control-response.js";
export interface ControlCommandOptions extends CommonOptions {
    /**
     * Command Interest signer.
     * @defaultValue
     * Digest signing.
     */
    signer?: Signer;
    /**
     * Signed Interest policy for the command Interest.
     * @defaultValue
     * Signed Interest shall contain SigNonce and SigTime.
     */
    signedInterestPolicy?: SignedInterestPolicy;
}
/**
 * Invoke generic ControlCommand and wait for response.
 * @param command - Command name.
 * @param params - Command parameters.
 * @param opts - Other options.
 * To interact with non-NFD producer, `.opts.prefix` must be set.
 * @returns Command response.
 */
export declare function invokeGeneric(command: string, params: Encodable, opts?: ControlCommandOptions): Promise<ControlResponse>;
