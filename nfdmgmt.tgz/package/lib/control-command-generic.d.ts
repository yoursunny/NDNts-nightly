import { Interest, type Name, SignedInterestPolicy, type Signer } from "@ndn/packet";
import { type Encodable } from "@ndn/tlv";
import { type CommonOptions } from "./common.js";
import { ControlResponse } from "./control-response.js";
export interface ControlCommandOptions extends CommonOptions {
    /**
     * Customize command format.
     * @defaultValue ControlCommandOptions.formatCommandParamsComp
     */
    formatCommand?: ControlCommandOptions.FormatCommand;
    /**
     * Command Interest signer.
     * @defaultValue
     * Digest signing.
     */
    signer?: Signer;
    /**
     * Signed Interest policy for the command Interest.
     * @defaultValue
     * Signed Interest shall contain SigNonce and SigTime.
     */
    signedInterestPolicy?: SignedInterestPolicy;
}
export declare namespace ControlCommandOptions {
    /** Build command Interest from name and parameters. */
    type FormatCommand = (prefix: Name, command: string, params: Encodable) => Interest;
    /**
     * Build command Interest with parameters in a GenericNameComponent.
     * @see {@link https://redmine.named-data.net/projects/nfd/wiki/ControlCommand}
     */
    const formatCommandParamsComp: FormatCommand;
    /**
     * Build command Interest with parameters in the ApplicationParameters field.
     * @see {@link https://redmine.named-data.net/projects/nfd/wiki/PrefixAnnouncement}
     */
    const formatCommandAppParams: FormatCommand;
}
/**
 * Invoke generic ControlCommand and wait for response.
 * @param command - Command name.
 * @param params - Command parameters.
 * @param opts - Other options.
 * To interact with non-NFD producer, `.opts.prefix` must be set.
 * @returns Command response.
 */
export declare function invokeGeneric(command: string, params: Encodable, opts?: ControlCommandOptions): Promise<ControlResponse>;
