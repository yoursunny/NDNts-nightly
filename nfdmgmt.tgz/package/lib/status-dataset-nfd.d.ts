import { StructBuilder, type StructFields } from "@ndn/tlv";
import type { StatusDataset } from "./status-dataset-generic.js";
declare const GeneralStatus_base: (new () => {
    nfdVersion: string;
    startTimestamp: number;
    currentTimestamp: number;
    nNameTreeEntries: number;
    nFibEntries: number;
    nPitEntries: number;
    nMeasurementsEntries: number;
    nCsEntries: number;
    nInInterests: number;
    nInData: number;
    nInNacks: number;
    nOutInterests: number;
    nOutData: number;
    nOutNacks: number;
    nSatisfiedInterests: number;
    nUnsatisfiedInterests: number;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<GeneralStatus>;
/** NFD status/general dataset. */
export declare class GeneralStatus extends GeneralStatus_base {
    static datasetName: string;
    /** Uptime in milliseconds. */
    get uptime(): number;
}
declare const FaceStatus_base: (new () => {
    faceId: number;
    uri: string;
    localUri: string;
    expirationPeriod?: number | undefined;
    faceScope: number;
    facePersistency: number;
    linkType: number;
    baseCongestionMarkingInterval?: number | undefined;
    defaultCongestionThreshold?: number | undefined;
    mtu?: number | undefined;
    nInInterests: bigint;
    nInData: bigint;
    nInNacks: bigint;
    nOutInterests: bigint;
    nOutData: bigint;
    nOutNacks: bigint;
    nInBytes: bigint;
    nOutBytes: bigint;
    flags: number;
    flagLocalFields: boolean;
    flagLpReliability: boolean;
    flagCongestionMarking: boolean;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<FaceStatus>;
/** NFD *faces/list* and *faces/query* dataset item. */
export declare class FaceStatus extends FaceStatus_base {
    static datasetName: string;
}
declare const buildFaceQueryFilter: StructBuilder<{
    faceId?: number | undefined;
    uriScheme?: string | undefined;
    uri?: string | undefined;
    localUri?: string | undefined;
    expirationPeriod?: number | undefined;
    faceScope?: number | undefined;
    facePersistency?: number | undefined;
    linkType?: number | undefined;
}>;
declare const FaceQueryFilter_base: (new () => {
    faceId?: number | undefined;
    uriScheme?: string | undefined;
    uri?: string | undefined;
    localUri?: string | undefined;
    expirationPeriod?: number | undefined;
    faceScope?: number | undefined;
    facePersistency?: number | undefined;
    linkType?: number | undefined;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<FaceQueryFilter>;
/** NFD *faces/query* dataset parameter. */
export declare class FaceQueryFilter extends FaceQueryFilter_base {
}
/** Create NFD *faces/query* dataset with specified face query filter. */
export declare function FaceQuery(filter: FaceQuery.Filter): StatusDataset<FaceStatus>;
export declare namespace FaceQuery {
    type Filter = Partial<StructFields<typeof buildFaceQueryFilter>>;
}
declare const ChannelStatus_base: (new () => {
    localUri: string;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<ChannelStatus>;
/** NFD *faces/channel* dataset item. */
export declare class ChannelStatus extends ChannelStatus_base {
    static datasetName: string;
}
declare const CsInfo_base: (new () => {
    capacity: bigint;
    flags: number;
    flagEnableAdmit: boolean;
    flagEnableServe: boolean;
    nCsEntries: bigint;
    nHits: bigint;
    nMisses: bigint;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<CsInfo>;
/** NFD *cs/info* dataset item. */
export declare class CsInfo extends CsInfo_base {
    static datasetName: string;
}
declare const StrategyChoice_base: (new () => {
    name: import("@ndn/packet").Name;
    strategy: import("@ndn/packet").Name;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<StrategyChoice>;
/** NFD *strategy-choice/list* dataset item. */
export declare class StrategyChoice extends StrategyChoice_base {
    static datasetName: string;
}
declare const Route_base: (new () => {
    faceId: number;
    origin: number;
    cost: number;
    flags: number;
    flagChildInherit: boolean;
    flagCapture: boolean;
    expirationPeriod?: number | undefined;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<Route>;
/** NFD Route within *rib/list* dataset. */
export declare class Route extends Route_base {
}
declare const RibEntry_base: (new () => {
    name: import("@ndn/packet").Name;
    route: Route[];
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<RibEntry>;
/** NFD *rib/list* dataset item. */
export declare class RibEntry extends RibEntry_base {
    static datasetName: string;
}
export {};
