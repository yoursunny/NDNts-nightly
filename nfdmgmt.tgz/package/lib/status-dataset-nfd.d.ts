import { StructBuilder, type StructFields } from "@ndn/tlv";
import type { StatusDataset } from "./status-dataset-generic.js";
declare const GeneralStatus_base: (new () => {
    currentTimestamp: number;
    nCsEntries: number;
    nFibEntries: number;
    nInData: number;
    nInInterests: number;
    nInNacks: number;
    nMeasurementsEntries: number;
    nNameTreeEntries: number;
    nOutData: number;
    nOutInterests: number;
    nOutNacks: number;
    nPitEntries: number;
    nSatisfiedInterests: number;
    nUnsatisfiedInterests: number;
    nfdVersion: string;
    startTimestamp: number;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<GeneralStatus>;
/** NFD *status/general* dataset. */
export declare class GeneralStatus extends GeneralStatus_base {
    static datasetName: string;
    /** Uptime in milliseconds. */
    get uptime(): number;
}
declare const FaceStatus_base: (new () => {
    baseCongestionMarkingInterval?: number | undefined;
    defaultCongestionThreshold?: number | undefined;
    expirationPeriod?: number | undefined;
    faceId: number;
    facePersistency: number;
    faceScope: number;
    flagCongestionMarking: boolean;
    flagLocalFields: boolean;
    flagLpReliability: boolean;
    flags: number;
    linkType: number;
    localUri: string;
    mtu?: number | undefined;
    nInBytes: bigint;
    nInData: bigint;
    nInInterests: bigint;
    nInNacks: bigint;
    nOutBytes: bigint;
    nOutData: bigint;
    nOutInterests: bigint;
    nOutNacks: bigint;
    uri: string;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<FaceStatus>;
/** NFD *faces/list* and *faces/query* dataset item. */
export declare class FaceStatus extends FaceStatus_base {
    static datasetName: string;
}
declare const buildFaceQueryFilter: StructBuilder<{
    expirationPeriod?: number | undefined;
    faceId?: number | undefined;
    facePersistency?: number | undefined;
    faceScope?: number | undefined;
    linkType?: number | undefined;
    localUri?: string | undefined;
    uri?: string | undefined;
    uriScheme?: string | undefined;
}>;
declare const FaceQueryFilter_base: (new () => {
    expirationPeriod?: number | undefined;
    faceId?: number | undefined;
    facePersistency?: number | undefined;
    faceScope?: number | undefined;
    linkType?: number | undefined;
    localUri?: string | undefined;
    uri?: string | undefined;
    uriScheme?: string | undefined;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<FaceQueryFilter>;
/** NFD *faces/query* dataset parameter. */
export declare class FaceQueryFilter extends FaceQueryFilter_base {
}
/** Create NFD *faces/query* dataset with specified face query filter. */
export declare function FaceQuery(filter: FaceQuery.Filter): StatusDataset<FaceStatus>;
export declare namespace FaceQuery {
    type Filter = Partial<StructFields<typeof buildFaceQueryFilter>>;
}
declare const ChannelStatus_base: (new () => {
    localUri: string;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<ChannelStatus>;
/** NFD *faces/channel* dataset item. */
export declare class ChannelStatus extends ChannelStatus_base {
    static datasetName: string;
}
declare const CsInfo_base: (new () => {
    capacity: bigint;
    flagEnableAdmit: boolean;
    flagEnableServe: boolean;
    flags: number;
    nCsEntries: bigint;
    nHits: bigint;
    nMisses: bigint;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<CsInfo>;
/** NFD *cs/info* dataset item. */
export declare class CsInfo extends CsInfo_base {
    static datasetName: string;
}
declare const StrategyChoice_base: (new () => {
    name: import("@ndn/packet").Name;
    strategy: import("@ndn/packet").Name;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<StrategyChoice>;
/** NFD *strategy-choice/list* dataset item. */
export declare class StrategyChoice extends StrategyChoice_base {
    static datasetName: string;
}
declare const Route_base: (new () => {
    cost: number;
    expirationPeriod?: number | undefined;
    faceId: number;
    flagCapture: boolean;
    flagChildInherit: boolean;
    flags: number;
    origin: number;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<Route>;
/** NFD Route within *rib/list* dataset. */
export declare class Route extends Route_base {
}
declare const RibEntry_base: (new () => {
    name: import("@ndn/packet").Name;
    route: Route[];
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<RibEntry>;
/** NFD *rib/list* dataset item. */
export declare class RibEntry extends RibEntry_base {
    static datasetName: string;
}
export {};
