import { Name } from "@ndn/packet";
import { Encoder } from "@ndn/tlv";
interface Fields {
    name?: Name;
    faceId?: number;
    uri?: string;
    localUri?: string;
    origin?: number;
    cost?: number;
    capacity?: number;
    count?: number;
    baseCongestionMarkingInterval?: number;
    defaultCongestionPeriod?: number;
    mtu?: number;
    flags?: number;
    mask?: number;
    strategy?: Name;
    expirationPeriod?: number;
    facePersistency?: number;
}
/** NFD Management ControlParameters struct (encoding only). */
export declare class ControlParameters {
    constructor(value?: Fields);
    encodeTo(encoder: Encoder): void;
}
export interface ControlParameters extends ControlParameters.Fields {
}
declare type Fields_ = Fields;
export declare namespace ControlParameters {
    type Fields = Fields_;
}
export {};
