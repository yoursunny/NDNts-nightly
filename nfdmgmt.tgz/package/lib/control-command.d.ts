import { Endpoint } from "@ndn/endpoint";
import { Name } from "@ndn/packet";
import { ControlParameters } from "./control-parameters";
import { ControlResponse } from "./control-response";
import { signInterest02 } from "./sign-interest-02";
/**
 * Pick fields from ControlParameters.Fields.
 * R are required.
 * O are optional.
 */
declare type CP<R extends keyof ControlParameters.Fields, O extends keyof ControlParameters.Fields> = Required<Pick<ControlParameters.Fields, R>> & Pick<ControlParameters.Fields, O>;
/** Declare required and optional fields of each command. */
interface Commands {
    "face/create": CP<"uri", "localUri" | "facePersistency" | "baseCongestionMarkingInterval" | "defaultCongestionPeriod" | "mtu" | "flags" | "mask">;
    "face/update": CP<never, "faceId" | "facePersistency" | "baseCongestionMarkingInterval" | "defaultCongestionPeriod" | "flags" | "mask">;
    "face/destroy": CP<"faceId", never>;
    "strategy-choice/set": CP<"name" | "strategy", never>;
    "strategy-choice/unset": CP<"name", never>;
    "rib/register": CP<"name", "faceId" | "origin" | "cost" | "flags" | "expirationPeriod">;
    "rib/unregister": CP<"name", "faceId" | "origin">;
}
/** NFD Management - Control Command client. */
export declare namespace ControlCommand {
    interface Options extends signInterest02.Options {
        endpoint?: Endpoint;
        commandPrefix?: Name;
    }
    const localhostPrefix: Name;
    const localhopPrefix: Name;
    function getPrefix(isLocal?: boolean): Name;
    /** Invoke a command and wait for response. */
    function call<C extends keyof Commands>(command: C, params: Commands[C], opts?: Options): Promise<ControlResponse>;
}
export {};
