export declare const RouteFlags: {
    readonly ChildInherit: number;
    readonly Capture: number;
};
