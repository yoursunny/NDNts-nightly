export declare const RouteFlags: {
    readonly ChildInherit: number;
    readonly Capture: number;
};
export declare const TT: {
    readonly ControlParameters: 104;
    readonly Cost: 106;
    readonly ExpirationPeriod: 109;
    readonly Flags: 108;
    readonly Origin: 111;
};
export declare const RouteOriginClient = 65;
export declare const RouteOriginPrefixAnn = 129;
