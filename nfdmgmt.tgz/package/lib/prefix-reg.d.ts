import { type FwFace, ReadvertiseDestination } from "@ndn/fw";
import { type KeyChain } from "@ndn/keychain";
import { type Name } from "@ndn/packet";
import type { Except } from "type-fest";
import { RouteFlags } from "./an-nfd-prefixreg.js";
import { ControlCommandOptions } from "./control-command-generic.js";
import type { ControlParameters } from "./control-command-nfd.js";
import type { PrefixAnn } from "./prefix-ann.js";
interface State {
    refreshTimer?: NodeJS.Timeout | number;
    pa?: PrefixAnn;
}
/** Readvertise prefix announcements via NFD prefix registration protocol. */
export declare class NfdPrefixReg extends ReadvertiseDestination<State> {
    private readonly face;
    private readonly commandOptions;
    private readonly PrefixAnn?;
    private readonly routeElements;
    private readonly refreshInterval?;
    private readonly preloadCertName?;
    private readonly preloadFromKeyChain?;
    private readonly preloadInterestLifetime;
    private readonly preloadCerts;
    /**
     * Constructor.
     *
     * @remarks
     * {@link enableNfdPrefixReg} is recommended.
     */
    constructor(face: FwFace, opts: NfdPrefixReg.Options);
    disable(): void;
    private tap;
    private preload;
    private retrievePreload;
    private readonly handleFaceUp;
    protected doAdvertise(name: Name, state: State): Promise<void>;
    private scheduleRefresh;
    protected doWithdraw(name: Name, state: State): Promise<void>;
    private checkSuccess;
}
export declare namespace NfdPrefixReg {
    /** {@link enableNfdPrefixReg} options. */
    type Options = Except<ControlCommandOptions, "prefix"> & (Pick<ControlParameters.Fields, "origin" | "cost" | `flag${keyof typeof RouteFlags}`>) & {
        /**
         * Opt-in to Prefix Announcement Protocol.
         * @see {@link https://redmine.named-data.net/projects/nfd/wiki/PrefixAnnouncement}
         *
         * To opt-in, set this field to `PrefixAnn` imported from this package.
         * Producer must supply Prefix Announcement objects to the FwFace so that they are available
         * for use in the readvertise destinations.
         *
         * Currently, the following limitations apply for the Prefix Announcement Protocol:
         * - Not all NFD deployments can accept this protocol.
         * - You cannot specify Origin, Cost, Flags of the route.
         * - The announced prefix will not be further propagated, because NFD considers routes with
         *   Origin=65 to be propagable but the route Origin cannot be specified.
         */
        PrefixAnn?: typeof PrefixAnn;
        /** Retry options for each advertise/withdraw operation. */
        retry?: ReadvertiseDestination.RetryOptions;
        /**
         * How often to refresh prefix registration (in milliseconds).
         * Random jitter of ±10% is applied automatically.
         * Set to `false` disables refreshing.
         *
         * @defaultValue 300 seconds
         *
         * @remarks
         * For rib/register command, the ExpirationPeriod is set to 4x of this refresh interval,
         * with a minimum of 60 seconds.
         *
         * For rib/announce command, the application must make sure each supplied Prefix Announcement
         * object has an ExpirationPeriod at least 2x of this refresh interval and a ValidityPeriod
         * that extends beyond the anticipated producer runtime.
         */
        refreshInterval?: number | false;
        /**
         * Set to signer name to retrieve and serve certificate chain.
         * If unset, no certificates will be served.
         */
        preloadCertName?: Name;
        /**
         * Local KeyChain to collect preloaded certificates.
         * If unset, certificates will not be collected from a local KeyChain.
         */
        preloadFromKeyChain?: KeyChain;
        /**
         * InterestLifetime for retrieving preloaded certificates.
         * @defaultValue 1500
         */
        preloadInterestLifetime?: number;
    };
}
/**
 * Enable prefix registration via NFD management protocol.
 * @param face - Face connected to NFD.
 * @returns NFD prefix registration module.
 */
export declare function enableNfdPrefixReg(face: FwFace, opts?: NfdPrefixReg.Options): NfdPrefixReg;
export {};
