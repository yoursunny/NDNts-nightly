import { FwFace, ReadvertiseDestination } from "@ndn/fw";
import { KeyChain } from "@ndn/keychain";
import { Name } from "@ndn/packet";
import { ControlCommand } from "./control-command";
import type { ControlParameters } from "./control-parameters";
declare type CommandOptions = Omit<ControlCommand.Options, "endpoint">;
declare type RouteOptions = Pick<ControlParameters.Fields, "origin" | "cost" | "flags">;
declare type Options = CommandOptions & RouteOptions & {
    retry?: ReadvertiseDestination.RetryOptions;
    /** How often to refresh prefix registration, false to disable. */
    refreshInterval?: number | false;
    /** Set to signer name to retrieve and serve certificate chain. */
    preloadCertName?: Name;
    /** Local KeyChain to collect preloaded certificates. */
    preloadFromKeyChain?: KeyChain;
};
/**
 * Enable prefix registration via NFD management protocol.
 * @param face face connected to NFD.
 * @param opts options.
 */
export declare function enableNfdPrefixReg(face: FwFace, opts?: Options): void;
export {};
