import { type FwFace, ReadvertiseDestination } from "@ndn/fw";
import { type KeyChain } from "@ndn/keychain";
import { type Name } from "@ndn/packet";
import type { Except } from "type-fest";
import { RouteFlags } from "./an-nfd-prefixreg.js";
import { type ControlCommandOptions } from "./control-command-generic.js";
import type { ControlParameters } from "./control-command-nfd.js";
interface State {
    refreshTimer?: NodeJS.Timeout | number;
}
/** Readvertise prefix announcements via NFD prefix registration protocol. */
export declare class NfdPrefixReg extends ReadvertiseDestination<State> {
    private readonly face;
    private readonly commandOptions;
    private readonly routeElements;
    private readonly refreshInterval?;
    private readonly preloadCertName?;
    private readonly preloadFromKeyChain?;
    private readonly preloadInterestLifetime;
    private readonly preloadCerts;
    /**
     * Constructor.
     *
     * @remarks
     * {@link enableNfdPrefixReg} is recommended.
     */
    constructor(face: FwFace, opts: NfdPrefixReg.Options);
    disable(): void;
    private tap;
    private preload;
    private retrievePreload;
    private readonly handleFaceUp;
    protected doAdvertise(name: Name, state: State): Promise<void>;
    private scheduleRefresh;
    protected doWithdraw(name: Name, state: State): Promise<void>;
    private checkSuccess;
}
export declare namespace NfdPrefixReg {
    /** {@link enableNfdPrefixReg} options. */
    type Options = Except<ControlCommandOptions, "prefix"> & Pick<ControlParameters.Fields, "origin" | "cost" | `flag${keyof typeof RouteFlags}`> & {
        retry?: ReadvertiseDestination.RetryOptions;
        /**
         * How often to refresh prefix registration (in milliseconds).
         * Set to `false` disables refreshing.
         */
        refreshInterval?: number | false;
        /**
         * Set to signer name to retrieve and serve certificate chain.
         * If unset, no certificates will be served.
         */
        preloadCertName?: Name;
        /**
         * Local KeyChain to collect preloaded certificates.
         * If unset, certificates will not be collected from a local KeyChain.
         */
        preloadFromKeyChain?: KeyChain;
        /**
         * InterestLifetime for retrieving preloaded certificates.
         * @defaultValue 500
         */
        preloadInterestLifetime?: number;
    };
}
/**
 * Enable prefix registration via NFD management protocol.
 * @param face - Face connected to NFD.
 * @returns NFD prefix registration module.
 */
export declare function enableNfdPrefixReg(face: FwFace, opts?: NfdPrefixReg.Options): NfdPrefixReg;
export {};
