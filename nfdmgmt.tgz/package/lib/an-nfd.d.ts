export { RouteFlags } from "./an-nfd-prefixreg.js";
export declare const TT: {
    readonly BaseCongestionMarkingInterval: 135;
    readonly Capacity: 131;
    readonly ChannelStatus: 130;
    readonly ControlParameters: 104;
    readonly Cost: 106;
    readonly Count: 132;
    readonly CsInfo: 128;
    readonly CurrentTimestamp: 130;
    readonly DefaultCongestionThreshold: 136;
    readonly ExpirationPeriod: 109;
    readonly FaceEventKind: 193;
    readonly FaceEventNotification: 192;
    readonly FaceId: 105;
    readonly FacePersistency: 133;
    readonly FaceQueryFilter: 150;
    readonly FaceScope: 132;
    readonly FaceStatus: 128;
    readonly Flags: 108;
    readonly LinkType: 134;
    readonly LocalUri: 129;
    readonly Mask: 112;
    readonly Mtu: 137;
    readonly NCsEntries: 135;
    readonly NfdVersion: 128;
    readonly NFibEntries: 132;
    readonly NHits: 129;
    readonly NInBytes: 148;
    readonly NInData: 145;
    readonly NInInterests: 144;
    readonly NInNacks: 151;
    readonly NMeasurementsEntries: 134;
    readonly NMisses: 130;
    readonly NNameTreeEntries: 131;
    readonly NOutBytes: 149;
    readonly NOutData: 147;
    readonly NOutInterests: 146;
    readonly NOutNacks: 152;
    readonly NPitEntries: 133;
    readonly NSatisfiedInterests: 153;
    readonly NUnsatisfiedInterests: 154;
    readonly Origin: 111;
    readonly RibEntry: 128;
    readonly Route: 129;
    readonly StartTimestamp: 129;
    readonly Strategy: 107;
    readonly StrategyChoice: 128;
    readonly Uri: 114;
    readonly UriScheme: 131;
};
export declare enum FaceScope {
    NonLocal = 0,
    Local = 1
}
export declare enum LinkType {
    PointToPoint = 0,
    MultiAccess = 1,
    AdHocWireless = 2
}
export declare enum FacePersistency {
    OnDemand = 0,
    Persistent = 1,
    Permanent = 2
}
export declare const FaceFlags: {
    readonly LocalFields: number;
    readonly LpReliability: number;
    readonly CongestionMarking: number;
};
export declare const CsFlags: {
    readonly EnableAdmit: number;
    readonly EnableServe: number;
};
