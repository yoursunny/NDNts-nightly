import type { FwFace } from "@ndn/fw";
import { Data, Name, type NameLike, type Signer, ValidityPeriod } from "@ndn/packet";
/**
 * Prefix Announcement object.
 * @see {@link https://redmine.named-data.net/projects/nfd/wiki/PrefixAnnouncement}
 * @see {@link https://gist.github.com/jaczhi/5408716346761de953bec18444b9daf4}
 */
export declare class PrefixAnn implements FwFace.PrefixAnnouncementObj {
    readonly data: Data;
    readonly expirationPeriod: number;
    readonly validityPeriod: ValidityPeriod | undefined;
    readonly cost: number;
    /**
     * Construct Prefix Announcement object from Data packet.
     *
     * @throws Error
     * Thrown if the Data packet is not a Prefix Announcement object.
     */
    static fromData(data: Data): PrefixAnn;
    private constructor();
    /** The announced prefix. */
    get announced(): Name;
}
export declare namespace PrefixAnn {
    /** {@link PrefixAnn.build} options. */
    interface BuildOptions {
        /** Announced name. */
        announced: NameLike;
        /**
         * Prefix Announcement object version.
         * @defaultValue `Date.now()`
         */
        version?: number;
        /** Expiration period in milliseconds. */
        expirationPeriod: number;
        /** ValidityPeriod. */
        validityPeriod?: ValidityPeriod;
        /**
         * Route cost.
         * @defaultValue 0
         */
        cost?: number;
        /**
         * Data signer.
         * @defaultValue nullSigner
         */
        signer?: Signer;
    }
    /** Build a Prefix Announcement object from fields. */
    function build({ announced, version, expirationPeriod, validityPeriod, cost, signer, }: BuildOptions): Promise<PrefixAnn>;
}
