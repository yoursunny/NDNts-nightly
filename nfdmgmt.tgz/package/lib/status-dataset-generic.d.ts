import type { Component } from "@ndn/packet";
import { type Decodable } from "@ndn/tlv";
import { type CommonOptions } from "./common.js";
export interface StatusDatasetOptions extends CommonOptions {
}
/** Dataset name, parameters, and item type. */
export interface StatusDataset<R> extends Decodable<R> {
    /** Dataset name, written in name URI format. */
    readonly datasetName: string;
    /** Dataset parameters components. */
    readonly datasetParams?: readonly Component[];
}
/**
 * Retrieve a StatusDataset.
 * @typeParam R - Item type.
 * @param dataset - Dataset name, parameters, and item type.
 * @param opts - Other options.
 * To interact with non-NFD producer, `.opts.prefix` must be set.
 * @returns Dataset items.
 */
export declare function list<R>(dataset: StatusDataset<R>, opts?: StatusDatasetOptions): Promise<R[]>;
/**
 * Retrieve a StatusDataset.
 * @typeParam R - Item type.
 * @param dataset - Dataset name, written in name URI format.
 * @param params - Dataset parameters components.
 * @param d - Item type.
 * @param opts - Other options.
 * To interact with non-NFD producer, `.opts.prefix` must be set.
 * @returns Dataset items.
 */
export declare function list<R>(dataset: string, params: readonly Component[], d: Decodable<R>, opts?: StatusDatasetOptions): Promise<R[]>;
