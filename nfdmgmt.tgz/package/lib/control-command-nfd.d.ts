import { type Name } from "@ndn/packet";
import { StructBuilder, type StructFields } from "@ndn/tlv";
import type { SetRequired } from "type-fest";
import { CsFlags, FaceFlags, FacePersistency, RouteFlags } from "./an-nfd.js";
import { type ControlCommandOptions } from "./control-command-generic.js";
import type { ControlResponse } from "./control-response.js";
declare const buildControlParameters: StructBuilder<{
    name?: Name | undefined;
    faceId?: number | undefined;
    uri?: string | undefined;
    localUri?: string | undefined;
    origin?: number | undefined;
    cost?: number | undefined;
    capacity?: number | undefined;
    count?: number | undefined;
    flags?: number | undefined;
    flagChildInherit: boolean;
    flagCapture: boolean;
    flagEnableAdmit: boolean;
    flagEnableServe: boolean;
    flagLocalFields: boolean;
    flagLpReliability: boolean;
    flagCongestionMarking: boolean;
    mask?: number | undefined;
    maskChildInherit: boolean;
    maskCapture: boolean;
    maskEnableAdmit: boolean;
    maskEnableServe: boolean;
    maskLocalFields: boolean;
    maskLpReliability: boolean;
    maskCongestionMarking: boolean;
    strategy?: Name | undefined;
    expirationPeriod?: number | undefined;
    facePersistency?: FacePersistency | undefined;
    baseCongestionMarkingInterval?: number | undefined;
    defaultCongestionThreshold?: number | undefined;
    mtu?: number | undefined;
}>;
declare const ControlParameters_base: (new () => {
    name?: Name | undefined;
    faceId?: number | undefined;
    uri?: string | undefined;
    localUri?: string | undefined;
    origin?: number | undefined;
    cost?: number | undefined;
    capacity?: number | undefined;
    count?: number | undefined;
    flags?: number | undefined;
    flagChildInherit: boolean;
    flagCapture: boolean;
    flagEnableAdmit: boolean;
    flagEnableServe: boolean;
    flagLocalFields: boolean;
    flagLpReliability: boolean;
    flagCongestionMarking: boolean;
    mask?: number | undefined;
    maskChildInherit: boolean;
    maskCapture: boolean;
    maskEnableAdmit: boolean;
    maskEnableServe: boolean;
    maskLocalFields: boolean;
    maskLpReliability: boolean;
    maskCongestionMarking: boolean;
    strategy?: Name | undefined;
    expirationPeriod?: number | undefined;
    facePersistency?: FacePersistency | undefined;
    baseCongestionMarkingInterval?: number | undefined;
    defaultCongestionThreshold?: number | undefined;
    mtu?: number | undefined;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<ControlParameters>;
/** NFD Management ControlParameters struct. */
export declare class ControlParameters extends ControlParameters_base {
    /**
     * Decode from {@link ControlResponse} body.
     * @param response - {@link ControlResponse} that contains ControlParameters.
     */
    static decodeFromResponseBody(response: {
        body: Uint8Array;
    }): ControlParameters;
    constructor(value?: ControlParameters.Fields);
}
export declare namespace ControlParameters {
    type Fields = Partial<StructFields<typeof buildControlParameters>>;
}
/**
 * Pick fields from ControlParameters.Fields.
 * @typeParam R - Required fields.
 * @typeParam O - Optional fields.
 */
type CP<R extends keyof ControlParameters.Fields, O extends keyof ControlParameters.Fields> = SetRequired<Pick<ControlParameters.Fields, R | O>, R>;
/** Declare required and optional fields of each command. */
interface Commands {
    "faces/create": CP<"uri", "localUri" | "facePersistency" | "baseCongestionMarkingInterval" | "defaultCongestionThreshold" | "mtu" | "flags" | `flag${keyof typeof FaceFlags}` | "mask" | `mask${keyof typeof FaceFlags}`>;
    "faces/update": CP<never, "faceId" | "facePersistency" | "baseCongestionMarkingInterval" | "defaultCongestionThreshold" | "mtu" | "flags" | `flag${keyof typeof FaceFlags}` | "mask" | `mask${keyof typeof FaceFlags}`>;
    "faces/destroy": CP<"faceId", never>;
    "cs/config": CP<never, "capacity" | "flags" | `flag${keyof typeof CsFlags}` | "mask" | `mask${keyof typeof CsFlags}`>;
    "cs/erase": CP<"name", "count">;
    "strategy-choice/set": CP<"name" | "strategy", never>;
    "strategy-choice/unset": CP<"name", never>;
    "rib/register": CP<"name", "faceId" | "origin" | "cost" | "flags" | `flag${keyof typeof RouteFlags}` | "expirationPeriod">;
    "rib/unregister": CP<"name", "faceId" | "origin">;
}
/**
 * Invoke NFD ControlCommand and wait for response.
 * @param command - Command module and verb.
 * @param params - Command parameters.
 * @param opts - Other options.
 * @returns Command response.
 */
export declare function invoke<C extends keyof Commands>(command: C, params: Commands[C], opts?: ControlCommandOptions): Promise<ControlResponse>;
/**
 * Erase all CS entries under a name prefix.
 * @param name - Name prefix.
 * @param opts - Other options.
 * @returns Total erased entries.
 *
 * @remarks
 * NFD cs/erase command can impose a limit on how many CS entries may be erased upon each
 * invocation. This function repeatedly invoke cs/erase until it returns zero. Notice that this
 * function could take a long time if `name` is a busy prefix, and this function may continue
 * forever if `name` is a prefix of `opts.prefix`.
 */
export declare function invokeCsErase(name: Name, opts?: ControlCommandOptions): Promise<number>;
export {};
