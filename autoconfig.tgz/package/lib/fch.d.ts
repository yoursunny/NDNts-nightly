/**
 * Query NDN-FCH (Find Closest Hub) service.
 * @see https://github.com/named-data/ndn-fch
 */
export declare function queryFch(opts?: queryFch.Options): Promise<string[]>;
export declare namespace queryFch {
    interface Options {
        /** FCH server, must be https for browser. */
        server?: string;
        /** Number of routers to request, default is 1. */
        count?: number;
        /** Required router capabilities. */
        capabilities?: string[];
        /** GPS position in GeoJSON [lon,lat] format, or IpGeolocation. */
        position?: [lon: number, lat: number] | typeof IpGeolocation;
    }
    /** Set IP geolocation in Options.position. */
    const IpGeolocation: unique symbol;
}
