import { Name } from "@ndn/packet";
import type { ConnectRouterOptions } from "./router.js";
export interface PlatformFchDefaults {
    transports: (opts?: ConnectRouterOptions) => string[];
    readonly hasIPv4?: boolean;
    readonly hasIPv6?: boolean;
}
/** FCH service request. */
export interface FchRequest {
    /**
     * FCH service URI.
     * @defaultValue https://fch.ndn.today
     */
    server?: string;
    /**
     * Transport protocol, such as "udp".
     *
     * @remarks
     * Ignored if `.transports` is specified.
     */
    transport?: string;
    /**
     * Number of routers.
     *
     * @remarks
     * Ignored if `transports` is a Record.
     */
    count?: number;
    /**
     * Transport protocols.
     *
     * @remarks
     * If this is an array of transport protocols, the quantity of each is specified by `count`.
     * If this is a Record, each key is a transport protocol and each value is the quantity.
     */
    transports?: readonly string[] | Record<string, number>;
    /**
     * IPv4 allowed?
     * @defaultValue auto detect
     */
    ipv4?: boolean;
    /**
     * IPv6 allowed?
     * @defaultValue auto detect
     */
    ipv6?: boolean;
    /** Client geolocation. */
    position?: [lon: number, lat: number];
    /** Network authority, such as "yoursunny". */
    network?: string;
    /** AbortSignal that allows canceling the request via AbortController. */
    signal?: AbortSignal;
}
/** FCH service response. */
export interface FchResponse {
    readonly updated?: Date;
    readonly routers: FchResponse.Router[];
}
export declare namespace FchResponse {
    interface Router {
        transport: string;
        connect: string;
        prefix?: Name;
    }
}
/** FCH service query. */
export declare function fchQuery(req?: FchRequest): Promise<FchResponse>;
