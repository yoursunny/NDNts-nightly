import type { FwFace } from "@ndn/fw";
import { type FchRequest } from "./fch.js";
import { type ConnectRouterOptions } from "./router.js";
/** {@link connectToNetwork} options. */
export interface ConnectNetworkOptions extends ConnectRouterOptions {
    /**
     * FCH request, or `false` to disable FCH query.
     * @defaultValue `{ count: 4 }`
     */
    fch?: FchRequest | false;
    /**
     * Whether to try HTTP/3 before all other options.
     * @defaultValue false
     *
     * @remarks
     * Ignored if H3Transport is not enabled or supported.
     */
    preferH3?: boolean;
    /**
     * Whether to consider default IPv4 gateway as a candidate.
     * @defaultValue true
     *
     * @remarks
     * This option has no effect if IPv4 gateway cannot be determined, e.g. in browser.
     */
    tryDefaultGateway?: boolean;
    /** Fallback routers, used if FCH and default gateway are both unavailable. */
    fallback?: readonly string[];
    /**
     * Number of faces to keep; others are closed.
     * Faces are ranked by shortest testConnection duration.
     * @defaultValue 1
     */
    fastest?: number;
}
/** Connect to an NDN network. */
export declare function connectToNetwork(opts?: ConnectNetworkOptions): Promise<FwFace[]>;
