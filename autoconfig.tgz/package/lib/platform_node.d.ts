import type { FwFace } from "@ndn/fw";
import type { PlatformFchDefaults } from "./fch.js";
import type { ConnectRouterOptions } from "./router.js";
export declare const FCH_DEFAULTS: PlatformFchDefaults;
export declare function getDefaultGateway(): Promise<string>;
export declare function createFace(router: string, { fw, preferTcp, mtu, connectTimeout, addRoutes, }: ConnectRouterOptions): Promise<FwFace>;
