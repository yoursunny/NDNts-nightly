import type { FwFace } from "@ndn/fw";
import nodeFetch from "node-fetch";
import type { connect } from "./connect";
export declare const fetch: typeof nodeFetch;
export declare const FCH_ALWAYS_CAPABILITIES: never[];
export declare function createFace(host: string, { fw, preferProtocol, mtu, connectTimeout, }: connect.Options): Promise<FwFace>;
export declare function getDefaultGateway(): Promise<string>;
