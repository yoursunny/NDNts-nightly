import type { FwFace } from "@ndn/fw";
import type { connect } from "./connect";
export declare const fetch: typeof globalThis.fetch;
export declare const FCH_ALWAYS_CAPABILITIES: string[];
export declare function createFace(host: string, { fw, connectTimeout, }: connect.Options): Promise<FwFace>;
export declare function getDefaultGateway(): Promise<string>;
