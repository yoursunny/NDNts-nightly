import { FwFace } from "@ndn/fw";
import { connect } from "./connect";
import { queryFch } from "./fch";
/**
 * Connect to the NDN research testbed.
 * @see https://named-data.net/ndn-testbed/
 */
export declare function connectToTestbed(opts?: connectToTestbed.Options): Promise<FwFace[]>;
export declare namespace connectToTestbed {
    interface Options extends queryFch.Options, connect.Options {
        /** List of routers to use in case FCH request fails. */
        fchFallback?: string[];
        /** Maximum number of faces to establish. */
        count?: number;
        /** Consider default IPv4 gateway as a candidate. */
        tryDefaultGateway?: boolean;
        /** Choose one face with fastest testConnection completion and close others. */
        preferFastest?: boolean;
    }
}
