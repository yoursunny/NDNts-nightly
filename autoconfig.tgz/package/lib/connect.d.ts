import { Forwarder, FwFace } from "@ndn/fw";
import { Name } from "@ndn/packet";
/** Connect to a router and test the connection. */
export declare function connect(host: string, opts?: connect.Options): Promise<connect.Result>;
export declare namespace connect {
    type PreferProtocol = "udp" | "tcp" | "ws";
    interface Options {
        fw?: Forwarder;
        /** Prefer one transport protocol over others. */
        preferProtocol?: PreferProtocol;
        /** Override MTU of datagram faces. */
        mtu?: number;
        /** Connect timeout (in milliseconds). */
        connectTimeout?: number;
        /** Test that the face can reach a given name, or provide custom tester function. */
        testConnection?: Name | ((face: FwFace) => Promise<any>);
        /** Routes to be added on the create face. Default is ["/"]. */
        addRoutes?: Name[];
    }
    interface Result {
        /** Created face */
        face: FwFace;
        /** Execution duration of testConnection function. */
        testConnectionDuration: number;
        /** Return value from custom testConnection function. */
        testConnectionResult: unknown;
    }
}
