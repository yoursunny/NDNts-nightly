import type { Name } from "@ndn/packet";
import { DataStore as S } from "@ndn/repo-api";
import { PyRepoClient } from "./client.js";
/**
 * A DataStore implementation using ndn-python-repo.
 *
 * @remarks
 * This DataStore is write-only. It can insert and delete data in ndn-python-repo.
 *
 * This DataStore does not have methods to read data. To read data in ndn-python-repo, send an
 * Interest to the network, and then ndn-python-repo itself can reply.
 * If you really need a readable DataStore, refer to {@link @ndn/repo-api!ReadFromNetwork}.
 */
export declare class PyRepoStore implements Disposable, S.Insert, S.Delete {
    /** Construct with internal {@link PyRepoClient}. */
    constructor(opts: PyRepoStore.Options);
    /**
     * Construct with existing {@link PyRepoClient}.
     *
     * @remarks
     * The passed `client` will not be disposed when this store is disposed.
     */
    constructor(client: PyRepoClient, opts?: PyRepoStore.StoreOptions);
    readonly client: PyRepoClient;
    private readonly ownsClient;
    private readonly insertPOpts;
    private readonly preCommandDelay;
    private readonly incomingInterestTimeout;
    private readonly postRetrievalDelay;
    [Symbol.dispose](): void;
    /** Insert some Data packets. */
    insert(...args: S.Insert.Args<{}>): Promise<void>;
    /** Delete some Data packets. */
    delete(...names: Name[]): Promise<void>;
}
export declare namespace PyRepoStore {
    interface StoreOptions {
        /**
         * How long to allow for prefix announcement before sending command, in milliseconds.
         * @defaultValue 100
         */
        preCommandDelay?: number;
        /**
         * How long to wait for incoming Interest during insertion, in milliseconds.
         * @defaultValue 5000
         */
        incomingInterestTimeout?: number;
        /**
         * How long to allow for retransmissions after finishing command, in milliseconds.
         * @defaultValue 100
         */
        postRetrievalDelay?: number;
    }
    interface Options extends PyRepoClient.Options, StoreOptions {
    }
}
