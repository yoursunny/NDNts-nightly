import { Interest, Name } from "@ndn/packet";
import type { Arrayable } from "type-fest";
import { PrpsPublisher } from "./prps/mod.js";
/** Client to interact with ndn-python-repo. */
export declare class PyRepoClient implements Disposable {
    constructor(opts: PyRepoClient.Options);
    readonly repoPrefix: Name;
    private readonly publisher;
    private readonly fwHint;
    private readonly combineRange;
    private readonly commandLengthLimit;
    private readonly commandTimeout;
    private readonly checkInterval;
    private readonly checkOpts;
    get cpOpts(): {
        modifyInterest?: Interest.Modify | undefined;
        retx?: import("@ndn/endpoint").RetxPolicy | undefined;
        verifier?: import("@ndn/packet").Verifier | undefined;
        describe?: string | undefined;
        signal?: AbortSignal | undefined;
        routeCapture?: boolean | undefined;
        announcement?: import("@ndn/endpoint").ProducerOptions.RouteAnnouncement | undefined;
        concurrency?: number | undefined;
        dataSigner?: import("@ndn/packet").Signer | undefined;
        dataBuffer?: import("@ndn/endpoint").DataBuffer | undefined;
        autoBuffer?: boolean | undefined;
        fw: import("@ndn/fw").Forwarder;
    };
    [Symbol.dispose](): void;
    /** Insert packet(s). */
    insert(objs: Name | Arrayable<PyRepoClient.ObjectParam>): Promise<void>;
    /** Delete packet(s). */
    delete(objs: Name | Arrayable<PyRepoClient.ObjectParam>): Promise<void>;
    private submit;
    private request;
}
export declare namespace PyRepoClient {
    /** {@link PyRepoClient} constructor options. */
    interface Options extends PrpsPublisher.Options {
        /**
         * Name prefix of the repo instance.
         *
         * @remarks
         * This corresponds to **ndn-python-repo.conf** `.repo_config.repo_name` key.
         */
        repoPrefix: Name;
        /**
         * If true, attempt to combine consecutive parameters into {@link RangeParam}.
         * @defaultValue false
         */
        combineRange?: boolean;
        /**
         * Maximum TLV-LENGTH of each RepoCommandParam.
         * @defaultValue 6144
         */
        commandLengthLimit?: number;
        /**
         * Maximum duration of each command in milliseconds.
         * @defaultValue 60 seconds
         */
        commandTimeout?: number;
        /**
         * How often to check command progress in milliseconds.
         * @defaultValue 1 second
         */
        checkInterval?: number;
    }
    /** Single packet parameters. */
    interface SingleParam {
        name: Name;
        registerPrefix?: Name;
    }
    /** Segment range parameters. */
    interface RangeParam {
        name: Name;
        start: number;
        end?: number;
        registerPrefix?: Name;
    }
    /** Either single packet parameters or segment range parameters. */
    type ObjectParam = SingleParam | RangeParam;
}
