import { ConsumerOptions, ProducerOptions } from "@ndn/endpoint";
import { Data, Name, type Signer } from "@ndn/packet";
import { type Encodable } from "@ndn/tlv";
import type { SetRequired } from "type-fest";
type Item = Encodable | PrpsPublisher.PublicationCallback;
/** ndn-python-repo PubSub protocol publisher. */
export declare class PrpsPublisher implements Disposable {
    constructor({ cpOpts, pubPrefix, pubFwHint, pubAnnouncement, pubSigner, notifyInterestLifetime, }?: PrpsPublisher.Options);
    readonly cpOpts: SetRequired<ConsumerOptions & ProducerOptions, "fw">;
    readonly pubPrefix: Name;
    readonly pubFwHint?: Name;
    private readonly pubSigner;
    private readonly notifyOpts;
    private readonly msgProducer;
    private readonly pendings;
    [Symbol.dispose](): void;
    /**
     * Publish an item.
     * @param topic - Topic name.
     * @param item - An Encodable to be published, or a function to generate one.
     * @returns Promise that resolves when the publication has reached a subscriber.
     */
    publish(topic: Name, item: Item): Promise<void>;
    private readonly handleMsgInterest;
}
export declare namespace PrpsPublisher {
    interface Options {
        /**
         * Consumer and producer options.
         *
         * @remarks
         * - `.fw` may be specified.
         * - Most other fields are overridden.
         */
        cpOpts?: ConsumerOptions & ProducerOptions;
        /**
         * Name prefix of the local application.
         * @defaultValue "/localhost" + random-suffix
         */
        pubPrefix?: Name;
        /** Forwarding hint of the local application. */
        pubFwHint?: Name;
        /**
         * Prefix announcement to receive msg Interests.
         * @defaultValue `.pubFwHint ?? .pubPrefix`
         */
        pubAnnouncement?: Name | false;
        /**
         * Key to sign publications.
         * @defaultValue `digestSigning`
         *
         * @remarks
         * This key should be trusted to sign objects under pubPrefix.
         * This may overridden on a per-publication basis by PublicationCallback returning Data.
         */
        pubSigner?: Signer;
        /** InterestLifetime of notify Interests. */
        notifyInterestLifetime?: number;
    }
    /**
     * A callback function to generate publication packet.
     * @param name - Expected Data name.
     * @param topic - Topic name.
     * @returns Either a Data that is already signed, or an Encodable to use as publication body.
     */
    type PublicationCallback = (name: Name, topic: Name) => Promise<Data | Encodable>;
}
export {};
