import { Component, Interest, type Name } from "@ndn/packet";
export declare const MsgSuffix: Component;
export declare const NotifySuffix: Component;
declare const NotifyAppParam_base: (new () => {
    nonce: Uint8Array<ArrayBufferLike>;
    publisher: Name;
    publisherFwHint?: Name | undefined;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<NotifyAppParam>;
/** ndn-python-repo PubSub NotifyAppParam struct. */
export declare class NotifyAppParam extends NotifyAppParam_base {
    /** Create a message Interest from enclosed publisher information. */
    makeMsgInterest(topic: Name): Interest;
}
export {};
