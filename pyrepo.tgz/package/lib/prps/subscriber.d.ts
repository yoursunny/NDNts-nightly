import { ConsumerOptions, ProducerOptions, type RetxPolicy } from "@ndn/endpoint";
import { Data, type Name, type Signer, type Verifier } from "@ndn/packet";
import type { Subscriber, Subscription } from "@ndn/sync-api";
/** ndn-python-repo PubSub protocol subscriber. */
export declare class PrpsSubscriber implements Subscriber<Name, PrpsSubscriber.Update> {
    constructor({ cpOpts, msgInterestLifetime, msgRetx, pubVerifier, subAnnouncement, subSigner, }?: PrpsSubscriber.Options);
    private readonly cpOpts;
    private readonly msgInterestLifetime;
    private readonly msgRetx;
    private readonly pubVerifier?;
    private readonly subAnnouncement?;
    private readonly subSigner;
    subscribe(topic: Name): Subscription<Name, PrpsSubscriber.Update>;
}
export declare namespace PrpsSubscriber {
    interface Options {
        /**
         * Consumer and producer options.
         *
         * @remarks
         * - `.fw` may be specified.
         * - Most other fields are overridden.
         */
        cpOpts?: ConsumerOptions & ProducerOptions;
        /** InterestLifetime of msg Interests. */
        msgInterestLifetime?: number;
        /**
         * Retransmission policy of msg Interests.
         * @defaultValue 2 retransmissions
         */
        msgRetx?: RetxPolicy;
        /**
         * Verifier for publications.
         * @defaultValue no verification
         */
        pubVerifier?: Verifier;
        /**
         * Set to false to disable prefix announcements for receiving notify Interests.
         *
         * @remarks
         * This should be set only if the application already has a prefix announcement that covers
         * the `topic` of each subscription.
         */
        subAnnouncement?: false;
        /**
         * Key to sign notify Data.
         * @defaultValue `digestSigning`
         */
        subSigner?: Signer;
    }
    type Update = CustomEvent<Data>;
}
