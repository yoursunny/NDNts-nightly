import { Component } from "@ndn/packet";
export interface Verb {
    action: Component;
    check: Component;
}
export declare const InsertVerb: {
    action: Component;
    check: Component;
};
export declare const DeleteVerb: {
    action: Component;
    check: Component;
};
declare const ObjectParam_base: (new () => {
    name: import("@ndn/packet").Name;
    fwHint?: import("@ndn/packet").Name | undefined;
    startBlockId?: number | undefined;
    endBlockId?: number | undefined;
    registerPrefix?: import("@ndn/packet").Name | undefined;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<ObjectParam>;
/** ndn-python-repo ObjectParam struct. */
export declare class ObjectParam extends ObjectParam_base {
}
declare const ObjectResult_base: (new () => {
    name: import("@ndn/packet").Name;
    statusCode: number;
    insertNum?: number | undefined;
    deleteNum?: number | undefined;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<ObjectResult>;
/** ndn-python-repo ObjectResult struct. */
export declare class ObjectResult extends ObjectResult_base {
}
declare const CommandParam_base: (new () => {
    objectParams: ObjectParam[];
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<CommandParam>;
/** ndn-python-repo RepoCommandParam struct. */
export declare class CommandParam extends CommandParam_base {
}
declare const CommandRes_base: (new () => {
    statusCode: number;
    objectResults: ObjectResult[];
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<CommandRes>;
/** ndn-python-repo RepoCommandRes struct. */
export declare class CommandRes extends CommandRes_base {
}
declare const StatQuery_base: (new () => {
    requestDigest: Uint8Array;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<StatQuery>;
/** ndn-python-repo RepoStatQuery struct. */
export declare class StatQuery extends StatQuery_base {
}
export {};
