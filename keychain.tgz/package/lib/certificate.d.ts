import { type Component, Data, type Name, type Signer, ValidityPeriod } from "@ndn/packet";
import type { CryptoAlgorithm, NamedSigner, PublicKey } from "./key/mod.js";
/**
 * NDN Certificate v2.
 *
 * @remarks
 * This type is immutable.
 */
export declare class Certificate {
    readonly data: Data;
    readonly validity: ValidityPeriod;
    /**
     * Construct Certificate from Data packet.
     *
     * @throws Error
     * Thrown if the Data packet is not a certificate.
     */
    static fromData(data: Data): Certificate;
    private constructor();
    /** Certificate name aka Data packet name. */
    get name(): Name;
    /** KeyLocator name, if present. */
    get issuer(): Name | undefined;
    /**
     * Whether this is a self-signed certificate.
     *
     * @remarks
     * A certificate is considered self-signed if its issuer key name is same as the certificate's
     * key name, i.e. they are the same key.
     */
    get isSelfSigned(): boolean;
    /**
     * Ensure certificate is within validity period.
     *
     * @throws Error
     * Certificate has expired as of `now`.
     */
    checkValidity(now?: ValidityPeriod.TimestampInput): void;
    /** Public key in SubjectPublicKeyInfo (SPKI) binary format. */
    get publicKeySpki(): Uint8Array;
    /**
     * Import SPKI as public key.
     * @param algoList - Algorithm list, such as {@link SigningAlgorithmListSlim}.
     */
    importPublicKey<I, A extends CryptoAlgorithm<I>>(algoList: readonly A[]): Promise<[A, CryptoAlgorithm.PublicKey<I>]>;
}
export declare namespace Certificate {
    /** {@link Certificate.build} options. */
    interface BuildOptions {
        /** Certificate name. */
        name: Name;
        /**
         * Certificate packet FreshnessPeriod.
         * @defaultValue 1 hour
         */
        freshness?: number;
        /** ValidityPeriod. */
        validity: ValidityPeriod;
        /** Public key in SubjectPublicKeyInfo (SPKI) binary format. */
        publicKeySpki: Uint8Array;
        /** Issuer signing key. */
        signer: Signer;
    }
    /** Build a certificate from fields. */
    function build({ name, freshness, validity, publicKeySpki, signer, }: BuildOptions): Promise<Certificate>;
    /** {@link Certificate.issue} options. */
    interface IssueOptions {
        /**
         * Certificate packet FreshnessPeriod.
         * @defaultValue 1 hour
         */
        freshness?: number;
        /** ValidityPeriod. */
        validity: ValidityPeriod;
        /** IssuerId in certificate name. */
        issuerId: Component;
        /** Issuer signing key. */
        issuerPrivateKey: Signer;
        /** Public key to appear in certificate. */
        publicKey: PublicKey;
    }
    /** Create a certificated signed by issuer. */
    function issue(opts: IssueOptions): Promise<Certificate>;
    /** {@link Certificate.selfSign} options. */
    interface SelfSignOptions {
        /**
         * Certificate packet FreshnessPeriod.
         * @defaultValue 1 hour
         */
        freshness?: number;
        /**
         * ValidityPeriod
         * @defaultValue `ValidityPeriod.MAX`
         */
        validity?: ValidityPeriod;
        /** Private key corresponding to public key. */
        privateKey: NamedSigner;
        /** Public key to appear in certificate. */
        publicKey: PublicKey;
    }
    /** Create a self-signed certificate. */
    function selfSign(opts: SelfSignOptions): Promise<Certificate>;
}
