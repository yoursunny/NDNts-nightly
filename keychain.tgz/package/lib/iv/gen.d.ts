import type { LLEncrypt } from "@ndn/packet";
/**
 * Initialization Vector generator.
 *
 * @remarks
 * The `.wrap()` method creates an {@link LLEncrypt.Key} or {@link LLEncrypt} that generates an
 * IV for each message before encryption, and updates the internal state of this class after
 * encryption. Typically, a separate IVGen instance should be used for each key.
 *
 * If a message presented for encryption already has an IV associated, it would bypass this class.
 * In that case, the IV is not checked and the internal state is not updated.
 */
export declare abstract class IvGen {
    readonly ivLength: number;
    constructor(ivLength: number);
    wrap<T extends LLEncrypt.Key>(key: T): T;
    wrap(f: LLEncrypt): LLEncrypt;
    private wrapKey;
    private wrapLLEncrypt;
    /** Generate IV for next message. */
    protected abstract generate(): Uint8Array;
    /** Update internal state after a message is encrypted.. */
    protected update(plaintextLength: number, ciphertextLength: number): void;
}
