import { IvGen } from "./gen.js";
/** IV generator using all random bits. */
export declare class RandomIvGen extends IvGen {
    protected generate(): Uint8Array;
}
