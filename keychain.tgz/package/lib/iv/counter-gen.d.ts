import { type CounterIvOptions } from "./counter-common.js";
import { IvGen } from "./gen.js";
/**
 * Generate Initialization Vectors using fixed+random+counter structure.
 * @see {@link CounterIvOptions} for expected IV structure.
 */
export declare class CounterIvGen extends IvGen {
    constructor(opts: CounterIvGen.Options);
    private readonly ivPrefix;
    private readonly ci;
    protected generate(): Uint8Array;
    protected update(plaintextLength: number, ciphertextLength: number): void;
}
export declare namespace CounterIvGen {
    interface Options extends CounterIvOptions {
    }
}
