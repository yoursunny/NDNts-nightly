import type { LLDecrypt } from "@ndn/packet";
/**
 * Initialization Vector checker.
 *
 * @remarks
 * The `.wrap()` method creates an {@link LLDecrypt.Key} or {@link LLDecrypt} that checks the IV in
 * each message before and after decryption, and updates the internal state of this class.
 * Typically, a separate IvChecker instance should be used for each key.
 */
export declare abstract class IvChecker {
    readonly ivLength: number;
    constructor(ivLength: number);
    wrap<T extends LLDecrypt.Key>(key: T): T;
    wrap(f: LLDecrypt): LLDecrypt;
    private wrapKey;
    private wrapLLDecrypt;
    /** Check IV for incoming message and update internal state. */
    protected abstract check(iv: Uint8Array, plaintextLength: number, ciphertextLength: number): void;
}
