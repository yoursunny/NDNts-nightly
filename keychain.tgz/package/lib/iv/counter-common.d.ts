/**
 * Options for Initialization Vectors using fixed+random+counter structure.
 *
 * IVs following this construction method have three parts:
 * 1. fixed bits, specified in options.
 * 2. random bits, different for each key and in each session.
 * 3. counter bits, monotonically increasing for each plaintext/ciphertext block.
 */
export interface CounterIvOptions {
    /** IV length in octets. */
    ivLength: number;
    /**
     * Number of fixed bits.
     * @defaultValue 0
     */
    fixedBits?: number;
    /**
     * Fixed portion.
     *
     * @remarks
     * Required if fixedBits is positive.
     * This may be specified as a bigint or a Uint8Array.
     * If it's a Uint8Array, it must have at least fixedBits bits.
     * The least significant bits are taken.
     */
    fixed?: bigint | Uint8Array;
    /** Number of counter bits. */
    counterBits: number;
    /**
     * Crypto algorithm block size in octets.
     * If plaintext and ciphertext have different lengths, the longer length is considered.
     */
    blockSize: number;
}
export declare function parseCounterIvOptions({ ivLength, fixedBits, fixed: fixedInput, counterBits, }: CounterIvOptions): parseCounterIvOptions.Result;
export declare namespace parseCounterIvOptions {
    interface Result {
        ivBits: number;
        fixedBits: number;
        fixedMask: bigint;
        fixed: bigint;
        randomBits: number;
        randomMask: bigint;
        random: bigint;
        counterMask: bigint;
        maxCounter: bigint;
    }
}
export declare function throwCounterIvErrorIf(cond: boolean): void;
export declare class CounterIncrement {
    private readonly maxCounter;
    constructor(blockSize: number, maxCounter: bigint);
    readonly blockSize: bigint;
    counter: bigint;
    appendBlocks(plaintextLength: number, ciphertextLength: number): void;
}
