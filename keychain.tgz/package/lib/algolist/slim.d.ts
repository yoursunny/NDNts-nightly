import type { CryptoAlgorithm, EncryptionAlgorithm, SigningAlgorithm } from "../key/mod.js";
/**
 * A slim list of signing algorithms.
 *
 * @remarks
 * The *slim* list contains only the most commonly used algorithms, to reduce bundle size.
 * This list currently contains {@link ECDSA}.
 * If you need more algorithms, explicitly import them or use {@link SigningAlgorithmListFull}.
 */
export declare const SigningAlgorithmListSlim: readonly SigningAlgorithm[];
/**
 * A slim list of encryption algorithms.
 *
 * @remarks
 * The *slim* list contains only the most commonly used algorithms, to reduce bundle size.
 * This list is currently empty.
 * If you need more algorithms, explicitly import them or use {@link EncryptionAlgorithmListFull}.
 */
export declare const EncryptionAlgorithmListSlim: readonly EncryptionAlgorithm[];
/**
 * A slim list of crypto algorithms.
 *
 * @remarks
 * The *slim* list contains only the most commonly used algorithms, to reduce bundle size.
 * This list encompasses {@link SigningAlgorithmListSlim} and {@link EncryptionAlgorithmListSlim}.
 * If you need more algorithms, explicitly import them or use {@link CryptoAlgorithmListFull}.
 */
export declare const CryptoAlgorithmListSlim: readonly CryptoAlgorithm[];
