import type { LLEncrypt, Name } from "@ndn/packet";
import type { Certificate } from "../certificate.js";
import { type ImportCertOptions } from "./impl-import-cert.js";
import { type CryptoAlgorithm, type EncryptionAlgorithm, type NamedEncrypter } from "./types.js";
/**
 * Create a plain encrypter from crypto key.
 * @param algo - Encryption algorithm.
 * @param key - Public key or secret key, which must match `algo`.
 */
export declare function createEncrypter<I>(algo: EncryptionAlgorithm<I>, key: CryptoAlgorithm.PublicSecretKey<I>): LLEncrypt.Key;
/**
 * Create a named encrypter from crypto key.
 * @param name - Key name.
 * @param algo - Encryption algorithm.
 * @param key - Public key or secret key, which must match `algo`.
 */
export declare function createEncrypter<I, Asym extends boolean>(name: Name, algo: EncryptionAlgorithm<I, Asym>, key: CryptoAlgorithm.PublicSecretKey<I>): NamedEncrypter<Asym>;
/**
 * Create a named encrypter from the public key in a certificate.
 * @param cert - Certificate.
 * @param opts - Certificate import options.
 */
export declare function createEncrypter(cert: Certificate, opts?: ImportCertOptions<EncryptionAlgorithm>): Promise<NamedEncrypter.PublicKey>;
