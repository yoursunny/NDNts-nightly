import type { Name, ValidityPeriod } from "@ndn/packet";
import type { Certificate } from "../certificate.js";
import type { CryptoAlgorithm } from "./types.js";
export declare function isPublicSecretKey(obj: unknown): obj is CryptoAlgorithm.PublicSecretKey;
/** Certificate import options for {@link createVerifier} and {@link createDecrypter}. */
export interface ImportCertOptions<A extends CryptoAlgorithm> {
    /**
     * List of recognized algorithms.
     * @defaultValue SigningAlgorithmListSlim or EncryptionAlgorithmListSlim
     *
     * @remarks
     * {@link SigningAlgorithmListSlim} and {@link EncryptionAlgorithmListSlim} only contain a subset
     * of available signing and encryption algorithms. Use {@link SigningAlgorithmListFull} and
     * {@link EncryptionAlgorithmListFull} for all algorithms, at the cost of larger bundle size.
     */
    algoList?: readonly A[];
    /**
     * Whether to check certificate ValidityPeriod.
     * If `true`, throws an error if `.now` is not within ValidityPeriod.
     * @defaultValue true
     */
    checkValidity?: boolean;
    /**
     * Current timestamp for checking ValidityPeriod.
     * @defaultValue `Date.now()`
     */
    now?: ValidityPeriod.TimestampInput;
}
export declare class ImportCertCached<T, A extends CryptoAlgorithm> {
    private readonly ImportedType;
    private readonly defaultAlgoList;
    constructor(ImportedType: new (keyName: Name, algo: A, key: CryptoAlgorithm.PublicSecretKey) => T, defaultAlgoList: readonly A[]);
    private readonly cache;
    importCert(cert: Certificate, { algoList, checkValidity, now, }: ImportCertOptions<A>): Promise<T>;
}
