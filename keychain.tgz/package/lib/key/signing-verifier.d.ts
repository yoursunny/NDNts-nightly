import { type Name, Verifier } from "@ndn/packet";
import type { Certificate } from "../certificate.js";
import { type ImportCertOptions } from "./impl-import-cert.js";
import { type CryptoAlgorithm, type NamedVerifier, type SigningAlgorithm } from "./types.js";
/**
 * Create a plain verifier from crypto key.
 * @param algo - Signing algorithm.
 * @param key - Public key or secret key, which must match `algo`.
 */
export declare function createVerifier<I>(algo: SigningAlgorithm<I>, key: CryptoAlgorithm.PublicSecretKey<I>): Verifier;
/**
 * Create a named verifier from crypto key.
 * @param name - Key name.
 * @param algo - Signing algorithm.
 * @param key - Public key or secret key, which must match `algo`.
 */
export declare function createVerifier<I, Asym extends boolean>(name: Name, algo: SigningAlgorithm<I, Asym>, key: CryptoAlgorithm.PublicSecretKey<I>): NamedVerifier<Asym>;
/**
 * Create a named verifier from the public key in a certificate.
 * @param cert - Certificate.
 * @param opts - Certificate import options.
 */
export declare function createVerifier(cert: Certificate, opts?: ImportCertOptions<SigningAlgorithm>): Promise<NamedVerifier.PublicKey>;
