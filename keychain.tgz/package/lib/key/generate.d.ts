import { Name } from "@ndn/packet";
import { CryptoAlgorithm } from "./types";
export declare function generateKeyInternal<Algo extends CryptoAlgorithm>(defaultAlgo: Algo, a: unknown[]): Promise<[Name, Algo, CryptoAlgorithm.GeneratedKeyPair | CryptoAlgorithm.GeneratedSecretKey]>;
