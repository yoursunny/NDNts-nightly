import { Name, NameLike, Signer, Verifier } from "@ndn/packet";
import type { KeyChain } from "../store/mod";
import { CryptoAlgorithm, NamedSigner, NamedVerifier, SigningAlgorithm } from "./types";
/** Create a plain signer from crypto key. */
export declare function createSigner<I>(algo: SigningAlgorithm<I>, key: CryptoAlgorithm.PrivateSecretKey<I>): Signer;
/** Create a named signer from crypto key. */
export declare function createSigner<I, Asym extends boolean>(name: Name, algo: SigningAlgorithm<I, Asym>, key: CryptoAlgorithm.PrivateSecretKey<I>): NamedSigner<Asym>;
/** Create a plain verifier from crypto key. */
export declare function createVerifier<I>(algo: SigningAlgorithm<I>, key: CryptoAlgorithm.PublicSecretKey<I>): Verifier;
/** Create a named verifier from crypto key. */
export declare function createVerifier<I, Asym extends boolean>(name: Name, algo: SigningAlgorithm<I, Asym>, key: CryptoAlgorithm.PublicSecretKey<I>): NamedVerifier<Asym>;
declare type SigningOptG<I, Asym extends boolean, G> = {} extends G ? [SigningAlgorithm<I, Asym, G>, G?] : [SigningAlgorithm<I, Asym, G>, G];
/** Generate a pair of signer and verifier with the default ECDSA signing algorithm. */
export declare function generateSigningKey(name: NameLike): Promise<[NamedSigner.PrivateKey, NamedVerifier.PublicKey]>;
/** Generate a pair of signer and verifier with the default ECDSA signing algorithm, and save to KeyChain. */
export declare function generateSigningKey(keyChain: KeyChain, name: NameLike): Promise<[NamedSigner.PrivateKey, NamedVerifier.PublicKey]>;
/** Generate a pair of signer and verifier. */
export declare function generateSigningKey<I, Asym extends boolean, G>(name: NameLike, ...a: SigningOptG<I, Asym, G>): Promise<[NamedSigner<Asym>, NamedVerifier<Asym>]>;
/** Generate a pair of signer and verifier, and save to KeyChain. */
export declare function generateSigningKey<I, Asym extends boolean, G>(keyChain: KeyChain, name: NameLike, ...a: SigningOptG<I, Asym, G>): Promise<[NamedSigner<Asym>, NamedVerifier<Asym>]>;
export {};
