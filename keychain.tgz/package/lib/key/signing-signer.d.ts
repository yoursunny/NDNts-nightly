import { type Name, Signer } from "@ndn/packet";
import { type CryptoAlgorithm, type NamedSigner, type SigningAlgorithm } from "./types.js";
/**
 * Create a plain signer from crypto key.
 * @param algo - Signing algorithm.
 * @param key - Private key or secret key, which must match `algo`.
 */
export declare function createSigner<I>(algo: SigningAlgorithm<I>, key: CryptoAlgorithm.PrivateSecretKey<I>): Signer;
/**
 * Create a named signer from crypto key.
 * @param name - Key name.
 * @param algo - Signing algorithm.
 * @param key - Private key or secret key, which must match `algo`.
 */
export declare function createSigner<I, Asym extends boolean>(name: Name, algo: SigningAlgorithm<I, Asym>, key: CryptoAlgorithm.PrivateSecretKey<I>): NamedSigner<Asym>;
