import type { CryptoAlgorithm } from "../key/mod.js";
import { CertStore } from "./cert-store.js";
import { KeyStore } from "./key-store.js";
export declare function openStores(locator: string, algoList: readonly CryptoAlgorithm[]): [KeyStore, CertStore];
