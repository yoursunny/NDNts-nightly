import { CertStore } from "./cert-store";
import { KeyStore } from "./key-store";
export declare function openStores(locator: string): [KeyStore, CertStore];
