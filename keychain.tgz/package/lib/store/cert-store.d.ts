import { Name } from "@ndn/packet";
import { Certificate } from "../cert/mod";
import { StoreBase } from "./store-base";
interface StoredCert {
    certBuffer: Uint8Array | string;
}
/** Storage of certificates. */
export declare class CertStore extends StoreBase<StoredCert> {
    get(name: Name): Promise<Certificate>;
    insert(cert: Certificate): Promise<void>;
}
export {};
