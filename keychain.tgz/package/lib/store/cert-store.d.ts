import { type Name } from "@ndn/packet";
import { Certificate } from "../certificate.js";
import { StoreBase } from "./store-base.js";
interface StoredCert {
    certBuffer: Uint8Array | string;
}
/** KV store of certificates. */
export declare class CertStore extends StoreBase<StoredCert> {
    get(name: Name): Promise<Certificate>;
    insert(cert: Certificate): Promise<void>;
}
export {};
