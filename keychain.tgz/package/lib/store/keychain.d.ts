import { Name, Signer } from "@ndn/packet";
import type { Certificate } from "../cert/mod";
import { CertStore } from "./cert-store";
import { KeyStore } from "./key-store";
/** Storage of own private keys and certificates. */
export declare abstract class KeyChain {
    /** Return whether insertKey function expects JsonWebKey instead of CryptoKey. */
    abstract readonly needJwk: boolean;
    /** List keys, filtered by name prefix. */
    abstract listKeys(prefix?: Name): Promise<Name[]>;
    /** Retrieve key pair by key name. */
    abstract getKeyPair(name: Name): Promise<KeyChain.KeyPair>;
    /**
     * Retrieve key by key name.
     * @param typ "signer", "verifier", etc
     */
    getKey<K extends keyof KeyChain.KeyPair>(name: Name, typ: K): Promise<KeyChain.KeyPair[K]>;
    /** Insert key pair. */
    abstract insertKey(name: Name, stored: KeyStore.StoredKey): Promise<void>;
    /** Delete key pair and associated certificates. */
    abstract deleteKey(name: Name): Promise<void>;
    /** List certificates, filtered by name prefix. */
    abstract listCerts(prefix?: Name): Promise<Name[]>;
    /** Retrieve certificate by cert name. */
    abstract getCert(name: Name): Promise<Certificate>;
    /** Insert certificate; key must exist. */
    abstract insertCert(cert: Certificate): Promise<void>;
    /** Delete certificate. */
    abstract deleteCert(name: Name): Promise<void>;
    /**
     * Create a signer from keys and certificates in the KeyChain.
     * @param name subject name, key name, or certificate name.
     *
     * @li If name is a certificate name, sign with the corresponding private key,
     *     and use the specified certificate name as KeyLocator.
     * @li If name is a key name, sign with the specified private key.
     *     If a non-self-signed certificate exists for this key, use the certificate name as KeyLocator.
     *     Otherwise, use the key name as KeyLocator.
     * @li If name is neither certificate name nor key name, it is interpreted as a subject name.
     *     A non-self-signed certificate of this subject name is preferred.
     *     If such a certificate does not exist, use any key of this subject name.
     * @li If prefixMatch is true, name can also be interpreted as a prefix of the subject name.
     */
    getSigner(name: Name, { prefixMatch, fallback, useKeyNameKeyLocator }?: KeyChain.GetSignerOptions): Promise<Signer>;
    private findSignerCertName;
}
export declare namespace KeyChain {
    type KeyPair<Asym extends boolean = any> = KeyStore.KeyPair<Asym>;
    /**
     * Create a signer from keys and certificates in the KeyChain.
     * @param name subject name, key name, or certificate name.
     * @param fallback invoked when no matching key or certificate is found.
     * @param useKeyNameKeyLocator force KeyLocator to be key name instead of certificate name.
     *
     * @li If name is a certificate name, sign with the corresponding private key,
     *     and use the specified certificate name as KeyLocator.
     * @li If name is a key name, sign with the specified private key.
     *     If a non-self-signed certificate exists for this key, use the certificate name as KeyLocator.
     *     Otherwise, use the key name as KeyLocator.
     * @li If name is neither certificate name nor key name, it is interpreted as a subject name.
     *     A non-self-signed certificate of this subject name is preferred.
     *     If such a certificate does not exist, use any key of this subject name.
     * @li If prefixMatch is true, name can also be interpreted as a prefix of the subject name.
     */
    interface GetSignerOptions {
        /**
         * If false, name argument must equal subject name, key name, or certificate name.
         * If true, name argument may be a prefix of subject name.
         * Default is false.
         */
        prefixMatch?: boolean;
        /**
         * If a function, it is invoked when no matching key or certificate is found, and should
         * either return a fallback Signer or reject the promise.
         * If a Signer, it is used when no matching key or certificate is found.
         */
        fallback?: Signer | ((name: Name, keyChain: KeyChain, err?: Error) => Promise<Signer>);
        /**
         * If false, KeyLocator is a certificate name when a non-self-signed certificate exists.
         * If true, KeyLocator is the key name.
         * Default is false.
         */
        useKeyNameKeyLocator?: boolean;
    }
    /**
     * Open a persistent keychain.
     * @param locator in Node.js, a filesystem directory; in browser, a database name.
     */
    function open(locator: string): KeyChain;
    /** Open a keychain from given KeyStore and CertStore. */
    function open(keys: KeyStore, certs: CertStore): KeyChain;
    /** Create an in-memory ephemeral keychain. */
    function createTemp(): KeyChain;
}
