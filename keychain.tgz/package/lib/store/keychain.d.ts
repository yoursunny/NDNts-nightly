import { Name, type Signer } from "@ndn/packet";
import type { Promisable } from "type-fest";
import { Mutex } from "wait-your-turn";
import type { Certificate } from "../certificate.js";
import type { CryptoAlgorithm } from "../key/mod.js";
import { CertStore } from "./cert-store.js";
import { KeyStore } from "./key-store.js";
/** Storage of own private keys and certificates. */
export declare abstract class KeyChain {
    /** Return whether `.insertKey()` method expects JsonWebKey instead of CryptoKey. */
    abstract readonly needJwk: boolean;
    /** List keys, filtered by name prefix. */
    abstract listKeys(prefix?: Name): Promise<Name[]>;
    /** Retrieve key pair by key name. */
    abstract getKeyPair(name: Name): Promise<KeyChain.KeyPair>;
    /**
     * Retrieve key by key name.
     * @param typ - "signer", "verifier", etc.
     */
    getKey<K extends keyof KeyChain.KeyPair>(name: Name, typ: K): Promise<KeyChain.KeyPair[K]>;
    /** Insert key pair. */
    abstract insertKey(name: Name, stored: KeyStore.StoredKey): Promise<void>;
    /** Delete key pair and associated certificates. */
    abstract deleteKey(name: Name): Promise<void>;
    /** List certificates, filtered by name prefix. */
    abstract listCerts(prefix?: Name): Promise<Name[]>;
    /** Retrieve certificate by cert name. */
    abstract getCert(name: Name): Promise<Certificate>;
    /**
     * Insert certificate.
     *
     * @remarks
     * Corresponding key must exist.
     */
    abstract insertCert(cert: Certificate): Promise<void>;
    /** Delete certificate. */
    abstract deleteCert(name: Name): Promise<void>;
    /**
     * Create a signer from keys and certificates in the KeyChain.
     * @param name - Subject name, key name, or certificate name.
     *
     * @remarks
     * If `name` is a certificate name, sign with the corresponding private key, and use the
     * specified certificate name as KeyLocator.
     *
     * If `name` is a key name, sign with the specified private key. If a non-self-signed certificate
     * exists for this key, use the certificate name as KeyLocator. Otherwise, use the key name as
     * KeyLocator.
     *
     * If `name` is neither a certificate name nor a key name, it is interpreted as a subject name.
     * A non-self-signed certificate of this subject name is preferred. If no such certificate
     * exists, use any key of this subject name.
     *
     * If `prefixMatch` is true, `name` can also be interpreted as a prefix of the subject name.
     */
    getSigner(name: Name, { prefixMatch, fallback, useKeyNameKeyLocator }?: KeyChain.GetSignerOptions): Promise<Signer>;
    private findSignerCertName;
}
export declare namespace KeyChain {
    type KeyPair<Asym extends boolean = any> = KeyStore.KeyPair<Asym>;
    /** {@link KeyChain.getSigner} options. */
    interface GetSignerOptions {
        /**
         * Whether to allow prefix match between name argument and subject name.
         * @defaultValue false
         *
         * @remarks
         * If `false`, `name` argument must equal subject name, key name, or certificate name.
         * If `true`, `name` argument may be a prefix of subject name.
         */
        prefixMatch?: boolean;
        /**
         * Fallback when no matching or certificate is found.
         *
         * @remarks
         * If this is a function, it is invoked when no matching key or certificate is found. The
         * function should either return a fallback Signer or reject the promise.
         *
         * If this is a Signer, it is used when no matching key or certificate is found.
         */
        fallback?: Signer | GetSignerFallback;
        /**
         * Whether to prefer key name in KeyLocator.
         * @defaultValue false
         *
         * @remarks
         * If `false`, KeyLocator is a certificate name when a non-self-signed certificate exists.
         * If `true`, KeyLocator is the key name.
         */
        useKeyNameKeyLocator?: boolean;
    }
    type GetSignerFallback = (name: Name, keyChain: KeyChain, err?: Error) => Promise<Signer>;
    /**
     * Open a persistent KeyChain.
     * @param locator - Filesystem directory in Node.js; database name in browser.
     * @param algoList - List of recognized algorithms.
     * Default is {@link CryptoAlgorithmListSlim}. Use {@link CryptoAlgorithmListFull} for all
     * algorithms, at the cost of larger bundle size.
     */
    function open(locator: string, algoList?: readonly CryptoAlgorithm[]): KeyChain;
    /** Open a KeyChain from given KeyStore and CertStore. */
    function open(keys: KeyStore, certs: CertStore): KeyChain;
    /**
     * Create an in-memory ephemeral KeyChain.
     * @param algoList - List of recognized algorithms.
     * Default is {@link CryptoAlgorithmListSlim}. Use {@link CryptoAlgorithmListFull} for all
     * algorithms, at the cost of larger bundle size.
     */
    function createTemp(algoList?: readonly CryptoAlgorithm<any, any, any>[]): KeyChain;
}
/**
 * KeyChain adapter that serializes function calls.
 *
 * @remarks
 * Only one `s*` function would be invoked at a time. Do not invoke a non-`s*` function from
 * within an `s*` function, otherwise it would cause a deadlock.
 */
export declare abstract class KeyChainSerialized extends KeyChain {
    protected readonly mutex: Mutex;
    listKeys(prefix?: Name): Promise<Name[]>;
    protected abstract sListKeys(prefix: Name): Promisable<Name[]>;
    getKeyPair(name: Name): Promise<KeyChain.KeyPair>;
    protected abstract sGetKeyPair(name: Name): Promisable<KeyChain.KeyPair>;
    insertKey(name: Name, stored: KeyStore.StoredKey): Promise<void>;
    protected abstract sInsertKey(name: Name, stored: KeyStore.StoredKey): Promisable<void>;
    deleteKey(name: Name): Promise<void>;
    protected abstract sDeleteKey(name: Name): Promisable<void>;
    listCerts(prefix?: Name): Promise<Name[]>;
    protected abstract sListCerts(prefix: Name): Promisable<Name[]>;
    getCert(name: Name): Promise<Certificate>;
    protected abstract sGetCert(name: Name): Promisable<Certificate>;
    insertCert(cert: Certificate): Promise<void>;
    protected abstract sInsertCert(cert: Certificate): Promisable<void>;
    deleteCert(name: Name): Promise<void>;
    protected abstract sDeleteCert(name: Name): Promisable<void>;
}
