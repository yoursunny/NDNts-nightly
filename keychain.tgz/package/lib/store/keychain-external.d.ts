import type { Name } from "@ndn/packet";
import type { Promisable } from "type-fest";
import type { Certificate } from "../certificate.js";
import type { CryptoAlgorithm } from "../key/mod.js";
import { KeyStore } from "./key-store.js";
import { KeyChain, KeyChainSerialized } from "./keychain.js";
/**
 * KeyChain adapter that copies from an external KeyChain.
 */
export declare abstract class KeyChainExternal extends KeyChainSerialized {
    readonly algoList: readonly CryptoAlgorithm[];
    readonly needJwk: boolean;
    private readonly insertKeyLoader;
    private cached?;
    protected constructor(algoList: readonly CryptoAlgorithm[], needJwk?: boolean);
    /** Copy the external KeyChain to `dest`. */
    protected abstract copyTo(dest: KeyChain): Promisable<KeyChain>;
    private load;
    protected sListKeys(prefix: Name): Promise<Name[]>;
    protected sGetKeyPair(name: Name): Promise<KeyChain.KeyPair>;
    protected sInsertKey(name: Name, stored: KeyStore.StoredKey): Promise<void>;
    /** Insert a key pair in external KeyChain. */
    protected abstract eInsertKey(keyPair: KeyStore.KeyPair): Promisable<void>;
    protected sDeleteKey(name: Name): Promise<void>;
    /** Delete a key pair in external KeyChain. */
    protected abstract eDeleteKey(name: Name): Promisable<void>;
    protected sListCerts(prefix: Name): Promise<Name[]>;
    protected sGetCert(name: Name): Promise<Certificate>;
    protected sInsertCert(cert: Certificate): Promise<void>;
    /** Insert a certificate in external KeyChain. */
    protected abstract eInsertCert(cert: Certificate): Promisable<void>;
    protected sDeleteCert(name: Name): Promise<void>;
    /** Delete a certificate in external KeyChain. */
    protected abstract eDeleteCert(name: Name): Promisable<void>;
}
