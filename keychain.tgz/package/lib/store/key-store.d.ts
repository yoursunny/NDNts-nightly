import type { Name } from "@ndn/packet";
import { CryptoAlgorithm, type NamedDecrypter, type NamedEncrypter, type NamedSigner, type NamedVerifier, type PublicKey } from "../key/mod.js";
import { StoreBase, type StoreProvider } from "./store-base.js";
/** KV store of named key pairs. */
export declare class KeyStore extends StoreBase<KeyStore.StoredKey> {
    readonly algoList: readonly CryptoAlgorithm[];
    constructor(provider: StoreProvider<KeyStore.StoredKey>, algoList: readonly CryptoAlgorithm[]);
    private readonly loader;
    get(name: Name): Promise<KeyStore.KeyPair>;
    insert(name: Name, stored: KeyStore.StoredKey): Promise<void>;
}
export declare namespace KeyStore {
    /** Loaded key pair. */
    class KeyPair<Asym extends boolean = any, I = any> {
        readonly name: Name;
        readonly algo: CryptoAlgorithm<I, Asym>;
        readonly pvt: CryptoAlgorithm.PrivateSecretKey<I, Asym>;
        readonly pub: CryptoAlgorithm.PublicSecretKey<I, Asym>;
        constructor(name: Name, algo: CryptoAlgorithm<I, Asym>, pvt: CryptoAlgorithm.PrivateSecretKey<I, Asym>, pub: CryptoAlgorithm.PublicSecretKey<I, Asym>);
        get signer(): NamedSigner<Asym>;
        get verifier(): NamedVerifier<Asym>;
        get encrypter(): NamedEncrypter<Asym>;
        get decrypter(): NamedDecrypter<Asym>;
        get publicKey(): PublicKey;
    }
    /** Stored key pair in JSON or structuredClone-compatible format. */
    interface StoredKey {
        algo: string;
        info: any;
        jwkImportParams?: AlgorithmIdentifier;
        privateKey?: CryptoKey | JsonWebKey;
        publicKey?: CryptoKey | JsonWebKey;
        publicKeySpki?: Uint8Array | string;
        secretKey?: CryptoKey | JsonWebKey;
    }
    /** Helper to load key pair from stored format. */
    class Loader {
        private readonly extractable;
        private readonly algoList;
        constructor(extractable: boolean, algoList: readonly CryptoAlgorithm[]);
        findAlgo(uuid: string): CryptoAlgorithm<unknown> | undefined;
        loadKey(name: Name, stored: StoredKey): Promise<KeyPair>;
        private loadAsymmetric;
        private loadSymmetric;
    }
}
