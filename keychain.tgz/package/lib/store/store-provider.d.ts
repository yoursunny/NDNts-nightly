/** Underlying storage provider. */
export interface StoreProvider<T> {
    /**
     * Indicate whether the storage provider supports the structured clone algorithm.
     * If false, values must be serialized as JSON.
     */
    readonly canSClone: boolean;
    list: () => Promise<string[]>;
    get: (key: string) => Promise<T>;
    insert: (key: string, value: T) => Promise<void>;
    erase: (key: string) => Promise<void>;
}
/** Memory based storage provider. */
export declare class MemoryStoreProvider<T> implements StoreProvider<T> {
    readonly canSClone = true;
    private map;
    list(): Promise<string[]>;
    get(key: string): Promise<T>;
    insert(key: string, value: T): Promise<void>;
    erase(key: string): Promise<void>;
}
