import { Name } from "@ndn/packet";
import type { StoreProvider } from "./store-provider";
export declare abstract class StoreBase<T> {
    private readonly provider;
    private throttle;
    constructor(provider: StoreProvider<T>);
    get canSClone(): boolean;
    /** List item names. */
    list(): Promise<Name[]>;
    /** Erase item by name. */
    erase(name: Name): Promise<void>;
    protected getValue(name: Name): Promise<T>;
    protected insertValue(name: Name, value: T): Promise<void>;
    protected bufferToStorable(input: Uint8Array | string): Uint8Array | string;
}
export declare namespace StoreBase {
    function bufferFromStorable(input: Uint8Array | string): Uint8Array;
}
