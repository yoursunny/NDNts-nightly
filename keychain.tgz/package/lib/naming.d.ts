import { Component, Name } from "@ndn/packet";
/** 'KEY' component. */
export declare const KEY: Component;
/** Default issuerId. */
export declare const ISSUER_DEFAULT: Component;
/** Self-signed issuerId. */
export declare const ISSUER_SELF: Component;
export interface KeyNameFields {
    subjectName: Name;
    keyId: Component;
}
export interface CertNameFields extends KeyNameFields {
    issuerId: Component;
    version: Component;
    keyName: Name;
}
/** Get subject name from subject name, key name, or certificate name. */
export declare function toSubjectName(name: Name): Name;
/** Determine whether the name is a key name. */
export declare function isKeyName(name: Name): boolean;
/** Parse a key name into fields. */
export declare function parseKeyName(name: Name): KeyNameFields;
/**
 * Get key name from key name or certificate name.
 * @throws input name is neither key name nor certificate name.
 */
export declare function toKeyName(name: Name): Name;
/**
 * Create key name from subject name, key name, or certificate name.
 * @param name subject name, key name, or certificate name.
 * @param opts.keyId keyId component, used only if input name is subject name.
 */
export declare function makeKeyName(name: Name, opts?: Partial<Omit<KeyNameFields, "subjectName">>): Name;
/** Determine whether the name is a certificate name. */
export declare function isCertName(name: Name): boolean;
/** Parse a certificate name into fields. */
export declare function parseCertName(name: Name): CertNameFields;
/**
 * Create certificate name from subject name, key name, or certificate name.
 * @param name subject name, key name, or certificate name.
 * @param opts.keyId keyId component, used only if input name is subject name.
 * @param opts.issuerId keyId, used only if input name is subject name.
 * @param opts.version keyId, used only if input name is subject name.
 */
export declare function makeCertName(name: Name, opts?: Partial<Omit<CertNameFields, "subjectName">>): Name;
