import type { EncryptionAlgorithm, SigningAlgorithm } from "../key/mod";
export declare type RsaModulusLength = 2048 | 4096;
export declare namespace RsaModulusLength {
    const Default: RsaModulusLength;
    const Choices: readonly RsaModulusLength[];
}
/** Sha256WithRsa signing algorithm. */
export declare const RSA: SigningAlgorithm<{}, true, RSA.GenParams>;
export declare namespace RSA {
    interface GenParams {
        modulusLength?: RsaModulusLength;
        /** Import PKCS#8 private key and SPKI public key instead of generating. */
        importPkcs8?: [Uint8Array, Uint8Array];
    }
}
/** RSA-OAEP encryption algorithm. */
export declare const RSAOAEP: EncryptionAlgorithm<{}, true, RSA.GenParams>;
