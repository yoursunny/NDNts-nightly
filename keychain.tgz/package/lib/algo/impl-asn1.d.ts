import * as asn1 from "@yoursunny/asn1";
/**
 * Require SubjectPublicKeyInfo.algorithm.algorithm to have specific OID.
 * @param der - SubjectPublicKeyInfo.
 * @param algoName - Textual algorithm name.
 * @param oid - OID hex string (upper case).
 */
export declare function assertSpkiAlgorithm(der: asn1.ElementBuffer, algoName: string, oid: string): void;
/**
 * Convert to ASN.1 PrivateKeyInfo (PKCS#8) format.
 * @param privateKeyAlgorithm - AlgorithmIdentifier elements.
 * @param privateKey - Value of private key.
 * @returns PKCS#8 buffer.
 */
export declare function toPkcs8(privateKeyAlgorithm: string[], privateKey: Uint8Array): Uint8Array;
