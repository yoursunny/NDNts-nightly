import type { LLDecrypt, LLEncrypt } from "@ndn/packet";
import type { IvGen } from "../iv/mod.js";
import type { CryptoAlgorithm, EncryptionAlgorithm } from "../key/mod.js";
/** AES encryption algorithm. */
export interface AesEncryption<I, G extends AesGenParams> extends EncryptionAlgorithm<I, false, G> {
    readonly ivLength: number;
    makeAesKeyGenParams: (genParams: G) => AesKeyGenParams;
}
/** AES key length option. */
export type AesKeyLength = (typeof AesKeyLength.Choices)[number];
export declare namespace AesKeyLength {
    const Default: AesKeyLength;
    const Choices: readonly [128, 192, 256];
}
/** AES key generation parameters. */
export interface AesGenParams {
    length?: AesKeyLength;
    /** Import raw key bits instead of generating. */
    importRaw?: Uint8Array;
}
/** AES block size in octets. */
export declare const AesBlockSize = 16;
export declare abstract class AesCommon<I extends {}, G extends AesGenParams> implements AesEncryption<I, G> {
    protected abstract readonly name: string;
    abstract readonly uuid: string;
    readonly keyUsages: {
        readonly secret: readonly ["encrypt", "decrypt"];
    };
    abstract readonly ivLength: number;
    protected abstract getIvGen(key: CryptoAlgorithm.SecretKey<I>): IvGen;
    protected abstract allowAdditionalData: boolean;
    protected abstract tagSize: number;
    protected abstract defaultInfo: I;
    protected modifyParams(params: any, info: I): void;
    makeAesKeyGenParams({ length }: G): AesKeyGenParams;
    cryptoGenerate(genParams: G, extractable: boolean): Promise<CryptoAlgorithm.GeneratedSecretKey<I>>;
    private check;
    makeLLEncrypt(key: CryptoAlgorithm.SecretKey<I>): LLEncrypt;
    makeLLDecrypt({ secretKey, info }: CryptoAlgorithm.SecretKey<I>): LLDecrypt;
}
