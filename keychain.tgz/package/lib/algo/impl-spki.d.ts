import type * as asn1 from "@yoursunny/asn1";
/**
 * Require SubjectPublicKeyInfo.algorithm.algorithm to have specific OID.
 * @param der - SubjectPublicKeyInfo.
 * @param algoName - Textual algorithm name.
 * @param oid - OID hex string (upper case).
 */
export declare function assertSpkiAlgorithm(der: asn1.ElementBuffer, algoName: string, oid: string): void;
