import type { SigningAlgorithm } from "../key/mod.js";
declare const PointSizes: {
    readonly "P-256": 32;
    readonly "P-384": 48;
    readonly "P-521": 66;
};
export type EcCurve = keyof typeof PointSizes;
export declare namespace EcCurve {
    const Default: EcCurve;
    const Choices: readonly EcCurve[];
}
/** Sha256WithEcdsa signing algorithm. */
export declare const ECDSA: SigningAlgorithm<ECDSA.Info, true, ECDSA.GenParams>;
export declare namespace ECDSA {
    /** Key generation parameters. */
    interface GenParams {
        /**
         * EC curve.
         * @defaultValue P-256
         */
        curve?: EcCurve;
        /** Import PKCS#8 private key and SPKI public key instead of generating. */
        importPkcs8?: [pkcs8: Uint8Array, spki: Uint8Array];
    }
    interface Info {
        curve: EcCurve;
    }
}
export {};
