import * as asn1 from "@yoursunny/asn1";
import type { SigningAlgorithm } from "../key/mod.js";
declare const NamedCurveInfo: {
    readonly "P-256": readonly [32, "2A8648CE3D030107"];
    readonly "P-384": readonly [48, "2B81040022"];
    readonly "P-521": readonly [66, "2B81040023"];
};
export type EcCurve = keyof typeof NamedCurveInfo;
export declare namespace EcCurve {
    const Default: EcCurve;
    const Choices: readonly EcCurve[];
    /** Detect EcCurve from SubjectPublicKeyInfo. */
    function detectFromSpki(der: asn1.ElementBuffer): EcCurve;
}
/** Sha256WithEcdsa signing algorithm. */
export declare const ECDSA: SigningAlgorithm<ECDSA.Info, true, ECDSA.GenParams>;
export declare namespace ECDSA {
    /** Key generation parameters. */
    interface GenParams {
        /**
         * EC curve.
         *
         * @defaultValue
         * During key generation when {@link importPkcs8} is absent, the default is "P-256".
         * During key import when {@link importPkcs8} is specified, this is auto-detected from SPKI.
         */
        curve?: EcCurve;
        /**
         * Import PKCS#8 private key and SPKI public key instead of generating.
         *
         * If {@link curve} is also specified, it must match the SPKI public key.
         */
        importPkcs8?: [pkcs8: Uint8Array, spki: Uint8Array];
        /**
         * Import SEC#1 private key and SPKI public key instead of generating.
         *
         * If {@link curve} is also specified, it must match the SPKI public key.
         * If {@link importPkcs8} is also specified, this field is ignored.
         */
        importSec1?: [sec1: Uint8Array, spki: Uint8Array];
    }
    interface Info {
        curve: EcCurve;
    }
}
export {};
