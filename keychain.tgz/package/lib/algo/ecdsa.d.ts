import type { SigningAlgorithm } from "../key/mod";
declare const PointSizes: {
    "P-256": number;
    "P-384": number;
    "P-521": number;
};
export declare type EcCurve = keyof typeof PointSizes;
export declare namespace EcCurve {
    const Default: EcCurve;
    const Choices: readonly ("P-256" | "P-384" | "P-521")[];
}
/** Sha256WithEcdsa signing algorithm. */
export declare const ECDSA: SigningAlgorithm<ECDSA.Info, true, ECDSA.GenParams>;
export declare namespace ECDSA {
    /** Key generation parameters. */
    interface GenParams {
        curve?: EcCurve;
        /**
         * Import PKCS#8 private key and SPKI public key instead of generating.
         * This cannot handle specificCurve in SPKI.
         */
        importPkcs8?: [Uint8Array, Uint8Array];
    }
    interface Info {
        curve: EcCurve;
    }
}
export {};
