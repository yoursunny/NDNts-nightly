import { type AesEncryption, type AesGenParams } from "./aes-common.js";
/**
 * AES-CTR encryption algorithm.
 *
 * @remarks
 * Initialization Vectors must be 16 octets.
 * During encryption, if IV is unspecified, it is constructed with two parts:
 * 1. 64-bit random number, generated each time a private key instance is constructed.
 * 2. 64-bit counter starting from zero.
 *
 * During decryption, quality of IV is not automatically checked.
 * Since the security of AES-CTR depends on having unique IVs, the application should check IV
 * uniqueness with {@link CounterIvChecker}.
 */
export declare const AESCTR: AesEncryption<AESCTR.Info, AESCTR.GenParams>;
export declare namespace AESCTR {
    interface Info {
        /**
         * Specify number of bits in IV to use as counter.
         * This must be between 1 and 128.
         * @defaultValue 64
         */
        counterLength: number;
    }
    type GenParams = AesGenParams & Partial<Info>;
}
