import { type AesEncryption, type AesGenParams } from "./aes-common.js";
/**
 * AES-GCM encryption algorithm.
 *
 * @remarks
 * Initialization Vectors must be 12 octets.
 * During encryption, if IV is unspecified, it is constructed with two parts:
 * 1. 64-bit random number, generated each time a private key instance is constructed;
 * 2. 32-bit counter starting from zero.
 *
 * During decryption, quality of IV is not automatically checked.
 * Since the security of AES-GCM depends on having unique IVs, the application should check IV
 * uniqueness with {@link CounterIvChecker}.
 */
export declare const AESGCM: AesEncryption<{}, AESGCM.GenParams>;
export declare namespace AESGCM {
    interface GenParams extends AesGenParams {
    }
}
