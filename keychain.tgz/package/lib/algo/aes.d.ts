import { EncryptionAlgorithm } from "../key/mod";
export interface Encryption<I, G extends GenParams> extends EncryptionAlgorithm<I, false, G> {
    readonly ivLength: number;
    makeAesKeyGenParams: (genParams: G) => AesKeyGenParams;
}
export declare type KeyLength = 128 | 192 | 256;
export declare namespace KeyLength {
    const Default: KeyLength;
    const Choices: readonly KeyLength[];
}
/** Key generation parameters. */
export interface GenParams {
    length?: KeyLength;
    /** Import raw key bits instead of generating. */
    importRaw?: Uint8Array;
}
declare type GenParams_ = GenParams;
/** AES block size in octets. */
export declare const blockSize = 16;
/**
 * AES-CBC encryption algorithm.
 *
 * Initialization Vectors must be 16 octets.
 * During encryption, if IV is unspecified, it is randomly generated.
 * During decryption, quality of IV is not checked.
 */
export declare const CBC: Encryption<{}, GenParams>;
/**
 * AES-CTR encryption algorithm.
 *
 * Initialization Vectors must be 16 octets.
 * During encryption, if IV is unspecified, it is constructed with two parts:
 * @li a 64-bit random number, generated each time a private key instance is constructed;
 * @li a 64-bit counter starting from zero.
 *
 * During decryption, quality of IV is not automatically checked.
 * Since the security of AES-CTR depends on having unique IVs, the application is recommended to
 * check IVs using CounterIvChecker type.
 */
export declare const CTR: Encryption<CTR.Info, CTR.GenParams>;
export declare namespace CTR {
    interface Info {
        /**
         * Specify number of bits in IV to use as counter.
         * This must be between 1 and 128. Default is 64.
         */
        counterLength: number;
    }
    type GenParams = GenParams_ & Partial<Info>;
}
/**
 * AES-GCM encryption algorithm.
 *
 * Initialization Vectors must be 12 octets.
 * During encryption, if IV is unspecified, it is constructed with two parts:
 * @li a 64-bit random number, generated each time a private key instance is constructed;
 * @li a 32-bit counter starting from zero.
 *
 * During decryption, quality of IV is not automatically checked.
 * Since the security of AES-CTR depends on having unique IVs, the application is recommended to
 * check IVs using CounterIvChecker type.
 */
export declare const GCM: Encryption<{}, GenParams>;
export {};
