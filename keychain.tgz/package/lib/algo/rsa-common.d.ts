import * as asn1 from "@yoursunny/asn1";
import type { CryptoAlgorithm } from "../key/mod.js";
import type { RSA } from "./rsa.js";
export type RsaModulusLength = (typeof RsaModulusLength.Choices)[number];
export declare namespace RsaModulusLength {
    const Default: RsaModulusLength;
    const Choices: readonly [2048, 4096];
}
export declare abstract class RsaCommon implements CryptoAlgorithm<{}, true, RSA.GenParams> {
    protected readonly name: string;
    constructor(name: string, hash?: AlgorithmIdentifier);
    abstract readonly uuid: string;
    abstract readonly keyUsages: Record<"private" | "public", readonly KeyUsage[]>;
    protected readonly importParams: RsaHashedImportParams;
    protected readonly genParams: RsaHashedKeyGenParams;
    cryptoGenerate({ modulusLength, importPkcs8, importPkcs1 }: RSA.GenParams, extractable: boolean): Promise<{
        privateKey: CryptoKey;
        publicKey: CryptoKey;
        jwkImportParams: RsaHashedImportParams;
        spki: Uint8Array<ArrayBuffer>;
        info: {};
    }>;
    private importPkcs8;
    importSpki(spki: Uint8Array, der: asn1.ElementBuffer): Promise<{
        publicKey: CryptoKey;
        spki: Uint8Array<ArrayBufferLike>;
        info: {};
    }>;
}
