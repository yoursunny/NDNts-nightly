export declare namespace TT {
    const ValidityPeriod = 253;
    const NotBefore = 254;
    const NotAfter = 255;
}
export declare const ContentTypeKEY = 2;
