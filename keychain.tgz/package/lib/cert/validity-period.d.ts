import { SigInfo } from "@ndn/packet";
import { Decoder, Encoder } from "@ndn/tlv";
/** Certificate validity period. */
export declare class ValidityPeriod {
    static decodeFrom(decoder: Decoder): ValidityPeriod;
    constructor();
    constructor(notBefore: ValidityPeriod.TimestampInput, notAfter: ValidityPeriod.TimestampInput);
    notBefore: number;
    notAfter: number;
    encodeTo(encoder: Encoder): void;
    /** Determine whether the specified timestamp is within validity period. */
    includes(t: ValidityPeriod.TimestampInput): boolean;
    /** Determine whether this validity period equals another. */
    equals({ notBefore, notAfter }: ValidityPeriod): boolean;
    /** Compute the intersection of this and other validity periods. */
    intersect(...validityPeriods: ValidityPeriod[]): ValidityPeriod;
    toString(): string;
}
export declare namespace ValidityPeriod {
    type TimestampInput = number | Date;
    const MAX: ValidityPeriod;
    function daysFromNow(n: number): ValidityPeriod;
    function get(si: SigInfo): ValidityPeriod | undefined;
    function set(si: SigInfo, v?: ValidityPeriod): void;
}
