import { Component, Data, Name, Signer } from "@ndn/packet";
import { CryptoAlgorithm, NamedEncrypter, NamedSigner, NamedVerifier, PublicKey } from "../key/mod";
import { ValidityPeriod } from "./validity-period";
/**
 * NDN Certificate v2.
 * This type is immutable.
 */
export declare class Certificate {
    readonly data: Data;
    readonly validity: ValidityPeriod;
    static fromData(data: Data): Certificate;
    private constructor();
    get name(): Name;
    get issuer(): Name | undefined;
    get isSelfSigned(): boolean;
    /** Public key in SubjectPublicKeyInfo (SPKI) binary format. */
    get publicKeySpki(): Uint8Array;
    /** Import SPKI as public key. */
    importPublicKey<I, A extends CryptoAlgorithm<I>>(algoList: readonly A[]): Promise<[A, CryptoAlgorithm.PublicKey<I>]>;
    /** Create verifier from SPKI. */
    createVerifier(): Promise<NamedVerifier.PublicKey>;
    /** Create encrypter from SPKI. */
    createEncrypter(): Promise<NamedEncrypter.PublicKey>;
    private verifier?;
    private encrypter?;
}
export declare namespace Certificate {
    interface BuildOptions {
        name: Name;
        freshness?: number;
        validity: ValidityPeriod;
        publicKeySpki: Uint8Array;
        signer: Signer;
    }
    function build({ name, freshness, validity, publicKeySpki, signer, }: BuildOptions): Promise<Certificate>;
    interface IssueOptions {
        freshness?: number;
        validity: ValidityPeriod;
        issuerId: Component;
        issuerPrivateKey: Signer;
        publicKey: PublicKey;
    }
    function issue(options: IssueOptions): Promise<Certificate>;
    interface SelfSignOptions {
        freshness?: number;
        validity?: ValidityPeriod;
        privateKey: NamedSigner;
        publicKey: PublicKey;
    }
    function selfSign(options: SelfSignOptions): Promise<Certificate>;
}
