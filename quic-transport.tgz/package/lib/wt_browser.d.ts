export declare const supported = true;
export declare function makeWebTransport(uri: string, opts: WebTransportOptions): WebTransport;
