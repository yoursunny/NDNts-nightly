import { L3Face, Transport } from "@ndn/l3face";
/** HTTP/3 transport. */
export declare class H3Transport extends Transport {
    private readonly uri;
    private readonly opts;
    private readonly tr;
    /** Whether current browser supports WebTransport. */
    static readonly supported: boolean;
    /**
     * Create a transport and connect to remote endpoint.
     * @param uri - Server URI.
     * @param opts - WebTransport options.
     */
    static connect(uri: string, opts?: WebTransportOptions): Promise<H3Transport>;
    private constructor();
    /** Report HTTP/3 maximum datagram size as MTU. */
    get mtu(): number;
    readonly rx: Transport.RxIterable;
    tx(iterable: Transport.TxIterable): Promise<void>;
    /** Reopen the transport by connecting again with the same options. */
    reopen(): Promise<H3Transport>;
}
export declare namespace H3Transport {
    /** Create a transport and add to forwarder. */
    const createFace: L3Face.CreateFaceFunc<[uri: string, opts?: WebTransportOptions | undefined]>;
}
