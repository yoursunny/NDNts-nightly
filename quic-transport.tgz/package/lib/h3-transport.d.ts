import { L3Face, Transport } from "@ndn/l3face";
/** HTTP/3 transport. */
export declare class H3Transport extends Transport {
    private readonly uri;
    private readonly opts;
    private readonly tr;
    /** Whether current environment supports WebTransport. */
    static readonly supported: boolean;
    /**
     * Create a transport and connect to remote endpoint.
     * @param uri - Server URI.
     * @param opts - WebTransport options.
     */
    static connect(uri: string, opts?: H3Transport.Options): Promise<H3Transport>;
    private constructor();
    /** Report HTTP/3 maximum datagram size as MTU. */
    get mtu(): number;
    readonly rx: Transport.RxIterable;
    tx(iterable: Transport.TxIterable): Promise<void>;
    /** Reopen the transport by connecting again with the same options. */
    reopen(): Promise<H3Transport>;
}
export declare namespace H3Transport {
    /** {@link H3Transport.connect} options. */
    interface Options extends WebTransportOptions {
        /**
         * Connect timeout (in milliseconds).
         * @defaultValue 10000
         */
        connectTimeout?: number;
        /**
         * Skip TLS certificate verification (Node.js only).
         * @defaultValue false
         *
         * @remarks
         * `serverCertificateHashes` does not work in Node.js due to \@webtransport-bun/webtransport
         * v0.3.0 bugs but would be supported when they release v1.0.
         */
        insecureSkipVerify?: boolean;
    }
    /** Create a transport and add to forwarder. */
    const createFace: L3Face.CreateFaceFunc<[uri: string, opts?: Options | undefined]>;
}
