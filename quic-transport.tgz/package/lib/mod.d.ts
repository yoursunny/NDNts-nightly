import { L3Face, Transport } from "@ndn/l3face";
/** QUIC transport. */
export declare class QuicTransport extends Transport {
    static connect(uri: string): Promise<QuicTransport>;
    readonly rx: Transport.Rx;
    private readonly datagramWriter;
    private constructor();
    tx: (iterable: AsyncIterable<Uint8Array>) => Promise<void>;
}
export declare namespace QuicTransport {
    /** Create a transport and add to forwarder. */
    const createFace: L3Face.CreateFaceFunc<typeof QuicTransport.connect>;
}
