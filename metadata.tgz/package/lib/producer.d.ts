import { type Producer, type ProducerOptions } from "@ndn/endpoint";
import { Data, type Interest, type NameLike, type Signer } from "@ndn/packet";
import { type Metadata } from "./metadata.js";
/**
 * Make metadata packet.
 * @param m - Content of metadata packet.
 */
export declare function makeMetadataPacket(m: Metadata, { prefix, freshnessPeriod, signer, }?: makeMetadataPacket.Options): Promise<Data>;
export declare namespace makeMetadataPacket {
    interface Options {
        /**
         * Metadata packet prefix.
         * @defaultValue `metadata.name.getPrefix(-1)`
         *
         * This should not contain `32=metadata` component.
         */
        prefix?: NameLike;
        /**
         * FreshnessPeriod.
         * @defaultValue 1
         */
        freshnessPeriod?: number;
        /**
         * Data signer.
         * @defaultValue noopSigning
         */
        signer?: Signer;
    }
}
/** Determine if an Interest is a discovery Interest. */
export declare function isDiscoveryInterest({ name, canBePrefix, mustBeFresh }: Interest): boolean;
/**
 * Serve metadata packet in a producer.
 * @param m - Content of metadata packet, or a function that returns the content.
 * @returns Producer instance.
 */
export declare function serveMetadata(m: Metadata | (() => Metadata), opts?: serveMetadata.Options): Producer;
export declare namespace serveMetadata {
    interface Options extends makeMetadataPacket.Options {
        /**
         * Producer options.
         *
         * @remarks
         * - `.describe` defaults to "metadata-s" + prefix.
         * - `.announcement` defaults to {@link makeMetadataPacket.Options.prefix}.
         * - {@link makeMetadataPacket.Options.signer} defaults to `.dataSigner`.
         */
        pOpts?: ProducerOptions;
    }
}
