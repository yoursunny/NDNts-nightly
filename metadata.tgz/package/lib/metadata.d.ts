import { type Component, Name } from "@ndn/packet";
import { type Decodable, type Decoder, type Encodable, type EncodableObj, type Encoder, Extensible } from "@ndn/tlv";
/** `32=metadata` component. */
export declare const MetadataKeyword: Component;
/** Metadata packet content. */
export declare class Metadata implements EncodableObj {
    name: Name;
    /**
     * Constructor.
     * @param name - Versioned name.
     */
    constructor(name?: Name);
    static decodeFrom(decoder: Decoder): Metadata;
    encodeTo(encoder: Encoder): void;
    protected encodeValueExt(): Encodable[];
}
export declare namespace Metadata {
    interface Constructor<M extends Metadata = Metadata> extends Decodable<M> {
        new (name?: Name): M;
    }
    /** Class decorator on an extensible {@link Metadata} subclass. */
    function extend<M extends Metadata & Extensible>(ctor: new () => M, ctx?: ClassDecoratorContext): void;
}
