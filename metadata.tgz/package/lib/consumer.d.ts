import { type ConsumerOptions } from "@ndn/endpoint";
import { Interest, type NameLike } from "@ndn/packet";
import { Metadata } from "./metadata.js";
/**
 * Make discovery Interest.
 * @param prefix - Metadata packet prefix.
 * `32=metadata` component is optional; it will be appended automatically if absent.
 */
export declare function makeDiscoveryInterest(prefix: NameLike): Interest;
/**
 * Retrieve metadata content of base type.
 * @param prefix - Metadata packet prefix.
 * @param cOpts - Consumer options.
 * - Commonly specified: `.retx` and `.verifier`.
 * - `.describe` defaults to "metadata-c" + prefix.
 * @returns Metadata content.
 */
export declare function retrieveMetadata(prefix: NameLike, cOpts?: ConsumerOptions): Promise<Metadata>;
/**
 * Retrieve metadata content of subclass type.
 * @typeParam C - Metadata subclass type.
 * @param prefix - Metadata packet prefix.
 * @param ctor - Metadata subclass constructor.
 * @param cOpts - Consumer options.
 * - Commonly specified: `.retx` and `.verifier`.
 * - `.describe` defaults to "metadata-c" + prefix.
 * @returns Metadata content of type C.
 */
export declare function retrieveMetadata<C extends Metadata.Constructor>(prefix: NameLike, ctor: C, cOpts?: ConsumerOptions): Promise<InstanceType<C>>;
