import { L3Face, Transport } from "@ndn/l3face";
import type { Memif } from "memif";
/** Shared Memory Packet Interface (memif) transport. */
export declare class MemifTransport extends Transport {
    /** Create a transport and establish connection. */
    static connect(opts: MemifTransport.Options): Promise<MemifTransport>;
    private constructor();
    /**
     * Access the underlying Memif instance.
     *
     * @remarks
     * You may read counters and monitor "memif:up" "memif:down" events, but not send/receive packets.
     */
    readonly memif: Memif;
    private readonly mtu_;
    get mtu(): number;
    readonly rx: Transport.RxIterable;
    tx(iterable: Transport.TxIterable): Promise<void>;
}
export declare namespace MemifTransport {
    /** {@link MemifTransport.connect} options. */
    interface Options extends Memif.Options {
        /**
         * Whether to wait until the connection is up.
         * @defaultValue true
         */
        waitUp?: boolean;
    }
    /** Create a memif transport and add to forwarder. */
    const createFace: L3Face.CreateFaceFunc<[opts: Options]>;
}
