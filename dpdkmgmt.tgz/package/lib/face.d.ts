import { Forwarder, type FwFace } from "@ndn/fw";
import { L3Face } from "@ndn/l3face";
import { udp_helper } from "@ndn/node-transport";
import type { NameLike } from "@ndn/packet";
import { MemifTransport } from "./memif-transport.js";
declare function openFaceUdp(opts: openFace.Options): Promise<FwFace>;
declare function openFaceMemif(opts: openFace.Options): Promise<FwFace>;
declare const openFaceScheme: {
    udp: typeof openFaceUdp;
    memif: typeof openFaceMemif;
};
/** Open a face on NDN-DPDK. */
export declare function openFace(opts?: openFace.Options): Promise<FwFace>;
export declare namespace openFace {
    interface Options {
        /**
         * NDN-DPDK GraphQL server.
         * @defaultValue http://127.0.0.1:3030
         */
        gqlServer?: string;
        /**
         * IP address to reach local host from NDN-DPDK.
         * @defaultValue
         * Auto-detected from GraphQL HTTP client.
         */
        localHost?: string;
        /**
         * NDNts logical forwarder.
         * @defaultValue `Forwarder.getDefault()`
         */
        fw?: Forwarder;
        /** NDNts face attributes. */
        attributes?: L3Face.Attributes;
        /**
         * Routes to be added on the created face.
         * @defaultValue `["/"]`
         */
        addRoutes?: readonly NameLike[];
        /**
         * Transport scheme.
         * @defaultValue "udp"
         */
        scheme?: keyof typeof openFaceScheme;
        /**
         * Face MTU.
         * @defaultValue
         * - For UDP, 1400.
         * - For memif, `.memif.dataroom` or 2048.
         */
        mtu?: number;
        /** UDP socket options. */
        udp?: udp_helper.OpenSocketOptions;
        /** memif options. */
        memif?: MemifOptions;
    }
    /** memif options. */
    interface MemifOptions extends Pick<MemifTransport.Options, "dataroom" | "ringCapacity"> {
        /**
         * Directory in which to place control socket.
         * If NDN-DPDK and NDNts are in containers, the same directory must be mounted in both containers.
         * @defaultValue /run/ndn
         */
        socketPath?: string;
    }
}
export {};
