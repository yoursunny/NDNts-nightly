import { Forwarder, FwFace } from "@ndn/fw";
import { L3Face } from "@ndn/l3face";
/** Open a face on NDN-DPDK. */
export declare function openFace({ fw, attributes, localHost, gqlServer, }?: openFace.Options): Promise<FwFace>;
export declare namespace openFace {
    interface Options {
        /** NDNts logical forwarder. */
        fw?: Forwarder;
        /** NDNts face attributes. */
        attributes?: L3Face.Attributes;
        /** Local IPv4 address. */
        localHost?: string;
        /** NDN-DPDK GraphQL server. */
        gqlServer?: string;
    }
}
