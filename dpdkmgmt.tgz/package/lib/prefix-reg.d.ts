import { ReadvertiseDestination } from "@ndn/fw";
import type { Name } from "@ndn/packet";
import type { GraphQLClient } from "graphql-request";
interface State {
    fibEntryID?: string;
}
/** Enable prefix registration via NDN-DPDK GraphQL management API. */
export declare class NdndpdkPrefixReg extends ReadvertiseDestination<State> {
    private readonly client;
    private readonly faceID;
    constructor(client: GraphQLClient, faceID: string);
    protected doAdvertise(name: Name, state: State): Promise<void>;
    protected doWithdraw(name: Name, state: State): Promise<void>;
}
export {};
