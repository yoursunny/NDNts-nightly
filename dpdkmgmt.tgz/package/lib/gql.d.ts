import { type Variables } from "graphql-request";
export declare const Delete: string;
export declare namespace Delete {
    interface Vars extends Variables {
        id: string;
    }
    interface Resp {
        delete: boolean;
    }
}
export declare const InsertFibEntry: string;
export declare namespace InsertFibEntry {
    interface Vars extends Variables {
        name: string;
        nexthops: string[];
        strategy?: string;
    }
    interface Resp {
        insertFibEntry: {
            id: string;
        };
    }
}
