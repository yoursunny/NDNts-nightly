import { DataStore } from "@ndn/repo-api";
import type { Arguments, Argv, CommandModule } from "yargs";
import { StoreArgs } from "./util";
interface GenDataArgs {
    prefix: string;
    start: number;
    count: number;
    size: number;
}
interface BaseArgs extends GenDataArgs {
    batch: number;
    parallel: number;
}
declare abstract class FillCommandBase {
    protected buildBaseArgv(argv: Argv): Argv<BaseArgs>;
    protected execute(args: BaseArgs, store: DataStore.Insert): Promise<void>;
}
declare type FillStoreArgs = BaseArgs & StoreArgs;
export declare class FillStoreCommand extends FillCommandBase implements CommandModule<{}, FillStoreArgs> {
    command: string;
    describe: string;
    builder: (argv: Argv) => Argv<FillStoreArgs>;
    handler: (args: Arguments<FillStoreArgs>) => Promise<void>;
}
declare type FillBiArgs = BaseArgs & {
    host: string;
    port: number;
};
export declare class FillBiCommand extends FillCommandBase implements CommandModule<{}, FillBiArgs> {
    command: string;
    describe: string;
    builder: (argv: Argv) => Argv<FillBiArgs>;
    handler: (args: Arguments<FillBiArgs>) => Promise<void>;
}
export {};
