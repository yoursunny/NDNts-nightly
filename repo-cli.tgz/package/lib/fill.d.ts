import { Name } from "@ndn/packet";
import type { CommandModule, InferredOptionTypes } from "yargs";
import { type StoreArgs } from "./util.js";
declare const baseOptions: {
    prefix: {
        coerce: typeof Name.from;
        default: Name;
        desc: string;
        type: "string";
    };
    start: {
        default: number;
        desc: string;
        type: "number";
    };
    count: {
        default: number;
        desc: string;
        type: "number";
    };
    size: {
        default: number;
        desc: string;
        type: "number";
    };
    batch: {
        default: number;
        desc: string;
        type: "number";
    };
    parallel: {
        default: number;
        desc: string;
        type: "number";
    };
    progress: {
        default: boolean;
        desc: string;
        type: "boolean";
    };
};
type BaseArgs = InferredOptionTypes<typeof baseOptions>;
export declare const FillStoreCommand: CommandModule<{}, BaseArgs & StoreArgs>;
export declare const FillBiCommand: CommandModule<{}, BaseArgs & {
    host: string;
    port: number;
}>;
export {};
