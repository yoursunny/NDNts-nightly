export declare const COMMAND = "ndnts-repo";
