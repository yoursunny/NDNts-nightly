import { type DataStore } from "@ndn/repo";
import type { InferredOptionTypes } from "yargs";
export declare const storeOptions: {
    store: {
        demandOption: true;
        desc: string;
        type: "string";
    };
};
export type StoreArgs = InferredOptionTypes<typeof storeOptions>;
export declare function openStore(argv: StoreArgs): Promise<DataStore>;
