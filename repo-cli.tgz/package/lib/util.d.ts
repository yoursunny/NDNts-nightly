import { DataStore } from "@ndn/repo";
import type { Argv } from "yargs";
export interface StoreArgs {
    store: string;
}
export declare function declareStoreArgs<T>(argv: Argv<T>): Argv<T & StoreArgs>;
export declare let store: DataStore;
export declare function openStore(argv: StoreArgs): void;
