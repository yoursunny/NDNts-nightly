import type { Arguments, Argv, CommandModule } from "yargs";
import { StoreArgs } from "./util";
interface Args extends StoreArgs {
    rdr: boolean;
    bi: boolean;
    "bi-host": string;
    "bi-port": number;
    "bi-batch": number;
    "bi-parallel": number;
}
export declare class ServerCommand implements CommandModule<{}, Args> {
    command: string;
    describe: string;
    builder(argv: Argv): Argv<Args>;
    handler(args: Arguments<Args>): Promise<void>;
}
export {};
