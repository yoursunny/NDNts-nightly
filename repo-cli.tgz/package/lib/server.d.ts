import type { CommandModule } from "yargs";
import { type StoreArgs } from "./util.js";
interface Args extends StoreArgs {
    rdr: boolean;
    bi: boolean;
    "bi-host": string;
    "bi-port": number;
    "bi-batch": number;
    "bi-parallel": number;
}
export declare const ServerCommand: CommandModule<{}, Args>;
export {};
