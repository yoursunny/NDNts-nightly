import { Component, Name } from "@ndn/packet";
/** 32=metadata component. */
export declare const MetadataKeyword: Component;
/** RDR metadata packet content. */
export interface Metadata {
    /** Versioned name. */
    name: Name;
}
/** Encode RDR metadata packet content. */
export declare function encodeMetadataContent({ name }: Metadata): Uint8Array;
/** Decode RDR metadata packet content. */
export declare function decodeMetadataContent(wire: Uint8Array): Metadata;
