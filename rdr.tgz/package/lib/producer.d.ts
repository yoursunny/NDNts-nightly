import { Endpoint, Producer } from "@ndn/endpoint";
import { Data, Interest, NameLike, Signer } from "@ndn/packet";
import { Metadata } from "./metadata";
interface Options {
    /**
     * RDR metadata packet prefix.
     *
     * This should not contain 32=metadata.
     *
     * @default metadata.name.getPrefix(-1)
     */
    prefix?: NameLike;
    /**
     * FreshnessPeriod.
     * @default 1
     */
    freshnessPeriod?: number;
    /** Signing key. */
    signer?: Signer;
    /** Endpoint to run producer. */
    endpoint?: Endpoint;
    /** Prefix to announce from producer. */
    announcement?: Endpoint.RouteAnnouncement;
}
/** Make RDR metadata packet. */
export declare function makeMetadataPacket(m: Metadata, { freshnessPeriod, prefix, signer, }?: Options): Promise<Data>;
/** Determine if an Interest is an RDR discovery Interest. */
export declare function isDiscoveryInterest({ name, canBePrefix, mustBeFresh }: Interest): boolean;
/** Serve RDR metadata packet in a producer. */
export declare function serveMetadata(m: Metadata | (() => Metadata), opts?: Options): Producer;
export {};
