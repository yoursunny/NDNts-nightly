import { Endpoint, RetxPolicy } from "@ndn/endpoint";
import { Interest, NameLike, Verifier } from "@ndn/packet";
import type { AbortSignal } from "abort-controller";
/**
 * Make RDR discovery Interest.
 * @param prefix prefix of RDR metadata packet; 32=metadata component is optional.
 */
export declare function makeDiscoveryInterest(prefix: NameLike): Interest;
/** Retrieve RDR metadata packet. */
export declare function retrieveMetadata(prefix: NameLike, { endpoint, retx, signal, verifier, }?: retrieveMetadata.Options): Promise<import("./metadata").Metadata>;
export declare namespace retrieveMetadata {
    interface Options {
        endpoint?: Endpoint;
        retx?: RetxPolicy;
        signal?: AbortSignal | globalThis.AbortSignal;
        verifier?: Verifier;
    }
}
