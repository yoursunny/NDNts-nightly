import { type ConsumerOptions, type Endpoint } from "@ndn/endpoint";
import { Interest, type NameLike } from "@ndn/packet";
import { Metadata } from "./metadata.js";
/**
 * Make discovery Interest.
 * @param prefix - Metadata packet prefix.
 * `32=metadata` component is optional; it will be appended automatically if absent.
 */
export declare function makeDiscoveryInterest(prefix: NameLike): Interest;
/**
 * Retrieve metadata packet of base type.
 * @param prefix - Metadata packet prefix.
 * @param cOpts - Consumer options.
 * - Commonly specified: `.retx` and `.verifier`.
 * - `.describe` defaults to "RDR-c" + prefix.
 * @returns Metadata packet.
 */
export declare function retrieveMetadata(prefix: NameLike, cOpts?: ConsumerOptions & EndpointOptions): Promise<Metadata>;
/**
 * Retrieve metadata packet of subclass type.
 * @typeParam C - Metadata subclass type.
 * @param prefix - Metadata packet prefix.
 * @param ctor - Metadata subclass constructor.
 * @param cOpts - Consumer options.
 * - Commonly specified: `.retx` and `.verifier`.
 * - `.describe` defaults to "RDR-c" + prefix.
 * @returns Metadata packet of type C.
 */
export declare function retrieveMetadata<C extends Metadata.Constructor>(prefix: NameLike, ctor: C, cOpts?: ConsumerOptions & EndpointOptions): Promise<InstanceType<C>>;
interface EndpointOptions {
    /**
     * Endpoint for communication.
     * @deprecated Use {@link ConsumerOptions} fields only.
     */
    endpoint?: Endpoint;
}
export {};
