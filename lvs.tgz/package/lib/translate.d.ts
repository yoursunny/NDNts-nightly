import { type Component } from "@ndn/packet";
import { TrustSchemaPolicy } from "@ndn/trust-schema";
import { type LvsModel } from "./tlv.js";
/**
 * User function used by a LVS model.
 * @param value - Name component supplied at runtime.
 * @param args - Arguments defined in the LVS model.
 * @returns Whether `value` is a match.
 */
export type UserFn = (value: Component, args: readonly Component[]) => boolean;
/** A table of user functions. */
export type Vtable = ReadonlyMap<string, UserFn>;
/** A table of user functions. */
export type VtableInput = Vtable | Record<string, UserFn>;
/**
 * Translate LVS model to TrustSchemaPolicy.
 * @param model - LVS model.
 *
 * @throws Error
 * Malformed LVS model.
 * Some user functions referenced in the LVS model are missing in the vtable.
 */
export declare function toPolicy(model: LvsModel, { vtable, buildTime, patternAliases, }?: toPolicy.Options): TrustSchemaPolicy;
export declare namespace toPolicy {
    /** {@link toPolicy} options. */
    interface Options {
        /** Link user functions to the model. */
        vtable?: VtableInput;
        /**
         * If set to true, perform a build-time translation where incomplete vtable would not throw
         * an error. The returned policy may not executed successfully, but can be serialized with
         * {@link printESM} and {@link printUserFns}.
         *
         * Otherwise, perform a runtime translation that checks all referenced user functions are
         * present in the vtable.
         *
         * @defaultValue false
         */
        buildTime?: boolean;
        /**
         * LVS model allows a node to have multiple rule names and may associate the same rule name
         * with multiple nodes. However, TrustSchemaPolicy only allows one name for each pattern.
         *
         * If set to true, a pattern translated from a node is duplicated so that it is associated
         * with every rule name.
         *
         * Otherwise, each pattern is only reachable from one name. The rule name, if unique, will be
         * used; otherwise, an internal name is derived from the node id.
         *
         * @defaultValue false
         */
        patternAliases?: boolean;
    }
}
export declare const neededFnsMap: WeakMap<TrustSchemaPolicy, Map<string, ReadonlySet<number>>>;
