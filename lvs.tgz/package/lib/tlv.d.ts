export declare const TT: {
    readonly ComponentValue: 33;
    readonly PatternTag: 35;
    readonly NodeId: 37;
    readonly UserFnId: 39;
    readonly Identifier: 41;
    readonly UserFnCall: 49;
    readonly FnArgs: 51;
    readonly ConsOption: 65;
    readonly Constraint: 67;
    readonly ValueEdge: 81;
    readonly PatternEdge: 83;
    readonly KeyNodeId: 85;
    readonly ParentId: 87;
    readonly Version: 97;
    readonly Node: 99;
    readonly TagSymbol: 103;
    readonly NamedPatternNum: 105;
};
export declare const BinfmtVersion = 69632;
declare const ValueEdge_base: (new () => {
    dest: number;
    value: import("@ndn/packet").Component;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<ValueEdge>;
export declare class ValueEdge extends ValueEdge_base {
}
declare const UserFnArg_base: (new () => {
    tag?: number | undefined;
    value?: import("@ndn/packet").Component | undefined;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<UserFnArg>;
export declare class UserFnArg extends UserFnArg_base {
}
declare const UserFnCall_base: (new () => {
    args: UserFnArg[];
    fn: string;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<UserFnCall>;
export declare class UserFnCall extends UserFnCall_base {
}
declare const ConsOption_base: (new () => {
    call?: UserFnCall | undefined;
    tag?: number | undefined;
    value?: import("@ndn/packet").Component | undefined;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<ConsOption>;
export declare class ConsOption extends ConsOption_base {
}
declare const Constraint_base: (new () => {
    options: ConsOption[];
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<Constraint>;
export declare class Constraint extends Constraint_base {
}
declare const PatternEdge_base: (new () => {
    constraints: Constraint[];
    dest: number;
    tag: number;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<PatternEdge>;
export declare class PatternEdge extends PatternEdge_base {
}
declare const Node_base: (new () => {
    id: number;
    parent?: number | undefined;
    patternEdges: PatternEdge[];
    ruleNames: string[];
    signConstraints: number[];
    valueEdges: ValueEdge[];
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<Node>;
export declare class Node extends Node_base {
    findEdgeTo(dest: number): ValueEdge | PatternEdge | undefined;
}
declare const TagSymbol_base: (new () => {
    identifier: string;
    tag: number;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<TagSymbol>;
export declare class TagSymbol extends TagSymbol_base {
}
declare const LvsModel_base: (new () => {
    namedPatternCnt: number;
    nodes: Node[];
    startId: number;
    tagSymbols: TagSymbol[];
    version: number;
} & import("@ndn/tlv").EncodableObj) & import("@ndn/tlv").Decodable<LvsModel>;
export declare class LvsModel extends LvsModel_base {
}
export {};
