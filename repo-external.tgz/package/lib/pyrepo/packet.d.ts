import { Component, Name } from "@ndn/packet";
import { Decoder, Encoder } from "@ndn/tlv";
export declare const InsertVerb: Component;
export declare const DeleteVerb: Component;
export declare const CheckVerb: Component;
export declare class CommandParameter {
    name?: Name | undefined;
    startBlockId?: number | undefined;
    endBlockId?: number | undefined;
    constructor(name?: Name | undefined, startBlockId?: number | undefined, endBlockId?: number | undefined);
    processId: Uint8Array;
    fwHint?: Name;
    checkPrefix: Name;
    encodeTo(encoder: Encoder): void;
}
export declare class CommandResponse {
    static decodeFrom(decoder: Decoder): CommandResponse;
    statusCode: number;
}
