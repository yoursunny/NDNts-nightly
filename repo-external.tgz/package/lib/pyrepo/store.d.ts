import type { Name } from "@ndn/packet";
import { DataStore as S } from "@ndn/repo-api";
import { PyRepoClient } from "./client";
/** A DataStore implementation using ndn-python-repo. */
export declare class PyRepoStore implements S.Close, S.Insert, S.Delete {
    /** Construct with new PyRepoClient. */
    constructor(opts: PyRepoStore.Options);
    /** Construct with existing PyRepoClient. */
    constructor(client: PyRepoClient, opts?: PyRepoStore.StoreOptions);
    readonly client: PyRepoClient;
    private readonly ownsClient;
    private readonly throttle;
    private readonly endpoint;
    /** Close the PyRepoClient only if it is created by this store. */
    close(): Promise<void>;
    /** Insert some Data packets. */
    insert(...args: S.Insert.Args<{}>): Promise<void>;
    /** Delete some Data packets. */
    delete(...names: Name[]): Promise<void>;
}
export declare namespace PyRepoStore {
    interface StoreOptions {
        /** Maximum number of parallel insertions. Default is 16. */
        parallel?: number;
    }
    interface Options extends PyRepoClient.Options, StoreOptions {
    }
}
