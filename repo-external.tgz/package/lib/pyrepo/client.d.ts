import { Endpoint } from "@ndn/endpoint";
import { Name } from "@ndn/packet";
import { PrpsPublisher, PrpsSubscriber } from "../prps/mod";
/** Client to interact with ndn-python-repo. */
export declare class PyRepoClient {
    constructor(opts: PyRepoClient.Options);
    readonly endpoint: Endpoint;
    readonly repoPrefix: Name;
    private readonly progressTimeout;
    private readonly publisher;
    private readonly subscriber;
    private readonly ongoing;
    close(): void;
    insert(name: Name): Promise<void>;
    insertRange(name: Name, start: number, end?: number): Promise<void>;
    delete(name: Name): Promise<void>;
    deleteRange(name: Name, start: number, end?: number): Promise<void>;
    private execute;
}
export declare namespace PyRepoClient {
    interface Options extends PrpsPublisher.Options, PrpsSubscriber.Options {
        /**
         * Name prefix of the repo instance.
         * This corresponds to ndn-python-repo.conf repo_config.repo_name key.
         */
        repoPrefix: Name;
        /**
         * Progress update timeout in milliseconds.
         * If no progress update is received for this period of time, the command is deemed failed.
         * Default is 10 seconds.
         */
        progressTimeout?: number;
    }
}
