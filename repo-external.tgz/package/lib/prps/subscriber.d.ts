import { Endpoint, RetxPolicy } from "@ndn/endpoint";
import { Data, Name, Signer, Verifier } from "@ndn/packet";
/** PyRepo PubSub protocol subscriber. */
export declare class PrpsSubscriber {
    constructor({ endpoint, msgInterestLifetime, msgRetx, pubVerifier, subAnnouncement, subSigner, }: PrpsSubscriber.Options);
    readonly endpoint: Endpoint;
    private readonly msgInterestLifetime;
    private readonly msgRetx;
    private readonly pubVerifier?;
    private readonly subAnnouncement?;
    private readonly subSigner;
    subscribe(topic: Name): PrpsSubscriber.Subscription;
}
export declare namespace PrpsSubscriber {
    interface Options {
        /** Endpoint for communication. */
        endpoint?: Endpoint;
        /** InterestLifetime of msg Interests. */
        msgInterestLifetime?: number;
        /**
         * Retransmission policy of msg Interests.
         * Default is 2 retransmissions.
         */
        msgRetx?: RetxPolicy;
        /**
         * Verifier for publications.
         * Default is no verification.
         */
        pubVerifier?: Verifier;
        /** Set to false to disable prefix announcements for receiving notify Interests. */
        subAnnouncement?: false;
        /**
         * Key to sign notify Data.
         * Default is digest signing.
         */
        subSigner?: Signer;
    }
    type Subscription = AsyncIterable<Data> & {
        readonly topic: Name;
        /** Unsubscribe. */
        close: () => void;
    };
}
