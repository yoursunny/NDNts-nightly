import { Endpoint, RetxPolicy } from "@ndn/endpoint";
import { Data, Name, Signer } from "@ndn/packet";
import { Encodable } from "@ndn/tlv";
/** PyRepo PubSub protocol publisher. */
export declare class PrpsPublisher {
    constructor({ endpoint, pubPrefix, pubFwHint, pubAnnouncement, pubSigner, notifyInterestLifetime, notifyRetx, }: PrpsPublisher.Options);
    readonly endpoint: Endpoint;
    readonly pubPrefix: Name;
    readonly pubFwHint?: Name;
    private readonly pubSigner;
    private readonly notifyInterestLifetime;
    private readonly notifyRetx;
    private readonly messagePrefix;
    private readonly messageProducer;
    private readonly pendings;
    close(): void;
    publish(topic: Name, item: Item): Promise<void>;
    private handleMessageInterest;
}
declare type Item = Encodable | PrpsPublisher.PublicationCallback;
export declare namespace PrpsPublisher {
    interface Options {
        /** Endpoint for communication. */
        endpoint?: Endpoint;
        /**
         * Name prefix of the local application.
         * Default is a random local name that only works when the subscriber is on local machine.
         */
        pubPrefix?: Name;
        /** Forwarding hint of the local application. */
        pubFwHint?: Name;
        /**
         * Prefix announcement to receive msg Interests.
         * Default is pubFwHint, or pubPrefix.
         */
        pubAnnouncement?: Name | false;
        /**
         * Key to sign publications.
         * This key should be trusted to sign objects under pubPrefix.
         * Default is digest signing.
         * This may overridden on a per-publication basis by PublicationCallback returning Data.
         */
        pubSigner?: Signer;
        /** InterestLifetime of notify Interests. */
        notifyInterestLifetime?: number;
        /**
         * Retransmission policy of notify Interests.
         * Default is 2 retransmissions.
         */
        notifyRetx?: RetxPolicy;
    }
    /**
     * A callback function to generate publication packet.
     * @param name expected Data name.
     * @param topic topic name.
     * @return either a Data that is already signed, or an Encodable object to use as publication body.
     */
    type PublicationCallback = (name: Name, topic: Name) => Promise<Data | Encodable>;
}
export {};
