import { Component, Name } from "@ndn/packet";
import { Decoder, Encoder } from "@ndn/tlv";
export declare const MsgSuffix: Component;
export declare const NotifySuffix: Component;
export declare class NotifyParams {
    publisher: Name;
    nonce: Uint8Array;
    publisherFwHint?: Name | undefined;
    static decodeFrom(decoder: Decoder): NotifyParams;
    constructor(publisher: Name, nonce: Uint8Array, publisherFwHint?: Name | undefined);
    encodeTo(encoder: Encoder): void;
}
