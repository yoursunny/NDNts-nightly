import { Certificate, KeyChain } from "@ndn/keychain";
import type { Name } from "@ndn/packet";
import type { CertSource } from "./types";
/** Find certificates in KeyChain. */
export declare class KeyChainCertSource implements CertSource {
    private readonly keyChain;
    constructor(keyChain: KeyChain);
    findCerts(keyLocator: Name): AsyncIterable<Certificate>;
}
