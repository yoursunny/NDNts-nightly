import { type Certificate, type KeyChain } from "@ndn/keychain";
import type { Name } from "@ndn/packet";
import type { CertSource } from "./types.js";
/** Find certificates in KeyChain. */
export declare class KeyChainCertSource implements CertSource {
    private readonly keyChain;
    constructor(keyChain: KeyChain);
    /** Find certificates by certificate name or key name. */
    findCerts(keyLocator: Name): AsyncIterable<Certificate>;
}
