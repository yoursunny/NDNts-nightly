import { type Certificate } from "@ndn/keychain";
import { type Name } from "@ndn/packet";
import type { CertSource } from "./types.js";
/** A container of trust anchors. */
export declare class TrustAnchorContainer implements CertSource {
    private readonly byCertName;
    private readonly byKeyName;
    /**
     * Constructor.
     * @param certs - Trust anchors.
     */
    constructor(certs?: readonly Certificate[]);
    /** Add a certificate as a trust anchor. */
    add(cert: Certificate): void;
    /** Remove a trust anchor. */
    remove(cert: Certificate): void;
    /** Determine if a certificate has been added as a trust anchor. */
    has(cert: Certificate): boolean;
    /** Find trust anchors by certificate name or key name. */
    findCerts(keyLocator: Name): AsyncIterable<Certificate>;
}
