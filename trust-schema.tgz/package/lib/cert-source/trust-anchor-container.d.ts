import { Certificate } from "@ndn/keychain";
import type { Name } from "@ndn/packet";
import type { CertSource } from "./types";
/** A container of trust anchors. */
export declare class TrustAnchorContainer implements CertSource {
    private readonly byCertName;
    private readonly byKeyName;
    constructor(certs: Certificate[]);
    add(cert: Certificate): void;
    remove(cert: Certificate): void;
    has(cert: Certificate): boolean;
    /** Find certificates among trust anchors. */
    findCerts(keyLocator: Name): AsyncIterable<Certificate>;
}
