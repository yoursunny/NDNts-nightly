import { Certificate, KeyChain } from "@ndn/keychain";
import { Name } from "@ndn/packet";
import { CertFetcher } from "./fetcher";
import { TrustAnchorContainer } from "./trust-anchor-container";
import type { CertSource } from "./types";
/** Find certificates from multiple sources. */
export declare class CertSources implements CertSource {
    readonly trustAnchors: TrustAnchorContainer;
    private readonly fetcher?;
    private readonly keyChainSource?;
    private readonly list;
    constructor(opts: CertSources.Options);
    findCerts(keyLocator: Name): AsyncIterable<Certificate>;
    isTrustAnchor(cert: Certificate): boolean;
}
export declare namespace CertSources {
    interface Options extends CertFetcher.Options {
        trustAnchors?: TrustAnchorContainer | Certificate[];
        /** If true, disable CertFetcher. */
        offline?: boolean;
        keyChain?: KeyChain;
    }
}
