import type { Certificate, KeyChain } from "@ndn/keychain";
import type { Name } from "@ndn/packet";
import { CertFetcher } from "./fetcher.js";
import { TrustAnchorContainer } from "./trust-anchor-container.js";
import type { CertSource } from "./types.js";
/** Find certificates from multiple sources. */
export declare class CertSources implements CertSource {
    readonly trustAnchors: TrustAnchorContainer;
    private readonly fetcher?;
    private readonly keyChainSource?;
    private readonly list;
    constructor(opts: CertSources.Options);
    /**
     * Find certificates by certificate name or key name.
     *
     * @remarks
     * Searching from sources in this order:
     * - trust anchors
     * - local KeyChain
     * - network retrieval
     * After finding one or more certificates in a source, subsequent sources are skipped.
     */
    findCerts(keyLocator: Name): AsyncIterable<Certificate>;
    isTrustAnchor(cert: Certificate): boolean;
}
export declare namespace CertSources {
    interface Options extends CertFetcher.Options {
        /** Trust anchor certificates. */
        trustAnchors?: TrustAnchorContainer | Certificate[];
        /** Local KeyChain. */
        keyChain?: KeyChain;
        /** If true, disable CertFetcher. */
        offline?: boolean;
    }
}
