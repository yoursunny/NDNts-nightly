import { Endpoint, RetxPolicy } from "@ndn/endpoint";
import { Certificate } from "@ndn/keychain";
import { Name } from "@ndn/packet";
import type { CertSource } from "./types";
interface CacheOptions {
    /** Cache lifetime for successful retrieval. Default is 1 hour. */
    positiveTtl?: number;
    /** Cache lifetime for unsuccessful retrieval. Default is 10 seconds. */
    negativeTtl?: number;
    /** Cache cleanup interval. Default is 5 minutes. */
    cacheCleanupInterval?: number;
}
/** Fetch certificates from network. */
export declare class CertFetcher implements CertSource {
    constructor(opts: CertFetcher.Options);
    private readonly endpoint;
    private readonly consumerOpts;
    private readonly cache;
    findCerts(keyLocator: Name): AsyncIterable<Certificate>;
}
export declare namespace CertFetcher {
    interface Options extends CacheOptions {
        /**
         * Endpoint for certificate retrieval.
         *
         * CertFetchers on the same Endpoint share the same cache instance.
         * Cache options are determined when it's first created.
         */
        endpoint?: Endpoint;
        /** InterestLifetime for certificate retrieval. */
        interestLifetime?: number;
        /** RetxPolicy for certificate retrieval. */
        retx?: RetxPolicy;
    }
}
export {};
