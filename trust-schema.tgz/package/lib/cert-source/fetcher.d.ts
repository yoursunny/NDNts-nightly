import { type ConsumerOptions, type Endpoint, type RetxPolicy } from "@ndn/endpoint";
import { Certificate } from "@ndn/keychain";
import { type Name } from "@ndn/packet";
import type { CertSource } from "./types.js";
/** Fetch certificates from network. */
export declare class CertFetcher implements CertSource {
    constructor(opts: CertFetcher.Options);
    private readonly cOpts;
    private readonly cache;
    /**
     * Fetch certificates from network by certificate name or key name.
     * Upon successful retrieval, yields the certificate.
     * Upon unsuccessful retrieval, ends the iterable without yielding.
     * Retrieval result is cached for a period of time.
     */
    findCerts(keyLocator: Name): AsyncIterable<Certificate>;
}
export declare namespace CertFetcher {
    interface CacheOptions {
        /**
         * Cache lifetime for successful retrieval, in milliseconds.
         * @defaultValue 1 hour
         *
         * @remarks
         * During this period, return the same certificate instead of re-fetching.
         */
        positiveTtl?: number;
        /**
         * Cache lifetime for unsuccessful retrieval, in milliseconds.
         * @defaultValue 10 seconds
         *
         * @remarks
         * During this period, report the certificate as un-retrievable instead of re-fetching.
         */
        negativeTtl?: number;
        /**
         * Cache cleanup interval, in milliseconds.
         * @defaultValue 5 minutes
         *
         * @remarks
         * This determines how often expired cache entries are deleted.
         */
        cacheCleanupInterval?: number;
    }
    interface Options extends CacheOptions {
        /**
         * Cache instance owner as WeakMap key.
         * @defaultValue `.endpoint ?? .cOpts.fw ?? Forwarder.getDefault()`
         *
         * @remarks
         * {@link CertFetcher}s with the same `.owner` share the same cache instance.
         * Cache options are determined when it's first created.
         */
        owner?: object;
        /**
         * Endpoint for communication.
         * @deprecated Specify `.cOpts`.
         */
        endpoint?: Endpoint;
        /**
         * Consumer options.
         *
         * @remarks
         * - `.describe` defaults to "CertFetcher".
         */
        cOpts?: ConsumerOptions;
        /**
         * InterestLifetime for certificate retrieval.
         *
         * @remarks
         * If specified, `.cOpts.modifyInterest` is overridden.
         */
        interestLifetime?: number;
        /**
         * RetxPolicy for certificate retrieval.
         * @deprecated Specify in `.cOpts.retx`.
         */
        retx?: RetxPolicy;
    }
}
