import type { Name, Signer } from "@ndn/packet";
/** Policy based signer. */
export declare abstract class PolicySigner implements Signer {
    /** Sign a packet. */
    sign(pkt: Signer.Signable): Promise<void>;
    /** Locate an existing signer. */
    abstract findSigner(name: Name): Promise<Signer>;
}
