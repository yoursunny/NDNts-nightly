import { type Certificate, type SigningAlgorithm } from "@ndn/keychain";
import { type Name, type Verifier } from "@ndn/packet";
import { CertSources } from "./cert-source/mod.js";
/** Policy based verifier. */
export declare abstract class PolicyVerifier<Context = unknown> implements Verifier {
    protected readonly certSources: CertSources;
    private readonly algoList;
    constructor(opts: PolicyVerifier.Options);
    /** Verify a packet. */
    verify(pkt: Verifier.Verifiable, now?: number): Promise<void>;
    /**
     * Check policy on KeyLocator name, before certificate retrieval.
     * @param pkt - Packet carrying KeyLocator.
     * @param klName - KeyLocator name.
     * @returns arbitrary value to be passed to {@link PolicyVerifier.checkCertPolicy}.
     *
     * @throws Error
     * Thrown if policy is violated.
     */
    protected abstract checkKeyLocatorPolicy(pkt: Verifier.Verifiable, klName: Name): Context;
    /**
     * Check policy on certificate name.
     * @param pkt - Packet carrying KeyLocator that triggered certificate retrieval.
     * @param cert - Retrieved certificate.
     * @param ctx - Return value of {@link PolicyVerifier.checkKeyLocatorPolicy}.
     *
     * @throws Error
     * Thrown if policy is violated.
     */
    protected abstract checkCertPolicy(pkt: Verifier.Verifiable, cert: Certificate, ctx: Context): void;
    private cryptoVerifyUncached;
    private readonly cryptoVerifyCache;
    private cryptoVerifyCached;
}
export declare namespace PolicyVerifier {
    interface Options extends CertSources.Options {
        /**
         * List of recognized algorithms in certificates.
         * @defaultValue SigningAlgorithmListSlim
         */
        algoList?: readonly SigningAlgorithm[];
    }
}
