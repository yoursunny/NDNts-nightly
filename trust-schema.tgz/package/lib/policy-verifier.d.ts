import { Certificate } from "@ndn/keychain";
import { Name, Verifier } from "@ndn/packet";
import { CertSources } from "./cert-source/mod";
/** Policy based verifier. */
export declare abstract class PolicyVerifier<Context = unknown> implements Verifier {
    protected readonly certSources: CertSources;
    constructor(opts: PolicyVerifier.Options);
    verify(pkt: Verifier.Verifiable, now?: number): Promise<void>;
    /**
     * Check policy on KeyLocator name, before certificate retrieval.
     * @param pkt packet carrying KeyLocator.
     * @param klName KeyLocator name.
     * @throws violating policy.
     * @returns arbitrary value to be passed to checkCertPolicy.
     */
    protected abstract checkKeyLocatorPolicy(pkt: Verifier.Verifiable, klName: Name): Context;
    /**
     * Check policy on certificate name.
     * @param pkt packet carrying KeyLocator that triggered certificate retrieval.
     * @param cert retrieved certificate.
     * @param ctx return value of checkKeyLocatorPolicy.
     */
    protected abstract checkCertPolicy(pkt: Verifier.Verifiable, cert: Certificate, ctx: Context): void;
    private checkValidity;
}
export declare namespace PolicyVerifier {
    interface Options extends CertSources.Options {
    }
}
