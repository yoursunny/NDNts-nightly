import { type KeyChain } from "@ndn/keychain";
import type { Name, Signer } from "@ndn/packet";
import { PolicySigner } from "../policy-signer.js";
/** Sign packets according to hierarchical trust model. */
export declare class HierarchicalSigner extends PolicySigner implements Signer {
    private readonly keyChain;
    constructor(keyChain: KeyChain);
    /**
     * Locate an existing signer among available certificates in the KeyChain.
     *
     * @remarks
     * The certificate's subject name shall be a prefix of the packet name.
     * Longer certificate names are preferred.
     */
    findSigner(name: Name): Promise<Signer>;
}
