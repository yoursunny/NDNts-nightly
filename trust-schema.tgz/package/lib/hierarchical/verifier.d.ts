import { type Certificate } from "@ndn/keychain";
import type { Name, Verifier } from "@ndn/packet";
import { PolicyVerifier } from "../policy-verifier.js";
/** Verify packets according to hierarchical trust model. */
export declare class HierarchicalVerifier extends PolicyVerifier {
    protected checkKeyLocatorPolicy({ name }: Verifier.Verifiable, klName: Name): void;
    protected checkCertPolicy({ name }: Verifier.Verifiable, { name: certName }: Certificate): void;
}
