import { type Pattern } from "./pattern.js";
/** Convert to a simpler pattern if possible. */
export declare function simplifyPattern(p: Pattern): Pattern;
