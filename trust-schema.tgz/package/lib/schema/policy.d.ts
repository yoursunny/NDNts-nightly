import type { Name } from "@ndn/packet";
import type { Pattern, Vars, VarsLike } from "./pattern";
/** Policy in a trust schema. */
export declare class TrustSchemaPolicy {
    private readonly patterns;
    private readonly rules;
    listPatterns(): Iterable<[string, Pattern]>;
    getPattern(id: string): Pattern;
    addPattern(id: string, pattern: Pattern): void;
    listRules(): Iterable<[string, string]>;
    hasRule(packetId: string, signerId: string): boolean;
    addRule(packetId: string, signerId: string): void;
    match(name: TrustSchemaPolicy.MatchInput): TrustSchemaPolicy.Match[];
    canSign(packet: TrustSchemaPolicy.MatchInput, signer: TrustSchemaPolicy.MatchInput): boolean;
    buildSignerNames(packet: TrustSchemaPolicy.MatchInput, vars?: VarsLike): Iterable<Name>;
}
export declare namespace TrustSchemaPolicy {
    interface Match {
        id: string;
        vars: Vars;
    }
    type MatchInput = Name | Match[];
}
