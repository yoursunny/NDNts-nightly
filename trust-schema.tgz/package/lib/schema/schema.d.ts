import type { Certificate } from "@ndn/keychain";
import type { TrustSchemaPolicy } from "./policy.js";
/** A trust schema. */
export declare class TrustSchema {
    readonly policy: TrustSchemaPolicy;
    readonly trustAnchors: Certificate[];
    constructor(policy: TrustSchemaPolicy, trustAnchors: Certificate[]);
}
