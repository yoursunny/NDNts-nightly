import { TrustSchemaPolicy } from "../policy.js";
import * as A from "./ast.js";
export declare function compile(schema: A.Schema): TrustSchemaPolicy;
/** Load policy from VerSec syntax. */
export declare function load(input: string): TrustSchemaPolicy;
