import type { TrustSchemaPolicy } from "../policy.js";
/** Print policy to VerSec syntax. */
export declare function print(policy: TrustSchemaPolicy): string;
