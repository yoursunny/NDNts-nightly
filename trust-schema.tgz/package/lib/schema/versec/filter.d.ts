import type { Name } from "@ndn/packet";
import { Pattern, VariablePattern, type Vars } from "../pattern.js";
import type * as A from "./ast.js";
/** Function in a call expression. */
export interface Callable {
    readonly nargs: number | [min: number, max: number];
    readonly asVariable?: boolean;
    readonly makeFilter?: (...args: readonly A.Expr[]) => VariablePattern.Filter;
}
export declare const builtinFunctions: Record<string, Callable>;
export declare class FunctionFilter implements VariablePattern.Filter {
    readonly callExpr: A.Call;
    readonly inner: VariablePattern.Filter;
    constructor(callExpr: A.Call, inner: VariablePattern.Filter);
    accept(name: Name, vars: Vars): boolean;
}
/** A filter from a component constraint term. */
export declare class ConstraintTerm implements VariablePattern.Filter {
    readonly id: string;
    readonly pattern: Pattern;
    constructor(id: string, pattern: Pattern);
    accept(name: Name, vars: Vars): boolean;
}
/** Combine multiple filters where every filter must pass. */
export declare class And implements VariablePattern.Filter {
    readonly filters: VariablePattern.Filter[];
    constructor(filters: VariablePattern.Filter[]);
    accept(name: Name, vars: Vars): boolean;
}
/** Combine multiple filters where some filter must pass. */
export declare class Or implements VariablePattern.Filter {
    readonly filters: VariablePattern.Filter[];
    constructor(filters: VariablePattern.Filter[]);
    accept(name: Name, vars: Vars): boolean;
}
/** Simplify a filter. */
export declare function simplify(filter: VariablePattern.Filter): VariablePattern.Filter;
/**
 * Simplify a filter.
 * @param allow - Allow set. Terms not in allow set are deleted.
 */
export declare function simplify(filter: VariablePattern.Filter, allow: ReadonlySet<string> | undefined): VariablePattern.Filter | undefined;
/**
 * Reduce a component constraint term as a {@link Pattern} if possible.
 * @returns
 * - `true`: there's no restriction for the term.
 * - `false`: the restriction cannot be translated to a Pattern.
 * - Pattern: translated pattern.
 */
export declare function reduceTerm(filter: VariablePattern.Filter, id: string): Pattern | boolean;
