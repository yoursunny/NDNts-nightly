import * as T from "./token.js";
/** A unit on the same nesting level. */
export type Unit = T.Token | Paren | Brace;
declare class Nested {
    readonly left: T.Operator;
    readonly mid: Unit[];
    right: T.Operator;
    protected constructor(left: T.Operator, mid: Unit[], right: T.Operator);
}
/** Tokens enclosed in parens. */
export declare class Paren extends Nested {
    constructor(left: T.Operator, mid?: Unit[]);
}
/** Tokens enclosed in braces. */
export declare class Brace extends Nested {
    constructor(left: T.Operator, mid?: Unit[]);
}
/** Scan tokens into a sequences of units on the same nesting level. */
export declare function scan(tokens: Iterable<T.Token>): Unit[];
/**
 * Split by operator.
 * @param sep - Separator operator type.
 * @param sequence - A sequence of units.
 * @param skipEmpty - Of true, empty sub sequences are skipped.
 * @returns Sub sequences.
 */
export declare function split(sep: typeof T.Operator, sequence: readonly Unit[], skipEmpty?: boolean): Unit[][];
/** Strip outer parens. */
export declare function unParen(units: readonly Unit[]): readonly Unit[];
/** Flatten sequence to tokens. */
export declare function toTokens(...sequence: readonly Unit[]): Iterable<T.Token>;
export {};
