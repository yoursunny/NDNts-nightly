import { Component } from "@ndn/packet";
/** Position in schema document. */
export declare class Position {
    /**
     * Constructor
     * @param line - 0-based line number.
     * @param column - 0-based column number.
     */
    constructor(line?: number, column?: number);
    /** 1-based line number, if known. */
    readonly line?: number;
    /** 1-based column number, if known. */
    readonly column?: number;
    toString(): string;
}
export declare namespace Position {
    const UNKNOWN: Position;
    interface WithPosition {
        position?: Position;
    }
    /** Extract first valid position from a sequence. */
    function from(input?: WithPosition | Iterable<WithPosition>): Position;
}
/** Token in schema document. */
export declare abstract class Token {
    /** Token position. */
    position: Position;
    /** String representation of the token. */
    abstract toString(): string;
}
/** Operator token. */
export declare abstract class Operator extends Token {
    /** Operator short string. */
    abstract get operator(): string;
    /** Operator nesting level. */
    abstract get nest(): number;
    /** If true, when this token appears at end of line, a comma should be inserted. */
    abstract get autoCommaAfter(): boolean;
}
export declare const Comma: new () => Operator;
export declare const Colon: new () => Operator;
export declare const And: new () => Operator;
export declare const Or: new () => Operator;
export declare const ArrowL: new () => Operator;
export declare const Slash: new () => Operator;
export declare const ParenL: new () => Operator;
export declare const ParenR: new () => Operator;
export declare const BraceL: new () => Operator;
export declare const BraceR: new () => Operator;
/** Identifier token. */
export declare class Ident extends Token {
    readonly id: string;
    constructor(id: string);
    toString(): string;
}
/** Name component literal token. */
export declare class ComponentLit extends Token {
    readonly comp: Component;
    constructor(comp: Component);
    toString(): string;
}
/** Tokenize a schema document. */
export declare function scan(doc: string): Iterable<Token>;
/** Serialize a token stream. */
export declare function print(tokens: Iterable<Token>): string;
