import type { Component as ndnComponent } from "@ndn/packet";
import * as N from "./nest.js";
import * as T from "./token.js";
/** AST node. */
export declare abstract class Node {
    abstract toTokens(): Iterable<T.Token>;
}
/** Expression node. */
export declare abstract class Expr extends Node {
    toTokens(): Generator<T.Token, void, undefined>;
    protected static exprToTokens(node: Expr, parent?: Expr): Generator<T.Token, void, undefined>;
    protected abstract exprParens(parent: Expr): boolean;
    protected abstract exprToTokens(): Iterable<T.Token>;
}
/** Name component literal node. */
export declare class ComponentLit extends Expr {
    comp: ndnComponent;
    constructor(comp: ndnComponent);
    protected exprParens(): boolean;
    protected exprToTokens(): Generator<T.ComponentLit, void, unknown>;
}
/** Identifier node. */
export declare class Ident extends Expr {
    id: string;
    /** Determine whether identifier could be a runtime variable name. */
    static isRuntime(id: string): boolean;
    static fromToken(token: N.Unit): Ident;
    constructor(id: string);
    protected exprParens(): boolean;
    protected exprToTokens(): Generator<T.Ident, void, unknown>;
}
/** Internal function call node. */
export declare class Call extends Expr {
    func: string;
    args: Expr[];
    constructor(func: string, args?: Expr[]);
    protected exprParens(): boolean;
    protected exprToTokens(): Generator<T.Token, void, undefined>;
}
/** Alternate expressions or expression in parens node. */
export declare class Alt extends Expr {
    choices: Expr[];
    constructor(choices?: Expr[]);
    protected exprParens(parent: Expr): boolean;
    protected exprToTokens(): Iterable<T.Token>;
}
/** Name node. */
export declare class Name extends Expr {
    comps: Expr[];
    constructor(comps?: Expr[]);
    protected exprParens(parent: Expr): boolean;
    protected exprToTokens(): Iterable<T.Token>;
}
/** Constrained expression node. */
export declare class Constrained extends Expr {
    name: Name | Ident;
    componentConstraint: ComponentConstraintEq;
    constructor(name: Name | Ident, componentConstraint: ComponentConstraintEq);
    protected exprParens(): boolean;
    protected exprToTokens(): Iterable<T.Token>;
}
/** Component constraint equation. */
export declare abstract class ComponentConstraintEq extends Node {
    toTokens(): Iterable<T.Token>;
    protected static componentConstraintToTokens(node: ComponentConstraintEq, parentOp: string): Iterable<T.Token>;
    protected abstract componentConstraintToTokens(parentOp: string): Iterable<T.Token>;
}
/** Component constraint term node. */
export declare class ComponentConstraintTerm extends Node {
    tag: Ident;
    expr: Expr;
    constructor(tag: Ident, expr: Expr);
    toTokens(): Generator<T.Token, void, undefined>;
}
/** Component constraint node. */
export declare class ComponentConstraint extends ComponentConstraintEq {
    terms: ComponentConstraintTerm[];
    constructor(terms?: ComponentConstraintTerm[]);
    protected componentConstraintToTokens(): Generator<T.Token, void, undefined>;
}
/** Component constraint And/Or relation node. */
export declare class ComponentConstraintRel extends ComponentConstraintEq {
    left: ComponentConstraintEq;
    op: T.Operator;
    right: ComponentConstraintEq;
    constructor(left: ComponentConstraintEq, op: T.Operator, right: ComponentConstraintEq);
    protected componentConstraintToTokens(parentOp: string): Generator<T.Token, void, undefined>;
}
/** Signing constraint node. */
export declare class SigningConstraint extends Node {
    signers: Ident[];
    constructor(signers?: Ident[]);
    toTokens(): Generator<T.Token, void, undefined>;
}
/** Statement node. */
export declare class Stmt extends Node {
    ident: Ident;
    definition: Expr | undefined;
    signingChain: SigningConstraint[];
    constructor(ident: Ident, definition?: Expr | undefined, signingChain?: SigningConstraint[]);
    toTokens(): Generator<T.Token, void, undefined>;
}
/** Schema document node. */
export declare class Schema extends Node {
    stmts: Stmt[];
    constructor(stmts?: Stmt[]);
    toTokens(): Generator<T.Token, void, undefined>;
}
/** Parse a schema. */
export declare function parse(tokens: Iterable<T.Token>): Schema;
