import type { KeyChain } from "@ndn/keychain";
import type { Name, Signer } from "@ndn/packet";
import { PolicySigner } from "../policy-signer.js";
import type { TrustSchema } from "./schema.js";
/** Sign packets according to a trust schema. */
export declare class TrustSchemaSigner extends PolicySigner implements Signer {
    private readonly keyChain;
    private readonly policy;
    constructor({ keyChain, schema }: TrustSchemaSigner.Options);
    findSigner(name: Name): Promise<Signer>;
}
export declare namespace TrustSchemaSigner {
    interface Options {
        /** KeyChain to find certificates. */
        keyChain: KeyChain;
        /** Trust schema to guide policy. */
        schema: TrustSchema;
    }
}
