import type { KeyChain } from "@ndn/keychain";
import type { Name, Signer } from "@ndn/packet";
import type { TrustSchema } from "./schema";
/** Sign packets according to a trust schema. */
export declare class TrustSchemaSigner implements Signer {
    private readonly keyChain;
    private readonly policy;
    constructor({ keyChain, schema }: TrustSchemaSigner.Options);
    /** Sign a packet. */
    sign(pkt: Signer.Signable): Promise<void>;
    /** Locate an existing signer. */
    findSigner(name: Name): Promise<Signer>;
}
export declare namespace TrustSchemaSigner {
    interface Options {
        /** KeyChain to find certificates. */
        keyChain: KeyChain;
        /** Trust schema to guide policy. */
        schema: TrustSchema;
    }
}
