import type { Certificate } from "@ndn/keychain";
import { Name, Verifier } from "@ndn/packet";
import { PolicyVerifier } from "../policy-verifier";
import type { TrustSchemaPolicy } from "./policy";
import type { TrustSchema } from "./schema";
interface Context {
    packet: TrustSchemaPolicy.Match[];
}
/** Verify packets according to a trust schema. */
export declare class TrustSchemaVerifier extends PolicyVerifier<Context> {
    private readonly policy;
    constructor(opts: TrustSchemaVerifier.Options);
    protected checkKeyLocatorPolicy({ name }: Verifier.Verifiable, klName: Name): Context;
    protected checkCertPolicy({ name }: Verifier.Verifiable, { name: certName }: Certificate, { packet }: Context): void;
}
export declare namespace TrustSchemaVerifier {
    interface Options extends Omit<PolicyVerifier.Options, "trustAnchors"> {
        /** The trust schema. */
        schema: TrustSchema;
    }
}
export {};
