import type { Certificate } from "@ndn/keychain";
import type { Name, Verifier } from "@ndn/packet";
import type { Except } from "type-fest";
import { PolicyVerifier } from "../policy-verifier.js";
import type { TrustSchemaPolicy } from "./policy.js";
import type { TrustSchema } from "./schema.js";
interface Context {
    packet: TrustSchemaPolicy.Match[];
}
/** Verify packets according to a trust schema. */
export declare class TrustSchemaVerifier extends PolicyVerifier<Context> {
    private readonly policy;
    constructor(opts: TrustSchemaVerifier.Options);
    protected checkKeyLocatorPolicy({ name }: Verifier.Verifiable, klName: Name): Context;
    protected checkCertPolicy({ name }: Verifier.Verifiable, { name: certName }: Certificate, { packet }: Context): void;
}
export declare namespace TrustSchemaVerifier {
    interface Options extends Except<PolicyVerifier.Options, "trustAnchors"> {
        /** The trust schema. */
        schema: TrustSchema;
    }
}
export {};
