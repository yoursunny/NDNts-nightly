import type { TrustSchemaPolicy } from "./policy.js";
/** Print policy as ECMAScript module. */
export declare function printESM(policy: TrustSchemaPolicy): string;
