import { VariablePattern } from "./pattern.js";
import type { TrustSchemaPolicy } from "./policy.js";
/** Print policy as ECMAScript module. */
export declare function printESM(policy: TrustSchemaPolicy): string;
export declare namespace printESM {
    interface Context {
        indent: string;
        addImport: (module: string, ...identifier: readonly string[]) => void;
    }
    interface PrintableFilter extends VariablePattern.Filter {
        printESM: (ctx: Context) => string;
    }
}
