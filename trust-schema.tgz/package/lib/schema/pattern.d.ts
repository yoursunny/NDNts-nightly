import { type Component, Name, type NameLike, type NamingConvention } from "@ndn/packet";
export type Vars = ReadonlyMap<string, Name>;
export declare namespace Vars {
    /** Check if lhs and rhs are consistent, i.e. have no key with different values. */
    function consistent(lhs: Vars, rhs: Vars): boolean;
}
export type VarsLike = Vars | Readonly<Record<string, NameLike>>;
export declare namespace VarsLike {
    /** Convert VarsLike to an iterable that may be passed to Map constructor to create Vars. */
    function toIterable(vars: VarsLike): Iterable<[string, NameLike]>;
}
/** Context of matching a name. */
declare class MatchState {
    readonly name: Name;
    readonly pos: number;
    readonly vars: Vars;
    /**
     * Constructor.
     * @param name - Input name.
     * @param pos - Position of first unconsumed component.
     * @param vars - Recognized variables.
     */
    constructor(name: Name, pos?: number, vars?: Vars);
    /** Length of unconsumed name. */
    get tailLength(): number;
    /**
     * Get first i components of unconsumed name.
     * @param i - Number of components, must be non-negative.
     */
    tail(i?: number): Name;
    /** Whether the input name has been accepted by pattern. */
    get accepted(): boolean;
    /**
     * Clone the state while consuming part of the name.
     * @param incrementPos - How many components are consumed.
     * @returns Updated state.
     */
    extend(incrementPos: number): MatchState;
    /**
     * Clone the state while consuming part of the name.
     * @param incrementPos - How many components are consumed.
     * @param varsL - Updated variables.
     * @returns Updated state, or `false` if variables are inconsistent.
     */
    extend(incrementPos: number, ...varsL: Array<Iterable<readonly [string, Name]>>): MatchState | false;
    toString(): string;
}
/** Context of constructing a name. */
declare class BuildState {
    readonly name: Name;
    readonly vars: Map<string, Name>;
    constructor(name: Name, vars: Map<string, Name>);
    append(...comps: Component[]): BuildState;
    toString(): string;
}
/** Structure of a name. */
export declare abstract class Pattern {
    /**
     * Determine whether a name matches the structure of this pattern.
     * @param name - Input name.
     * @returns - Iterable of extracted fields in possible interpretations.
     */
    match(name: Name): Iterable<Vars>;
    protected static matchState(p: Pattern, state: MatchState): Iterable<MatchState>;
    /**
     * Recognize part of the input name.
     * @returns Iterable of potential matches.
     */
    protected abstract matchState(state: MatchState): Iterable<MatchState>;
    /**
     * Determine minimum and maximum match length.
     *
     * @remarks
     * This optimization is used in {@link match} for early rejection of input names that are
     * either too short or too long.
     */
    get matchLengthRange(): [min: number, max: number];
    private matchLengthRange_?;
    protected abstract computeMatchLengthRange(): [min: number, max: number];
    /**
     * Build names following the structure of this pattern.
     * @param varsL - Sets of variables to be replaced into the name.
     * @returns Iterable of possible names.
     */
    build(...varsL: VarsLike[]): Iterable<Name>;
    /**
     * Build part of an output name.
     * @returns Iterable of potential constructions.
     */
    protected static buildState(p: Pattern, state: BuildState): Iterable<BuildState>;
    protected abstract buildState(state: BuildState): Iterable<BuildState>;
}
/** Match or construct a constant name portion. */
export declare class ConstPattern extends Pattern {
    constructor(name: NameLike);
    readonly name: Name;
    protected matchState(state: MatchState): Iterable<MatchState>;
    protected computeMatchLengthRange(): [min: number, max: number];
    protected buildState(state: BuildState): Iterable<BuildState>;
}
/**
 * Match or construct a variable name portion.
 *
 * @remarks
 * When matching a name, this pattern extracts a number of name components, and saves the sub-name
 * in variables object in {@link VariablePattern.match} return value.
 *
 * When building a name, this pattern succeeds if the variable is present in
 * {@link VariablePattern.build} function argument.
 */
export declare class VariablePattern extends Pattern {
    readonly id: string;
    /**
     * Constructor
     * @param id - Variable name.
     */
    constructor(id: string, { minComps, maxComps, inner, filter, }?: VariablePattern.Options);
    readonly minComps: number;
    readonly maxComps: number;
    readonly inner?: Pattern;
    readonly filter?: VariablePattern.Filter;
    private innerMatch;
    private filtersAccept;
    protected matchState(state: MatchState): Iterable<MatchState>;
    protected computeMatchLengthRange(): [min: number, max: number];
    protected buildState(state: BuildState): Iterable<BuildState>;
}
export declare namespace VariablePattern {
    interface Options {
        /**
         * Minimum number of components.
         * @defaultValue 1
         */
        minComps?: number;
        /**
         * Maximum number of components.
         * @defaultValue 1
         */
        maxComps?: number;
        /**
         * An overlay pattern that the name part must satisfy.
         *
         * @remarks
         * Setting this option effectively makes this variable an alias of the inner pattern.
         *
         * When building a name, if the variable of this pattern is present in
         * {@link VariablePattern.build} function argument, it is checked that the inner pattern
         * matches the name and its interpretation is consistent with other variables that are present.
         * Otherwise, the inner pattern is used to build the name.
         */
        inner?: Pattern;
        /**
         * Filter that the name part must satisfy.
         *
         * @remarks
         * If {@link inner} is specified, the filter function can have access to variables
         * interpreted by the inner pattern.
         */
        /**
         * Filter that the name part must satisfy.
         *
         * @remarks
         * If {@link inner} is specified, the filter function can have access to variables
         * interpreted by the inner pattern.
         */
        filter?: Filter;
    }
    /** Function to determine whether a name part is acceptable. */
    interface Filter {
        accept: (name: Name, vars: Vars) => boolean;
    }
    /** Create a filter that accepts a name component if it satisfies a convention. */
    class ConventionFilter implements Filter {
        readonly convention: NamingConvention<any>;
        constructor(convention: NamingConvention<any>);
        accept(name: Name): boolean;
    }
}
/**
 * Match or construct a KeyLocator or certificate name.
 *
 * @remarks
 * To match a KeyLocator or certificate name, use a {@link ConcatPattern} that contains
 * patterns to match the subject name, followed by a {@link CertNamePattern} at last.
 * The captured variable contains the whole KeyLocator or certificate name that can
 * be further recognized by {@link CertNaming.parseKeyName} and {@link CertNaming.parseCertName}.
 *
 * Using the same {@link ConcatPattern}, the constructed name would be the subject name only.
 * It can be passed to {@link \@ndn/keychain!KeyChain.getSigner} to find a key/certificate.
 */
export declare class CertNamePattern extends Pattern {
    protected matchState(state: MatchState): Iterable<MatchState>;
    protected computeMatchLengthRange(): [min: number, max: number];
    protected buildState(state: BuildState): Iterable<BuildState>;
}
/** Concatenate several patterns. */
export declare class ConcatPattern extends Pattern {
    readonly parts: readonly Pattern[];
    constructor(parts: readonly Pattern[]);
    protected matchState(state: MatchState, partIndex?: number): Iterable<MatchState>;
    protected computeMatchLengthRange(): [min: number, max: number];
    protected buildState(state: BuildState, partIndex?: number): Iterable<BuildState>;
}
/** Specify several alternate patterns in "OR" relation. */
export declare class AlternatePattern extends Pattern {
    readonly choices: readonly Pattern[];
    constructor(choices: readonly Pattern[]);
    protected matchState(state: MatchState): Iterable<MatchState>;
    protected computeMatchLengthRange(): [min: number, max: number];
    protected buildState(state: BuildState): Iterable<BuildState>;
}
/**
 * Specify several overlapped patterns in "AND" relation.
 *
 * @remarks
 * When matching a name, every branch of this pattern must extract the same number of name
 * components, and their variables must be consistent.
 *
 * When building a name, one branch is used to build the name as long as all required variables
 * are present, and then the built name must match all branches.
 */
export declare class OverlapPattern extends Pattern {
    readonly branches: readonly Pattern[];
    constructor(branches: readonly Pattern[]);
    protected matchState(state: MatchState, branchIndex?: number, lastMatch?: MatchState): Iterable<MatchState>;
    protected computeMatchLengthRange(): [min: number, max: number];
    protected buildState(state: BuildState): Iterable<BuildState>;
}
export {};
