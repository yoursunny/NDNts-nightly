import { Component, Name, NameLike } from "@ndn/packet";
export declare type Vars = Record<string, Name>;
export declare type VarsLike = Readonly<Record<string, NameLike>>;
/** Context of matching a name. */
declare class MatchState {
    readonly name: Name;
    readonly pos: number;
    readonly vars: Vars;
    /**
     * Constructor.
     * @param name input name.
     * @param pos  position of first unconsumed component.
     * @param vars recognized variables.
     */
    constructor(name: Name, pos?: number, vars?: Vars);
    /** Unconsumed name portion. */
    get tail(): Name;
    /** Length of unconsumed name. */
    get tailLength(): number;
    /** Get first i components of unconsumed name. */
    tailPrefix(i: number): Name;
    /** Whether the input name has been accepted by pattern. */
    get accepted(): boolean;
    /**
     * Clone the state while consuming part of the name.
     * @param incrementPos how many components are consumed.
     * @param vars updated variables.
     */
    extend(incrementPos: number, vars?: Vars): MatchState;
}
/** Context of constructing a name. */
declare class BuildState {
    readonly name: Name;
    readonly vars: Map<string, Name>;
    constructor(name: Name, vars: Map<string, Name>);
    append(...comps: Component[]): BuildState;
}
/** Structure of a name. */
export declare abstract class Pattern {
    /** Convert to a simpler pattern if possible. */
    simplify(): Pattern;
    /**
     * Determine whether a name matches the structure of this pattern.
     *
     * @param name input name.
     * @returns an iterable of extracted fields in possible interpretations.
     */
    match(name: Name): Iterable<Vars>;
    protected static matchState(p: Pattern, state: MatchState): Iterable<MatchState>;
    /**
     * Recognize part of the input name.
     * @returns iterable of potential matches.
     */
    protected abstract matchState(state: MatchState): Iterable<MatchState>;
    /**
     * Build names following the structure of this pattern.
     *
     * @param vars variables to be replaced into the name.
     * @returns an iterable of possible names.
     */
    build(vars?: VarsLike): Iterable<Name>;
    /**
     * Build part of an output name.
     * @returns iterable of potential constructions.
     */
    protected static buildState(p: Pattern, state: BuildState): Iterable<BuildState>;
    protected abstract buildState(state: BuildState): Iterable<BuildState>;
}
/** Match or construct a constant name portion. */
export declare class ConstPattern extends Pattern {
    constructor(name: NameLike);
    readonly name: Name;
    protected matchState(state: MatchState): Iterable<MatchState>;
    protected buildState(state: BuildState): Iterable<BuildState>;
}
/**
 * Match or construct a variable name portion.
 *
 * When matching a name, this pattern extracts a number of name components,
 * and saves the sub-name in variables object in match() return value.
 *
 * When building a name, this pattern succeeds if the variable is present
 * in build() function argument.
 */
export declare class VariablePattern extends Pattern {
    readonly id: string;
    /**
     * Constructor
     * @param id variable name.
     */
    constructor(id: string, { minComps, maxComps, accept, }?: VariablePattern.Options);
    readonly minComps: number;
    readonly maxComps: number;
    readonly accept: (part: Name) => boolean;
    protected matchState(state: MatchState): Iterable<MatchState>;
    protected buildState(state: BuildState): Iterable<BuildState>;
}
export declare namespace VariablePattern {
    interface Options {
        /** Minimum number of components, default is 1. */
        minComps?: number;
        /** Maximum number of components, default is 1. */
        maxComps?: number;
        /** Function to determine whether a name part is acceptable. */
        accept?: (name: Name) => boolean;
    }
}
/**
 * Match or construct a KeyLocator or certificate name.
 *
 * To match a KeyLocator or certificate name, use a ConcatPattern that contains
 * patterns to match the subject name, followed by a CertNamePattern at last.
 * The captured variable contains the whole KeyLocator or certificate name that can
 * be further recognized by CertNaming.parseKeyName() and CertNaming.parseCertName().
 *
 * Using the same ConcatPattern, the constructed name would be the subject name.
 * It can be passed to keyChain.getSigner() to find a key/certificate.
 */
export declare class CertNamePattern extends Pattern {
    protected matchState(state: MatchState): Iterable<MatchState>;
    protected buildState(state: BuildState): Iterable<BuildState>;
}
/** Concatenate several patterns. */
export declare class ConcatPattern extends Pattern {
    readonly parts: Pattern[];
    constructor(parts?: Pattern[]);
    simplify(): Pattern;
    private flatten;
    protected matchState(state: MatchState, partIndex?: number): Iterable<MatchState>;
    protected buildState(state: BuildState, partIndex?: number): Iterable<BuildState>;
}
/**
 * Specify several alternate patterns in "OR" relation.
 *
 * When matching a name, the first successful match is returned.
 *
 * When building a name, the first choice that does not have missing variable is returned.
 */
export declare class AlternatePattern extends Pattern {
    readonly choices: Pattern[];
    constructor(choices?: Pattern[]);
    simplify(): Pattern;
    private flatten;
    protected matchState(state: MatchState): Iterable<MatchState>;
    protected buildState(state: BuildState): Iterable<BuildState>;
}
export {};
