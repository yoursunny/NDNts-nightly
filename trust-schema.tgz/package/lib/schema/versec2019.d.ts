import { TrustSchemaPolicy } from "./policy";
/**
 * Load policy from VerSec syntax.
 * https://pollere.net/Pdfdocs/BuildingBridge.pdf page 14
 */
export declare function load(input: string): TrustSchemaPolicy;
/**
 * Print policy to VerSec syntax.
 * https://pollere.net/Pdfdocs/BuildingBridge.pdf page 14
 */
export declare function print(policy: TrustSchemaPolicy): string;
