/**
 * Distill the essence of NDN into one emoji.
 * @returns URI of the emoji
 * @todo Use an NDN Name instead of HTTPS.
 */
export declare function distill(): string;
