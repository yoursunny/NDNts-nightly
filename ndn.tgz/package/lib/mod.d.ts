/**
 * Distill the essence of NDN into one emoji.
 * @returns URI of the emoji.
 */
export declare function distill(): string;
